"""One-time archival of the eleven user-approved display-only parameters."""
import copy
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATE = '2026-11-18 America/Los_Angeles'
SPECS = {
    'ascend910_reference': (9, 12, {
        'cube.units_per_core': 'Cube count was used only for compute-unit inventory. GEMM uses its explicit per-core MAC service and fixed INT8 geometry.',
        'vector.units_per_core': 'Vector count was used only for compute-unit inventory. The standalone Vector API uses its explicit shared service budget.',
    }),
    'tpu_v4_reference': (12, 13, {
        'parameters.nominal_int8_tops': 'Published nominal peak was a display-only reference, distinct from the retained geometry-derived peak.',
        'parameters.vpus_per_tensorcore': 'VPU count was used only for physical inventory; the standalone Vector service has an explicit fixed budget.',
        'parameters.vpu_lanes': 'VPU lane geometry was used only for ALU inventory; it is not a runtime fallback for Vector throughput.',
        'parameters.vpu_alus_per_lane': 'ALUs per VPU lane were used only for ALU inventory; Vector work consumes the independently configured budget and costs.',
    }),
    'tsp': (9, 10, {
        'parameters.nominal_int8_tops': 'Nominal 750 TOPS was only printed as a reference; derived geometry remains 737.28 TOPS and neither nominal value drives GEMM time.',
    }),
    'tsp_cim': (7, 10, {
        'parameters.nim_units_per_plane': 'NIM unit count was inventory only; no NIM unit allocator or FP conversion execution exists in the INT32 GEMM path.',
        'parameters.nim_tiles_per_plane': 'NIM tile count was inventory only; current INT32 writer timing uses the separate explicit int32_writer_bpc service.',
        'parameters.nim_channels_per_tile': 'Logical NIM channel count was inventory only; it does not allocate independent physical writers or schedule channels.',
        'parameters.nim_conversion_lanes': 'FP conversion-lane count was inventory only. Current GEMM outputs INT32 through an explicit bypass service and performs no FP conversion.',
    }),
}

def digest(data):
    return hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

base=json.loads((ROOT/'tmp/hardware_archival_baseline.json').read_text(encoding='utf-8'))
audit_path=ROOT/'calibration/parameter_source_audit.json'
audit=json.loads(audit_path.read_text(encoding='utf-8'))
for name,(schema,report_schema,fields) in SPECS.items():
    active_path=f'configs/hardware/{name}.json'
    archive_path=f'configs/archive/{name}.json'
    c=json.loads((ROOT/active_path).read_text(encoding='utf-8'))
    assert c==base['configs'][name], f'Concurrent configuration change: {name}'
    entry=audit['configs'][active_path]
    assert entry['canonical_json_sha256']==digest(c)
    old_schema=c['schema_version']
    if (ROOT/archive_path).exists():
        a=json.loads((ROOT/archive_path).read_text(encoding='utf-8'))
        a.setdefault('archival_history',[{'archived_at':a['archived_at'],
            'from_schema':a['archived_from']['schema_version'],
            'parameters':list(a['parameters'])}])
    else:
        a={'schema_version':1,'model':name+'_archived_specifications',
           'description':'Reference-only specifications archived from the active execution profile. Not a simulation configuration; the runtime does not load or merge this file.',
           'archived_at':DATE,'archived_from':{'path':active_path,'schema_version':old_schema},
           'parameters':{},'archival_reasons':{},'archival_history':[]}
    names=[]
    for path,reason in fields.items():
        parent,key=path.split('.')
        parameter=c[parent].pop(key)
        archive_key=key if parent=='parameters' else path
        assert archive_key not in a['parameters']
        a['parameters'][archive_key]=copy.deepcopy(parameter)
        a['archival_reasons'][archive_key]=reason
        names.append(archive_key)
        prior=entry['parameters'].pop(path)
        retired={'retired_at':DATE,'last_configuration':parameter,'prior_audit':prior,
                 'archive_path':archive_path,'reason':reason+' User authorized archival using the existing TPU pattern.',
                 'migration':f'Remove {path} from the active JSON and migrate hardware schema {old_schema} to {schema}; report schema is {report_schema}. The runtime has no archive dependency.'}
        usage=entry.get('parameter_usage_review',{}).get('parameters',{})
        if key in usage:
            retired['prior_usage']=usage.pop(key)
        entry.setdefault('retired_parameters',{})[path]=retired
    a['archival_history'].append({'archived_at':DATE,'from_schema':old_schema,
        'active_schema_after':schema,'report_schema_after':report_schema,'parameters':names})
    c['schema_version']=schema
    note=f' Display-only specifications are preserved in {archive_path}; the runtime does not load this archive.'
    c['description']+=note
    docs=c['_documentation']
    docs['descriptive_metadata']['description']+=f' 已归档的规格/库存值见 {archive_path}，运行时不读取或合并归档。'
    if name=='ascend910_reference':
        docs['hardware_parameters']['cube']='硬件数值参数：INT8 分形几何与计算服务率；几何不自动等于每周期吞吐。Cube 单元数量仅作库存，已移入归档。'
        docs['hardware_parameters']['vector']='硬件数值参数：共享 Vector 服务预算与操作代价；独立服务 API 消费这些值，当前 GEMM 不额外计 Vector 算术。Vector 单元数量已归档。'
    elif name=='tpu_v4_reference':
        docs['hardware_parameters']['parameters']='硬件数值参数：矩阵几何、容量、带宽、算术服务和矩阵单元库存。标称 TOPS 与 VPU/ALU 库存已归档；Vector 服务直接使用显式预算，不从归档几何推导默认吞吐。'
    elif name=='tsp_cim':
        docs['hardware_parameters']['parameters']='硬件数值参数：CIM Core/Cluster/Plane 拓扑、LW 捕获及 INT32 writer 服务。四项 NIM 库存已归档；int32_writer_bpc 继续参与 GEMM 计时。共享 MEM/stream/VXM 从 native_reference 读取，Macro 几何从 macro_reference 读取。'
    if 'parameter_usage_review' in entry:
        entry['parameter_usage_review']['method']='Current 21 parameters retain GEMM execution/capacity, standalone Vector service and matrix/memory inventory. Nominal TOPS and three VPU inventory fields were additionally archived by user authorization; no runtime archive loading or geometry fallback.'
    entry['parameter_count']=len(entry['parameters'])
    entry['status_counts']=dict(Counter(p['status'] for p in entry['parameters'].values()))
    entry.setdefault('archival_history',[]).append({'archived_at':DATE,'fields':list(fields),
        'archive_path':archive_path,'hardware_schema_before':old_schema,'hardware_schema_after':schema,
        'report_schema_after':report_schema,'scope':'Display-only fields removed from active input and reports; execution and service formulas unchanged.'})
    entry['canonical_json_sha256']=digest(c)
    record=audit.setdefault('archives',{}).setdefault(archive_path,{})
    record.update(canonical_json_sha256=digest(a),parameter_count=len(a['parameters']),
                  parameters=list(a['parameters']),active_profile=active_path,runtime_dependency=False)
    save(ROOT/active_path,c);save(ROOT/archive_path,a)
    print(name, 'archived',len(fields),'active',entry['parameter_count'],'schema',schema,'report',report_schema)
all_parameters=[p for e in audit['configs'].values() for p in e['parameters'].values()]
audit['total_parameters_reviewed']=len(all_parameters)
audit['status_counts']=dict(Counter(p['status'] for p in all_parameters))
audit['result_counts']=dict(Counter(p['result'] for p in all_parameters))
audit['configuration_reviewed_at']=datetime.now(timezone.utc).isoformat()
audit.setdefault('completion_boundary_history',[]).append(audit['completion_boundary'])
audit['completion_boundary']='User-authorized archival of eleven display-only hardware inputs across the four active profiles. Original source records and audit evidence are retained in archives and retired_parameters. Current active totals include the separate Macro profile. Execution formulas, independent Vector services and remaining structural/capacity checks are preserved. No new external verification or hardware calibration is claimed.'
save(audit_path,audit)
