"""Ascend reference model tests."""
