import json
import sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.core.ascend.simulator import AscendSimulator
from src.core.tpu.simulator import TPUSimulator
from src.core.tsp.simulator import TSPSimulator
from src.core.tsp_cim.simulator import TSPCIMSimulator
from src.hardware.ascend import AscendSpec
from src.hardware.tpu import TPUSpec
from src.utils.tsp_cim_config import TSPCIMConfigLoader
from src.utils.workload import parse_workloads

base=json.loads((ROOT/'tmp/hardware_archival_baseline.json').read_text(encoding='utf-8'))
configs={name:json.loads((ROOT/'configs/hardware'/f'{name}.json').read_text(encoding='utf-8')) for name in base['configs']}
for name,c in configs.items():
    original=base['configs'][name]
    for key,value in c.items():
        if key in ('_documentation','schema_version','description'):continue
        if key in ('cube','vector','parameters'):
            for field,item in value.items():assert item==original[key][field],(name,key,field)
        else:assert value==original[key],(name,key)
ld=TSPCIMConfigLoader();cs=ld.create_tsp_spec(ld.load_hardware_config())
sims={'ascend':AscendSimulator(AscendSpec(configs['ascend910_reference'])),
      'tpu':TPUSimulator(TPUSpec(configs['tpu_v4_reference'])),
      'tsp':TSPSimulator(cs.native_reference_spec),'tsp_cim':TSPCIMSimulator(cs)}
def diff(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        result=[]
        for k in sorted(a.keys()|b.keys()):
            p=path+'.'+k if path else k
            result.extend([p] if k not in a or k not in b else diff(a[k],b[k],p))
        return result
    return [] if a==b else [path]
records=[]
for entry in base['reports']:
    name,shape=entry['name'],entry['shape']
    w=parse_workloads({'gemm':dict(zip('MKN',shape)),'data_format':'INT8'})[0]
    options=dict(mode=entry['mode'],**entry['policy'])
    new=sims[name].simulate(w,**options) if name in ('ascend','tpu') else sims[name].simulate(*shape,**options)
    old=entry['report']
    keys=('counts','action_counts','work_counts','memory','timing','schedule','execution_contract')
    assert all(old.get(k)==new.get(k) for k in keys),(name,shape,options)
    records.append({**{k:v for k,v in entry.items() if k!='report'},'execution_equal':True,
                    'report_changes':diff(old,new)})
changes=Counter(path for r in records for path in r['report_changes'])
print('All',len(records),'reports preserve timing, counts, actions, work views, memory, schedules and execution policies.')
print(json.dumps(changes,indent=2))
out=ROOT/'validation/hardware_archival';out.mkdir(parents=True,exist_ok=True)
(out/'comparison.json').write_text(json.dumps({'report_count':len(records),'execution_equal':True,
    'remaining_parameter_records_unchanged':True,'changes':changes,'cases':records},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
