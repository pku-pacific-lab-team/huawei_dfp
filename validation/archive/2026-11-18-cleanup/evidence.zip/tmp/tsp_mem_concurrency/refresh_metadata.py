"""One-time migration of the reviewed MEM policy; preserves earlier evidence."""
import hashlib
import json
from collections import Counter
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf8")


audit_path = "calibration/parameter_source_audit.json"
audit = read(audit_path)
old = read("tmp/tsp_mem_concurrency/tsp.json")
profile = audit["configs"]["configs/hardware/tsp.json"]
profile["retired_parameters"]["parameters.mem_shared_bpc"] = {
    "retired_at": "2026-11-18 America/Los_Angeles",
    "reason": "Replace the conservative combined read/write cap with independent directional services under the user-selected conflict-free bank-layout assumption. Single-direction bandwidth is unchanged; no 640 B/cycle read service is introduced.",
    "last_configuration": old["parameters"]["mem_shared_bpc"],
    "prior_audit": profile["parameters"].pop("parameters.mem_shared_bpc"),
}
source_id = "tsp_mem_concurrency_policy"
audit["sources"][source_id] = {
    "title": "Independent MEM read/write services with assumed conflict-free bank placement",
    "classification": "model_policy", "path": "ARCHITECTURE.md#tsp-mem-concurrency",
    "version": "2026-11-18 independent MEM read/write services v1",
    "identity_verification": "Hardware capability corroborated by Answer Fast II-B (PDF page 2), HotChips34 slide 30 and ALCF Groq workshop 2024 slide 28. Conflict-free placement for all modeled workloads is a software assumption, not a measured guarantee.",
}
evidence = [
    {"source_id": "asap2022", "section": "II-B TSP Architecture, PDF page 2",
     "summary": "Opposite-bank read/write concurrency; one 320-byte vector per direction per cycle."},
    {"source_id": "hotchips2022", "section": "MEM, slide 30",
     "summary": "Two banks can read and write one physical vector each per cycle."},
    {"source_id": source_id, "locator": "ARCHITECTURE.md#tsp-mem-concurrency",
     "summary": "Assume conflict-free bank placement; retain read/read contention, dependencies and stream limits. No per-bank allocation or capacity validation."},
]
for name in ("tsp", "tsp_cim"):
    path = f"configs/hardware/{name}.json"
    config = read(path)
    entry = audit["configs"][path]
    entry["canonical_json_sha256"] = hashlib.sha256(json.dumps(config, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    entry["parameter_count"] = len(config["parameters"])
    entry["status_counts"] = dict(Counter(p["status"] for p in config["parameters"].values()))
    review = entry["execution_policy_review"]
    review["configuration"] = config["execution"]
    review["decision"] += " MEM read/write services are independent; conflict-free bank placement is assumed explicitly. Read consumers still share one budget, including background LW; write traffic does not consume that read budget."
    review["mem_concurrency_evidence"] = evidence
profile["parameters"]["parameters.install_bpc"]["decision"] = read("configs/hardware/tsp.json")["parameters"]["install_bpc"]["conditions"]
audit["total_parameters_reviewed"] = sum(p["parameter_count"] for p in audit["configs"].values())
audit["status_counts"] = dict(sum((Counter(p["status_counts"]) for p in audit["configs"].values()), Counter()))
audit["result_counts"] = dict(Counter(p["result"] for c in audit["configs"].values() for p in c["parameters"].values()))
audit["configuration_reviewed_at"] = "2026-11-18 America/Los_Angeles"
audit["completion_boundary"] = audit["completion_boundary"].replace("All 109", "All 108").replace("68 documented, 41 assumed", "68 documented, 40 assumed").replace("TSP hardware schema 6 replaces", "TSP hardware schema 7 retains the schema 6 replacement of").replace("31 non-null", "30 non-null")
audit["completion_boundary"] += " TSP schema 7/report 7 and CIM schema 6/report 8 retire the combined MEM cap; independent read/write services assume conflict-free bank placement and do not validate banks."
audit["findings"]["tsp_mem_concurrency_2026_11_18"] = {
    "hardware_schemas": {"tsp": 7, "tsp_cim": 6}, "report_schemas": {"tsp": 7, "tsp_cim": 8},
    "retired": "parameters.mem_shared_bpc", "policy": "independent_assumed_conflict_free",
    "evidence": evidence,
    "decision": "Independent 320 B/cycle read and 320 B/cycle write per slice. Aggregate read consumers are summed before max with writes; background LW competes with reads and input streams only. Preserve action counts and physical capacity; timing may improve on combined-MEM-bound cases. No bank allocator, numerical simulation or silicon validation added.",
}
save(audit_path, audit)

p = Path("README.md")
s = p.read_text(encoding="utf8")
s = s.replace("TSP 当前硬件和报告均为 schema 6", "TSP 当前硬件和报告均为 schema 7")
s = s.replace("schema 6 进一步替换旧 add/nonlinear 速率，当前共 31 项且无 null；19 项 documented、12 项 assumed。", "schema 6 替换旧 add/nonlinear 速率，schema 7 再删除 `mem_shared_bpc`，当前共 30 项且无 null；19 项 documented、11 项 assumed。")
s = s.replace("CIM 当前硬件为 **schema 5**、报告为 **schema 7**", "CIM 当前硬件为 **schema 6**、报告为 **schema 8**")
anchor = "## 检查与维护"
section = """TSP 和 CIM 当前采用**简化 MEM 读写并发模型**：每 slice 读、写分别为 320 B/cycle，假设 bank 布局无冲突；同方向动作仍共享预算，后台 LW 与激活/旧部分和读取竞争读带宽。删除合计上限 `mem_shared_bpc`，不新增 640 B/cycle 单向服务。原生 schema 6→7、CIM schema 5→6 的配置必须显式增加 `execution.rules.mem_read_write=\"independent_assumed_conflict_free\"`，报告分别升至 7/8；旧配置拒绝。计数和容量不变，MEM 受限场景的周期可能减少；默认 tiny 仍为原生 588、CIM 4307 cycle。公式和边界见 [MEM 并发模型](ARCHITECTURE.md#tsp-mem-concurrency)。

"""
assert anchor in s
s = s.replace(anchor, section+anchor)
p.write_text(s, encoding="utf8")

p = Path("ARCHITECTURE.md")
s = p.read_text(encoding="utf8")
pairs = [
    ("[tsp_report](src/utils/tsp_report.py)，报告 schema 6", "[tsp_report](src/utils/tsp_report.py)，报告 schema 7"),
    ("CLI 直接输出 JSON，报告 schema 7", "CLI 直接输出 JSON，报告 schema 8"),
    ("当前 schema 6 保持安装服务", "当前 schema 7 采用独立 MEM 读写预算，保持安装服务"),
    ("B_install = min(slice_read_supply, slice_shared_supply,", "B_install = min(slice_read_supply,"),
    ("write_bytes / write_supply,\n             (read_bytes + write_bytes) / shared_supply), each rounded up", "write_bytes / write_supply), each rounded up"),
    ("MEM read/write 有独立上限以及共享总预算，避免一个 slice 被重复分配给多个同时满速的动作。", "MEM read/write 使用独立预算，假设异 bank 无冲突；所有读需求共用 read 预算，所有写需求共用 write 预算。不再施加读写合计上限。"),
    ("当前报告 schema 6，timing.model=single_hem_fixed_services_v2", "当前报告 schema 7，timing.model=single_hem_fixed_services_v3"),
    ("从 852 改为 **846 cycle**", "经固定服务迁移从 852 改为 846，当前独立 MEM 读写服务进一步降为 **844 cycle**"),
    ("硬件 schema 6 使用 `vxm_base_ops_per_cycle=320`", "硬件 schema 7 沿用 schema 6 引入的 `vxm_base_ops_per_cycle=320`"),
    ("参考配置的 31 个参数均非空", "参考配置的 30 个参数均非空"),
    ("| `mem_shared_bpc` | 320 | byte/cycle | slice | assumed | isca2020 / assumption_retained |\n", ""),
    ("mem_shared_bpc=320 是保守软件合并上限。", "旧 mem_shared_bpc=320 保守合并上限已退役；当前独立读写服务显式假设 bank 布局无冲突。"),
    ("MEM read/write/shared 与 stream in/out 五种容量", "MEM read/write 与 stream in/out 四种容量"),
    ("             ceil((total_MEM_read + total_MEM_write) / allocated_shared_bpc),\n", ""),
    ("输出 schema 为 6：reference_id", "输出 schema 为 8：reference_id"),
    ("109 项", "108 项"),
    ("68 documented、41 assumed", "68 documented、40 assumed"),
    ("TSP 的 8 项", "TSP 的 9 项"),
    ("共享 MEM 320 B/cycle 是软件保守策略；任务服务显式采用 assumed 值；schema 6 的参考参数已无 null", "独立 MEM 读写预算假设 bank 布局无冲突；任务服务显式采用 assumed 值；schema 7 的参考参数已无 null"),
]
for a,b in pairs:
    assert a in s, a
    s = s.replace(a,b)
anchor = '<a id="tsp-vxm-service"></a>'
section = """<a id="tsp-mem-concurrency"></a>

### 简化 MEM 读写并发模型（2026-11-18）

原生 TSP 硬件/报告 schema 7，CIM 硬件 schema 6、报告 schema 8。每 slice 保留 `mem_read_bpc=320`、`mem_write_bpc=320`，删除 `mem_shared_bpc`。两份配置都要求 `execution.rules.mem_read_write=\"independent_assumed_conflict_free\"`：明确假设布局已把并发读写分配到不同 bank，不模拟 bank 分配、逐 bank 容量或冲突。同一读预算仍由 activation、旧 PSUM 和权重 LW 共享，所有写动作共用独立写预算；不能把 320+320 当作 640 B/cycle 的单向能力。

公开依据：[Answer Fast 第 2 页](https://arxiv.org/pdf/2206.11062#page=2)明确支持异 bank 同时读写各一个 320 B 向量；[HotChips34 第 30 页](https://hc34.hotchips.org/assets/program/conference/day2/Machine%20Learning/HotChips34%20-%20Groq%20-%20Abts%20-%20final.pdf#page=30)及 [ALCF Groq 2024 培训第 28 页](https://www.alcf.anl.gov/sites/default/files/2024-11/ALCFGroqDay1.pdf#page=28)给出相同能力。硬件能力有公开依据，任意任务均具备无冲突布局则是本模型的 assumed 策略。

```text
read_supply  = allocated_slices * mem_read_bpc
write_supply = allocated_slices * mem_write_bpc
II_MEM = max(ceil(total_row_reads / read_supply),
             ceil(total_row_writes / write_supply))
```

原生首行仍遵守读取→计算→结果传输→可选 PSUM 读取/加法→写回的依赖；仅稳态资源服务允许重叠。CIM 的日历分别预约 mem_read、mem_write，后台 LW 只占 mem_read 和 stream_in；输出写回不消耗读预算，其他读操作仍限制 LW。保持现有 stream 方向约束、块/wave 边界和保守填充/排空预约；这不是逐指令或逐 bank 精确调度。

单 slice、32 streams、M4/K320/N640：原生稳态 II 从 ceil((320+2560)/320)=9 降为 max(1,8)=8；K640 的后续行 activation+PSUM 共读 2880 B，II=9。CIM 的 K640/N640 两任务 wave 每行读 3200 B、写 5120 B，II 从 26 降为 16；其余首行依赖和动作计数不变。

迁移需同时删除原生旧参数、给原生及 CIM 增加上述执行规则并升级各自 schema，不能只改版本。历史参数配置和核验保存在 `retired_parameters`，原生现有 30 项参数（19 documented、11 assumed），全部非空。报告不再输出 mem_shared 服务/资源/需求。安装仅消耗读服务；所有计数和总 MEM 容量不变，周期改善取决于瓶颈。

"""
assert anchor in s
s = s.replace(anchor,section+anchor)
p.write_text(s, encoding="utf8")
print("Audit and documentation updated:",audit["total_parameters_reviewed"],audit["status_counts"])
