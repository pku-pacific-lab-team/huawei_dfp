"""Add root-only maintenance documentation without changing model inputs."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
baseline = json.loads((ROOT/'tmp/config_annotation_baseline.json').read_text(encoding='utf-8'))

sections = {
    'ascend910_reference': {
        'hardware_parameters': {
            'clock_freq_ghz': '硬件数值参数：参考时钟，参与周期/纳秒换算及带宽派生。',
            'memory': '硬件数值参数：各本地缓冲的 physical_bytes 用于库存与容量一致性检查，usable_bytes 用于分块和驻留容量校验；两者不可互相替代。',
            'cube': '硬件数值参数：INT8 分形几何、Cube 库存和计算服务率；几何不自动等于每周期吞吐。',
            'vector': '硬件数值参数：Vector 库存、共享服务预算与操作代价；独立服务 API 消费这些值，当前 GEMM 不额外计 Vector 算术。',
            'transfers': '硬件数值参数：三条核内路径的固定 byte/cycle 服务率；不是路径选择开关。',
            'chip': '硬件数值参数：芯片核数、HBM/L2 容量和带宽；按当前单核分配规则派生服务，不代表已经模拟整片执行。',
        },
        'descriptive_metadata': {
            'description': '说明与依据：模型范围和局限的文字摘要，不控制实际执行。',
            'output_path': '说明与依据：INT32 L0C→UB→HBM 路径的来源及假设；会校验来源状态并写入报告，但修改 description 不会重连数据通路，也不是报告输出文件路径。实际动作由模拟器实现，资源映射见 execution.rules.route_resources。',
        },
        'configuration_control': {
            'schema_version': '配置控制：解析器校验版本；不是硬件数值或自由说明，不能仅改版本来迁移字段。',
            'model': '配置控制：模型身份，必须匹配 Ascend 解析器支持的名称。',
        },
    },
    'tpu_v4_reference': {
        'hardware_parameters': {
            'parameters': '硬件数值参数：几何、容量、带宽、算术服务、标称峰值与单元库存。部分值只供库存/峰值报告或独立 Vector 服务使用，不一定参与当前 GEMM；具体限制见各项 conditions。',
        },
        'descriptive_metadata': {
            'description': '说明与依据：模型范围、带宽代理及已归档项目的文字说明。configs/archive/tpu_v4_reference.json 是参考资料；当前加载器不读取它来补默认值。',
        },
        'configuration_control': {
            'schema_version': '配置控制：解析器校验版本；不允许通过修改版本号自动恢复已归档参数。',
            'model': '配置控制：模型身份，必须匹配 TPU 解析器支持的名称。',
        },
    },
    'tsp': {
        'hardware_parameters': {
            'parameters': '硬件数值参数：拓扑、MEM/stream 容量与服务、MXM/IW 延迟、共享 VXM 服务和有限权重缓冲。含明确 assumed 的模型代理；数值用途可能为计算、校验、派生规格或库存。weight_buffer_bytes 是待用权重缓冲容量假设，不是缓冲槽数，也不额外并入物理 SRAM 库存。',
        },
        'descriptive_metadata': {
            'description': '说明与依据：原生 TSP 模型范围与假设的文字摘要，不控制实际执行。',
        },
        'configuration_control': {
            'schema_version': '配置控制：解析器校验版本；旧配置需显式迁移数值与策略字段。',
            'model': '配置控制：模型身份，必须匹配原生 TSP 解析器。',
            'profile_id': '配置控制：参考配置标识，参与 reference_id 命名，不作为计算系数。',
            'memory_tile_capacity': '配置控制：强制校验 includes_both_banks，声明每个 memory_tile_bytes 已包含两个 bank；不是可忽略的文字，不能再乘 bank 数。',
            'supported_formats': '配置控制：支持格式约束，当前必须为 INT8；添加名称不会自动实现新精度。',
        },
    },
    'tsp_cim': {
        'hardware_parameters': {
            'parameters': '硬件数值参数：CIM Core/Cluster/Plane 拓扑、NIM 库存、LW 捕获及 INT32 writer 服务。包括设计约束和明确 assumed 的服务值；NIM FP 转换库存不等于当前 INT32 GEMM writer 吞吐。共享 MEM/stream/VXM 从 native_reference 读取，Macro 几何从 macro_reference 读取。',
        },
        'descriptive_metadata': {
            'description': '说明与依据：CIM 替换方案及建模范围的文字摘要，不控制实际执行。',
        },
        'configuration_control': {
            'schema_version': '配置控制：解析器校验版本；不应作为任意备注修改。',
            'model': '配置控制：模型身份，必须匹配 CIM 解析器支持的名称。',
            'profile_id': '配置控制：参考配置标识，参与 reference_id 命名，不作为吞吐系数。',
            'supported_formats': '配置控制：支持格式约束，当前必须为 INT8；添加名称不会自动实现新精度。',
            'native_reference': '配置依赖：实际加载的原生 TSP JSON，提供共享系统及比较基线；相对路径以本文件所在目录为准。修改它可能改变执行和校验，不是引用文献的文字。',
            'macro_reference': '配置依赖：实际加载的 Macro profile，提供 Macro 几何及动作模型；相对路径以本文件所在目录为准。修改它会影响构造与计算，不是纯说明。',
        },
    },
}

execution_fields = {
    'scope': '执行约束：允许的局部仿真范围；不能通过改字符串获得整片调度。',
    'resident_boundary': '执行约束：任务的输入/输出驻留边界，解析器校验支持的边界。',
    'schedule': '执行策略：选择解析器支持的调度模型。',
    'default_tile_mkn': '执行策略：默认 M/K/N 分块；不是物理阵列尺寸。支持的 CLI/API 参数可覆盖。',
    'buffer_slots': '执行策略：允许的缓冲槽数；容量仍由硬件数值约束，实际分配以报告为准。',
    'weight_load_overlap': '执行策略/约束：权重准备是否允许重叠，取值必须属于本架构支持的实现。',
    'fixed_latency_cycles': '执行策略：显式建模的固定周期开销，虽为数值仍属于执行策略；0 表示忽略该项开销，空对象表示没有此类配置项。',
    'rules': '执行规则：资源共享、屏障或映射约束；只支持已实现的值，修改说明文字不能增加新规则。',
    'status': '说明与依据并附校验：执行模型必须标为 assumed，不冒充硬件实测行为。',
    'source': '说明与依据：策略的设计依据；不会执行此字符串或访问其 URL 来决定调度。',
    'version': '说明与依据：策略依据的版本，不是 schema_version。',
    'conditions': '说明与依据：策略的适用条件和局限；用于追溯，不作为可执行表达式。',
}
special_execution_fields = {
    'ascend910_reference': {
        'l2': '执行策略：冷启动、完整面板 LRU、均分容量/带宽、输出及超大块绕过等规则；容量和速率仍取自 chip 数值。',
    },
    'tpu_v4_reference': {
        'cmem_mode': '执行策略：tiled 启用完整 K 面板，bypass 旁路；实际模式还受容量约束。',
        'cmem_groups_mn': '执行策略：外层 CMEM 面板覆盖的 VMEM 输出块组数，不是硬件阵列数量。',
        'cmem_buffer_slots': '执行策略：请求的 CMEM 面板槽数，容量不足或无下一面板时可降为一个。',
    },
    'tsp': {
        'buffer_slots': '执行约束：当前必须为 1，表示一份 resident A/B/C 分配；待用权重缓冲另由 parameters.weight_buffer_bytes 限制。',
    },
    'tsp_cim': {
        'buffer_slots': '执行约束：当前必须为 1，表示一份 resident A/B/C 分配；不能用它设置 Macro context 数量。',
    },
}

for name, section in sections.items():
    path = ROOT/'configs/hardware'/f'{name}.json'
    config = {key:value for key,value in json.loads(path.read_text(encoding='utf-8')).items()
              if key != '_documentation'}
    assert config == baseline['configs'][name], f'Concurrent change in {path}; inspect before annotating'
    convention = {
        'value': '硬件数值输入：固定能力、容量、数量、服务率或延迟；包括 status=assumed 的显式代理，不是自动求值的公式。',
        'unit': '单位约束：随 value 一起校验；不能仅改单位标签而不换算数值。',
        'scope': '作用域约束：区分 chip/core/plane 等；随参数校验，不能只改标签来缩放硬件。',
        'status': '说明与依据并附校验：documented/measured/assumed/unknown；描述证据强度，不是开关。null 必须显式为 unknown，不触发隐藏默认值。',
        'source': '说明与依据：原始来源或模型政策，文字不会自动执行或改写 value。',
        ('source_version' if name in ('tsp', 'tsp_cim') else 'version'): '说明与依据：参数依据的文档/配置版本，不是本文件 schema_version。',
        'conditions': '说明与依据：数值取法、适用条件及消费边界；改变公式文字不会自动重算 value，应同步更新数值和实现。',
    }
    if name in ('tsp', 'tsp_cim'):
        convention['verification'] = '说明与依据：核验范围与限制；项目设计材料核验不等于硅片测量。'
    notes = {
        'purpose': '维护注释，采用合法 JSON 字段代替 // 注释。前三节区分硬件数值、执行策略、说明依据；configuration_control 单列会参与身份/格式校验或依赖加载的字段。此 _documentation 块为可选，只供阅读，解析时整体剔除，不进入计算、报告或运行时 reference_id；完整文件仍纳入来源台账校验。',
        'hardware_parameters': section['hardware_parameters'],
        'execution_policy': {'execution': '执行策略及其依据：约束/控制仿真行为，内部数值如槽数、分块和固定延迟也属于本类；其中 status/source/version/conditions 是说明与依据，详见 execution_fields。'},
        'descriptive_metadata': section['descriptive_metadata'],
        'configuration_control': section['configuration_control'],
        'parameter_fields': [f'{key}: {value}' for key,value in convention.items()],
        'execution_fields': {**execution_fields, **special_execution_fields[name]},
        'maintenance_rules': [
            '新增或移动真实字段时同步更新本注释的分类；不要只修改注释来改变模型行为。',
            '硬件参数的 value、unit、scope 与来源元数据一起维护；是否参与当前 GEMM 以该参数的 conditions 和实际消费路径为准。',
            '执行策略仅可使用解析器已有实现；修改策略后检查容量、动作计数和时间报告，不用库存数量直接缩放任务耗时。',
            '说明文字仍可能接受完整性校验或出现在来源报告中；只有 _documentation 是完全独立的阅读注释。',
            '注释只放在根层 _documentation 中；其他未知字段及参数/策略内部的额外字段仍严格拒绝。',
        ],
    }
    # Keep model inputs unchanged; organize top-level sections in the same order.
    order = [*notes['configuration_control'], *notes['hardware_parameters'],
             *notes['execution_policy'], *notes['descriptive_metadata']]
    assert len(order) == len(set(order)) and set(order) == set(config)
    result = {'_documentation':notes, **{key:config[key] for key in order}}
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(name, 'annotated; original input fields preserved')
