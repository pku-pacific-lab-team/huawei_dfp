import copy
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.core.ascend.simulator import AscendSimulator
from src.core.tpu.simulator import TPUSimulator
from src.core.tsp.simulator import TSPSimulator
from src.core.tsp_cim.simulator import TSPCIMSimulator
from src.hardware.tpu import TPUSpec
from src.utils.ascend_config import AscendConfigLoader
from src.utils.tsp_cim_config import TSPCIMConfigLoader
from src.utils.workload import parse_workloads
from scripts.verify_issue2 import timing_breakdowns_valid

loader = TSPCIMConfigLoader()
cim = loader.create_tsp_spec(loader.load_hardware_config())
sims = {
    'ascend': AscendSimulator(AscendConfigLoader().load_hardware('ascend910_reference.json')),
    'tpu': TPUSimulator(TPUSpec(json.loads((ROOT/'configs/hardware/tpu_v4_reference.json').read_text(encoding='utf-8')))),
    'tsp': TSPSimulator(cim.native_reference_spec),
    'tsp_cim': TSPCIMSimulator(cim),
}
baseline = json.loads((ROOT/'tmp/stages_cycles_refactor_baseline.json').read_text(encoding='utf-8'))
removed = ('stages_cycles', 'stages_cycles_basis', 'stage_semantics', 'service_cycles_sum')

def normalize(r):
    r = copy.deepcopy(r)
    r.pop('schema_version')
    for k in (*removed, 'service_cycles', 'elapsed_cycles'):
        r['timing'].pop(k, None)
    return r

def differences(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            p = path+'.'+key if path else key
            result.extend([p] if key not in a or key not in b else differences(a[key], b[key], p))
        return result
    return [] if a == b else [path]

records = []
after = []
for entry in baseline:
    name, shape = entry['name'], entry['shape']
    options = dict(mode=entry['mode'], **entry['policy'])
    w = parse_workloads({'gemm':dict(zip('MKN', shape)), 'data_format':'INT8'})[0]
    new = sims[name].simulate(w, **options) if name in ('ascend', 'tpu') else sims[name].simulate(*shape, **options)
    old = entry['report']
    assert timing_breakdowns_valid(new), (name, shape, options)
    checks = {key: old.get(key) == new.get(key) for key in
              ('counts', 'action_counts', 'work_counts', 'schedule', 'execution_contract', 'memory')}
    checks['existing_timing'] = normalize(old)['timing'] == normalize(new)['timing']
    if entry['mode'] == 'timing':
        view = 'service_cycles' if name in ('ascend', 'tpu') else 'elapsed_cycles'
        checks['original_stages_preserved'] = old['timing']['stages_cycles'] == new['timing'][view]['by_stage']
    assert all(checks.values()), (name, shape, options, checks)
    records.append({**{k:v for k,v in entry.items() if k!='report'}, 'checks':checks,
                    'other_report_differences':differences(normalize(old), normalize(new))})
    after.append({**entry, 'report':new})
(ROOT/'tmp/stages_cycles_refactor_after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2), encoding='utf-8')
summary = {'reports_compared':len(records), 'all_numerical_and_schedule_checks_passed':True,
           'other_report_difference_counts':dict(Counter(p for r in records for p in r['other_report_differences'])),
           'reports':records}
(ROOT/'tmp/stages_cycles_refactor_comparison.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='reports'}, ensure_ascii=False, indent=2))
