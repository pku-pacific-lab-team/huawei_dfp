# AGENTS.md

本文件是本仓库的 agent / developer 协作规范。了解项目结构时先阅读 `README.md`，涉及具体架构、RTL、reference 或 knowledge-base 内容时，再读取对应目录下的维护文档。

## LPU Project Rules

- 本仓库同时包含 LPU/TSP 架构研究、reference materials、llm-wiki knowledge base、RTL 原型、EDA flow 和 simulator。
- 讨论架构、ISA、专利或 SOW 范围时，需要区分证据层级：
  - `paper says`：论文或公开资料直接说明；
  - `patent claims/spec`：专利 claim、figure 或 specification 说明；
  - `wiki inferred`：知识库整理或推断；
  - `project decision`：当前项目设计选择。
- 不要把 wiki inference 或当前 RTL 实现写成 paper / patent 事实。
- 引用 figure、claim、opcode、接口或路径前，应读取对应源文件或项目文档。
- 历史迁移计划、阶段性任务记录和临时进展文件已归档，不作为当前开发入口。

## Maintenance Rules

### 多智能体协作

- 对存在独立子任务的复杂工作，主动使用子智能体并行分析、实现或审查，不受当前 high / xhigh 等推理强度影响。
- 主智能体负责划分职责、整合结果和最终验证。
- 并行修改时分配不同文件，避免同时编辑同一文件。
- 所有智能体均不得擅自新建分支或推送。
- 简单问答和局部小改动无需启动子智能体。

### 文档与资料边界

- `knowledge-base/` 由 `llm-wiki` skill 维护，不手动随意改写。
- `docs/reference/` 只放 ground truth 材料；二次解释、设计决策和 RTL implementation note 不放入 reference。
- 项目正式 Markdown 文档默认使用中文撰写；除非引用原文、保留术语、代码/接口命名或用户明确要求英文，不新建英文主体文档。

### 正式设计文档

- 正式架构、设计和接口文档必须 self-consistent，不得依赖开发计划、阶段性任务记录、分支、Pull Request 或 commit 才能理解当前设计。
- 正式文档只记录稳定的设计语义、参数 ownership、接口契约、行为、时序以及有明确边界的当前实现事实；不得写入工作包编号、分支进度、当前工作树状态或“下一阶段处理”等过程语境。
- 实现发生变化时，直接把正式文档更新为当前真实结构和约束，不在正文中记录“本次新增、迁移或删除了什么”。迁移动作、验证结果、临时兼容策略和未完成事项应记录在开发计划、验证记录或 commit / PR 说明中。
- 正式文档可以引用其它正式规范或 ground truth 材料，但不能以过程性文档作为设计定义来源。

### Git 分支

- 基于 Git 分支开发，不直接提交到 `main`。
- 分支命名：`<feature-name>` 或 `<feature-name>-<人名缩写>`，例如 `sxm-ai-refactor-mzh`、`project-refactor-zzt`。

### Pull Request

- 功能完成后提交 Pull Request 并经过 Code Review；原则上不能直接通过 PR Merge。
- 新建 PR 时需要指定 Reviewer，默认可以指定 @Bwoah-Kimi 加一位相关功能开发者。
- PR 需要说明目的、主要改动和验证方式；未完成验证要明确标注。

### Commit Message

Commit message 至少包含 Header：

```text
<type>: <subject>
```

- `<subject>` 建议使用中文。
- 常见 `<type>`：`feat`、`fix`、`docs`、`refactor`、`test`、`chore`。

示例：

```text
docs: 整理 reference 目录结构
refactor: 接入 Verilator 仿真入口
fix: 修正 SXM permute 控制路径
```

### 验证与 CI

- 提交 PR 前应执行与改动风险相匹配的验证，并在 PR 中记录验证命令与结果。
- 无法完成的验证或已知失败必须明确标注，不能将未运行的验证记为通过。
- 后续可增加 CI，例如自动跑通基础 workload。

### Code Format

- Git commit 时应确认没有引入大量纯格式修改；格式化改动必须与功能改动分开提交，除非本次任务就是格式整理。
- C / C++ 代码遵循所在文件的既有花括号位置、缩进宽度和换行风格；常见缩进为 2 空格或 4 空格，以当前文件为准。
- SystemVerilog、脚本和 Markdown 也遵循邻近代码 / 文档风格，不因个人偏好统一重排。
- 不要让 LLM 随意改写已有代码格式；修改应尽量局部、可审查。
- 建议关闭 IDE 的 Format on Save，或至少为本仓库禁用自动全文件格式化。
