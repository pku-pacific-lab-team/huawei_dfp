# LPU-HUAWEI-2012

本仓库用于 LPU / TSP 架构研究、RTL 原型开发、reference materials 管理、FPGA flow 维护和相关仿真工具开发。

## 版本定位

本分支是标准 RTL 基线：维护 ICU、MEM、Multiplier、MXM、VXM、SXM 和 SuperLane top 的 production RTL，以及 CVA6 SoC 集成。`soc.sv` 不实例化 LPU TSP 系统顶层。其他交付线使用独立分支维护。

## 目录入口

| 路径 | 内容 |
|------|------|
| `docs/hardware/` | 架构 / 微架构开发文档 |
| `docs/development/` | 开发阶段的任务计划与协作入口 |
| `docs/legacy/` | 历史设计稿、阶段计划与迁移记录索引 |
| `docs/public/` | 对外交付文档 |
| `docs/reference/` | 论文、专利和其它 ground truth 材料 |
| `knowledge-base/` | 由 `llm-wiki` 维护的 agent-facing 知识库 |
| `src/` | SystemVerilog RTL 正式入口，见 [RTL 说明](src/README.md) |
| `sim/` | RTL testbench、Verilator / VCS flow，见 [仿真流程](sim/README.md) |
| `fpga/` | Vivado / FPGA flow 入口，见 [FPGA flow](fpga/README.md) |
| `sxm-sim/` | SXM 独立功能仿真器 |
| `lpu-sim/` | LPU simulator 相关代码 |
| `scripts/` | TOP 依赖 filelist 生成器和项目辅助脚本，见 [脚本说明](scripts/README.md) |
| `automation/` | ASIC flow 异步调度、状态验证和 Agent 事件接口，见 [自动化说明](automation/README.md) |

## 仿真

- Verilator lint / run 在本地 Linux 或 WSL 执行；VCS 与 Verdi 在 EDA server 执行。
- 根目录 `Makefile` 通过 `TOP=<testbench>` 选择验证层级。
- active TB、DPI source、构建目录和波形恢复规则见 [RTL 仿真流程](sim/README.md)。

## Filelist

设计和 TB 仿真清单由 `scripts/generate_filelist.py` 从指定 TOP 的可达依赖生成：

```sh
make list-asic TOP=src/sl/lpu_sl_top.sv
make list-fpga TOP=src/soc.sv
make list-sim TOP=src/sl/lpu_sl_top.sv
make list-sim TOP=sim/tb/icu/tb_icu_frontend.sv
```

`TOP` 必须由 Make 命令行显式提供。`list-asic` 定义 `SYNTHESIS`，`list-fpga` 定义 `{SYNTHESIS, FPGA}`，`list-sim` 定义 `{SIM, VERILATOR}`。设计清单写入 `src/filelist.f` 或 `fpga/fpga_filelist.f`，TB 清单写入 `sim/build/<TB>/<TB>.f`。生成器排除 `src/vendor/`，传播 parameter override 并裁剪确定不可达的 constant-generate 分支。详细规则见 [脚本说明](scripts/README.md)。

## Genus Elaboration

```sh
make elab
make elab MODE=quick
make elab MODE=full
```

`MODE` 仅支持 `quick` 和 `full`，省略时为 `full`。两种模式使用相同的 technology library、MMMC、RTL、constraint、elaborate 和 uniquify 流程；`full` 随后执行 `check_timing_intent` 与 `check_design -all`。

## ASIC Flow 自动化

```sh
make flow-syn
make flow-status
make flow-inspect
make flow-smoke
```

执行模型、状态文件和环境要求见 [ASIC Flow 自动化](automation/README.md)。

## 开发约定

- Agent / developer 协作规范见 `AGENTS.md`。
- 架构事实、专利事实、项目设计决定和 RTL 实现说明需要区分来源层级。
- 正式 Markdown 文档默认使用中文撰写。
- 新开发基于 feature branch，并通过 Pull Request 合入；功能完成后需要 PR 和 Code Review。
- Commit message 遵循 `<type>: <subject>` 格式，`subject` 建议使用中文。
- 格式化改动应与功能改动分开提交；不要随意重排现有代码格式。
