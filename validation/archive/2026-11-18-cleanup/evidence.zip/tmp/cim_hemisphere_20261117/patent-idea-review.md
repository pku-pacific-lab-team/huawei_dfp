# 专利 Idea 评审胶片内容大纲（工作稿）

| 项 | 内容 |
|----|------|
| 版本 | v0.1（章节大纲，内容待填） |
| 日期 | 2026-11-03 |
| 状态 | 待逐节明确预期内容、素材与篇幅 |
| 用途 | 沉淀可转换为专利 Idea 评审胶片的内容；不直接产出 PPT |
| 结构依据 | 专利 Idea 评审模板截图目录及撰写指引 |
| 后续交付 | 内容完成后整理为可交付版本，移至 `docs/public/` |

> **参考材料边界**：`docs/public/cim_tsp_architecture_doc_20261006.md` 仅作为技术背景和历史方案参考，其中的任何架构参数均不视为本 Idea 的定稿依据。包括但不限于对称精度设置、固定 1/8 算力缩减等历史设定，均已在讨论中被重新审视或推翻，不构成本工作稿的约束。本工作稿中的 Macro、CIM core、Plane 组织、精度配置、算力与输出规格以当前讨论为准；若与参考文档不一致，以本工作稿为准，后续定稿时再统一相关架构描述。

## 1. IDEA合规检查

> 请按照如下检查项自检，无需填写自检结果，若自检不通过请勿提交 Idea，自检全部通过后方可提交 Idea。
>
> 提交时请勿删除本页。

Idea是否涉及在外部交流、技术合作、产品合作、采购等场景中从他人获取到的信息？

| 检查项类型 | 检查结果项 |
|---|---|
| 是否直接引用外来非公开信息 | 不涉及在外部交流、技术合作、产品合作、采购等场景中从他人获取到的外来非公开信息（下称“外非信息”），包括但不限于他人资料、仿真数据、测试结果、模型图、原理图、器件结构图、软件算法和其他非公开技术方案等，尤其注意不能引入带有他人标志或保密标识/水印的图片或资料 |
| 是否以外非信息为基础进行改进 | 不存在以外非信息的技术方案或技术构思为基础或主要设计参考而提出的改进方案，尤其注意也不能在背景技术中引入外非信息 |
| 是否涉及外网引入 | 不涉及从外部网站下载的有保密义务和/或使用限制的信息，如在线签署保密协议或者最终用户协议中限制分发或商业使用等；不涉及利用个人注册账号等途径从外部网站下载的非公开信息 |
| 职务成果归属 | 所涉及的发明方案100%属于发明人在华为的职务成果，不涉及前雇主/前研究机构/学校的职务成果 |
| 其他 | 使用的技术材料，不是来自于其他部门/其他产品线或关联公司，不包括来源不明的或无法确定是否属于外非信息的图片及资料；不涉及其他公司的私有协议、私有接口、私有标准等；不涉及通过对未上市产品或软件进行拆解、反编译、反汇编等技术手段获取到的信息 |
| 是否涉及出口管制 | 如果含有海外发明人，请确认：（a）技术没有达到出口管制规格，或者（b）虽已达到技术出口管制规格，但已获得相应的出口许可 |
| 发明人信息是否准确 | 列出的每个发明人都必须对本发明作出了实质性贡献 |

【待补充：本 Idea 的实际合规自检情况】

## 2. Idea产生的背景与现有技术

**撰写指引（完成 Idea 胶片后请删除）：**

简述问题的产生根源，与本发明最相关的现有技术，以及现有技术所存在的技术问题，让人信服本发明想要解决的问题是有价值的。（建议 2～3 页，具体情况视发明本身而定）

注意：

1. 现有技术的问题应该是**本发明所能解决的问题**，请勿提供本发明无法解决的问题；
2. 现有技术存在的问题应该是由于其技术方案的不足而带来的**客观存在的技术问题**，比如可靠性低、传输时延长、系统资源浪费、成本高等，而不能仅仅只是一种主观感受，比如用户体验差等。

现有的技术：数据流架构的芯片，以 Groq LPU 为代表，同样包括 Sambanova 等芯片架构，相比于传统 GPU 体现了 xx 的优势 【Citation，参考 Groq Hot Chips】。
特别是在端侧应用场景中，满足了用户对于相应低延迟的需求。

进一步，SRAM CIM 架构有其优势 xxx 【参考项目 PPT】，能够与 LPU 数据流架构结合，进一步降低计算延迟，提升计算能效。

在这样的技术目标下（在 LPU 架构中引入 SRAM CIM），现有技术存在一些不足。

首先是：LPU 架构中，矩阵计算模块（MXM）支持 INT8/FP16 两种精度，而随着各类 AI 应用在边缘端的部署需求（片上 SRAM 容量的限制），原版的 LPU MXM 对于低精度支持较差 【这里需要数据支撑，完整的评估可以在第五章技术效果中呈现，但是这里应该有数据体现，在现有的 MXM 版本下，如果硬要支持 INT1/INT2/INT4，会有多大的 overhead，你从 RTL 层级和实现，先判断这个是否成立，然后后面可以做 ASIC 综合量化证明这件事情】

其次是，现有的 SRAM CIM 没法很好支持浮点计算，需要依赖 pre-processing 和 post-processing 做块浮点（现有技术已定位：ReDCIM, JSSC 2023——指数预对齐 + 存内整数尾数 MAC + 指数回赋后处理，论文已归档至 `docs/reference/papers/`，机制梳理与我们方案的对照见 [bfp-cim-int-fp.md](bfp-cim-int-fp.md)，可直接引用的表述见该文 §8）。在这样的情况下，如何在 LPU 数据流架构中支持 SRAM CIM 需要额外的设计。【LPU 有 NIM 相关的专利，阿里有一个向量单元浮点计算相关的专利，我们本质是对这个的缝合，并且兼容 CIM bit-serial 输入和 LPU 确定性数据流】

### 2.1 Baseline 低精度浮点支持的开销结构

Baseline MXM 的 FP16 路径是以 INT8 乘法器为核心、靠分量拆分拼接 mantissa，再叠加浮点辅助逻辑。RTL 实现可定位为四层开销：

| 层次 | RTL 模块 | 作用 | 随 mantissa 变窄是否缩减 |
|---|---|---|---|
| 分类与特殊值 | `src/mult/mult_fp16_decode.sv` | FP16 的 NaN/Inf/zero/subnormal 判定，有效指数计算 | **否**——位宽固定，开销不变 |
| 分量乘积与归约 | `src/mult/mult_fp16_decode.sv` + `src/mult/mult_fp16_component_reduce.sv` | 11-bit significand 拆为 8+3 两段，4 个 8×8 乘法器做 4 个分量乘积，再移位相加 | **非线性**——交叉项数量取决于分段方式 |
| 格式转换 | `src/mult/mult_fp16_product_to_e32m32.sv` | 定点乘积转宽指数（e32m32）格式 | **否**——转换逻辑固定 |
| 精度输出 | `src/mult/mult_fp_e32m32_to_fp32.sv` | 宽格式舍入并窄化为 FP32 | **否**——舍入逻辑固定 |

FP16 的 mantissa 为 11 bit，不能整除进 8-bit 乘法器，被拆成 8+3 两段，产生 2 个交叉项。按同样拆分逻辑推到 FP8/FP4：

| 格式 | Mantissa | 低位宽乘法器 | 分段 | 交叉项 | 固定格式逻辑 |
|---|---|---|---|---|---|
| FP16 | 11 bit | 8×8（4 个） | 2 段（8+3） | 2 个 | 不变 |
| FP8 E4M3 | 4 bit | 4×4 | 1 段 | 0 个 | **不变** |
| FP4 E2M1 | 3 bit | 2×2 | 2 段（2+1） | 2 个 | **不变** |

**问题在于：mantissa 变窄时，乘法器位宽下降，但分量拆分与固定格式逻辑并不同比下降。**分类、格式转换、舍入的开销近似不变，在更小的格式上被摊得更薄、占单位有效算力的比例反而上升。

**ASIC 面积结果（任务 1，已回填）**：以下为 Cadence Genus 实际综合的 Cell Area，口径为**单个 MML 内四个 MME 的乘积生成前端**，不包含完整 MML/Supercell、dot/PSUM 或 collector 的 FP32 窄化。完整数据与追溯信息见 [asic-area-evaluation.md](asic-area-evaluation.md)。

| 集成配置 | 乘法器阵列 | 浮点辅助逻辑 | 整数辅助逻辑 | 顶层/边界差额 | 总 Cell Area | 浮点辅助占比 |
|---|---:|---:|---:|---:|---:|---:|
| Baseline：INT8 / FP16 | 1,996.628 | 2,137.633 | 798.327 | 596.570 | **5,529.158 µm²** | 38.661% |
| 加入 FP8：INT8 / FP8 / FP16 | 3,547.275 | 7,826.412 | 810.750 | 880.386 | **13,064.823 µm²** | 59.904% |
| 加入 FP4/INT4：全格式 | 5,083.435 | 9,878.888 | 3,102.069 | 592.220 | **18,656.612 µm²** | 52.951% |

对应的累计扩展面积：

| 扩展步骤 | 总面积增量 | 浮点辅助逻辑增量 |
|---|---:|---:|
| Baseline → +FP8 | **+7,535.665 µm²** | +5,688.779 µm² |
| Baseline → 全格式 | **+13,127.454 µm²** | +7,741.255 µm² |

[多格式乘积生成路径面积堆叠图](assets/asic-area-evaluation-task1.png)

结果支持以下判断：低精度浮点扩展的主要开销来自**浮点辅助逻辑、格式转换和归约组织的增加**，而不是仅来自低位宽乘法器本体。FP4 的总面积在独立路径模型中低于 FP8，是具体格式位宽和综合优化的结果，不能据此写成所有实现都满足单调变化。

评估边界：不包含 CIM Macro，不讨论功耗、Fmax 或布局布线；评估 RTL 只用于形成可综合的面积模型，不作为功能正确性或生产实现验收内容。

这一段与 §3 的 CIM 方案形成对照：CIM 原生只处理定点，浮点走 NIM 的 block-fp 预对齐，把指数处理从逐元素移到组级共享，固定成本被一组元素摊销。

## 3. 本Idea的技术方案

技术方案继承两个技术前提：LPU 确定性数据流架构（功能切片、stream 数据通路、编译期静态调度）和 SRAM CIM 标准宏单元设计。在此基础上，本 Idea 的核心内容是以 SRAM CIM 阵列等算力替换 baseline MXM，并围绕多精度计算重构阵列组织与数据通路。

替换的基本事实是：CIM 的 bit-serial 激活输入使单个 Macro 的吞吐低于字节并行的 Supercell，等算力通过增加 Macro 数量补偿（INT8 下 4 个 Macro 对应 1 个 Supercell），形成五级阵列层级：Macro → Core → Cluster → Plane → MXM（§3.2）。
三个新增层级各有职责：Core（4 Macro）是 N 分片计算与错峰启动的单位；Cluster（5 Core）是独立的 activation 广播域，即任务调度单位；Plane 保持 baseline 组织，承担 K=320 累加与 collector。

围绕这一组织，技术方案分五个部分：

1. **Macro 内部多精度**（§3.1）：16 column 按权重精度逻辑切分，共享加法器 + MUX/gating 重构归约车道，属于技术前提层，不作为保护点；
2. **等算力组织与结果通路**（§3.2）：CIM Core/Cluster/Plane 层级、192 B 输出上限下的 collector、错峰启动的阶梯结果时序、四 Cluster 广播域与单 NIM 多通道交错写回；
3. **LW 带宽与装载**（§3.3）：N 切分下装载开销与 baseline 持平（通用式 2.5w/M），LW 按 2 Core/拍轮转装载，160 拍写满一套 context，与计算重叠的条件与 baseline 相同；
4. **NIM 微架构**（§3.4）：每 Plane 一个多通道 NIM，激活预对齐（每 tile 每拍一组、四拍轮转）、64 lane FP32 转换、静态写回；FP/INT 统一走整数阵列 + 组级指数通路；
5. **权重 context 切换**（§3.5）：context 为 Macro 级 SRAM（4 套），就绪判定为 Cluster 级，IW 以 Core 级滚动切换，LW/就绪/IW/ACC 四操作粒度各自跟随底层结构。

贯穿全部五个部分的一条主线是：CIM 引入的每一项结构差异（bit-serial II、列打包 N 扩展、错峰结果、SRAM 权重驻留）都被转换为静态可调度的组织机制，而非运行时管理——整个方案不引入动态仲裁、运行时分配器或不确定延迟。

### 3.1 CIM Macro 内部结构（技术前提层）

> 本节描述 Macro 内部的既有设计，作为整体方案的技术前提，不作为技术保护点。学术论文已有同类多精度 CIM 阵列架构，这里只是定义清楚我们的具体实现形态。【学术架构引用：ReDCIM, JSSC 2023（§VI 层级可重构存内累加器，以最低精度 8b 加法器为基准，向上融合支持 16/24b）；同类还有 Column-MAC（ESSCIRC'19，1–16b bit-serial）、UNPU（ISSCC'18，1–16b 可变权重位宽）。我们与 ReDCIM 的差异：以 INT16 为基准向下切分 + MUX/gating 共享加法树，融合对象与算力口径均不同，对照见 [bfp-cim-int-fp.md](bfp-cim-int-fp.md) §4.3】

**Macro 层级与存储组织。**单个 CIM Macro 由若干套 weight context 组成（示例 4 套，随 ASIC 面积指标调整）。每套 context 的组织为 `16 bank × 16 sub-array × 16 column`，容量 512 Byte，恰好容纳一个 `K=16 × N=16` 的 INT16 权重 tile。层级的语义为：bank 对应 N 方向的一个输出位置，sub-array 对应 K 方向的一个激活/权重元素对，column 保存一个权重的位。

**每拍计算原语。**在最高精度形态下，sub-array 的 16 个 column 共同保存一个 16-bit 权重；激活值以 bit-serial 方式逐拍输入，每拍执行 `W[16bit] × A[1bit]`，经 16 拍移位累加完成完整的 INT16×INT16 运算。即每拍原生原语是 INT16×INT1，完整运算由多拍位权累加形成。

**低精度下的 column 逻辑切分。**权重为 INT8/INT4 时，16 个 column 物理不变，逻辑上切分为多个权重元素：

| 权重精度 | Column 逻辑分组 | 每个 sub-array 的 N 方向元素数 |
|---|---|---:|
| INT16 | C1–C16 保存 1 个权重 | 1 |
| INT8 | C1–C8、C9–C16 各保存 1 个权重 | 2 |
| INT4 | C1–C4、C5–C8、C9–C12、C13–C16 各保存 1 个权重 | 4 |

**共享加法器 + MUX/gating 的 Adder Tree。**每个 sub-array 输出向量 `OF_i[N-1:0]`；bank 内按 N 方向并行布置 K 方向归约车道，每条车道执行 `Y[j] = Σ_i OF_i[j]`（i=1..16，4 级二叉加法）。支持可变权重元素的方式是**跨精度模式共享同一批物理加法器节点，通过 MUX 重构归约分组、通过 gating 关闭未使用的输出车道**，而不是为每种精度复制一套完整加法树：

```text
16 column 本地计算结果
  → 按精度完成权重分组
  → MUX 选择各组进入哪条 K 归约车道
  → 共享加法器节点完成归约
  → gating 关闭未使用车道
  → 有效车道进入 Shift-Accumulator
```

- INT16：启用 1 条 N 归约车道，其余车道 gating；
- INT8：启用 2 条；INT4：启用 4 条。

**峰值车道约束。**"共享"指不同精度模式复用同一批物理加法器，不是同一模式内对多个 N 输出做时分复用。为维持 INT4 峰值（每拍 4 条归约车道同时工作），物理加法器节点需按峰值车道数配置；若用一条树轮流算 4 路输出，会改变 II 与峰值吞吐。

**各模式的 Macro 计算规格。**权重位宽 w 与激活数值位宽 a 是**两个独立配置**：w ∈ {16, 8, 4} 由 column 逻辑分组决定；a 为激活数值位宽，II 为有效调度间隔。整型 INT4/8/16 下 II=a；FP4 另行定为 a=3、II=4。每拍计算原语恒为 `W[w] × A[1]`。下表以对称整型配置为例：

| 配置（w × a） | sub-array 权重元素数 16/w | Macro 数学边界（N = 256/w） | 有效调度 II | 每路结果位宽 | Macro 结果总量 | 原生 MAC/cycle = 4096/(w·II) | 等效 INT8×INT8 MAC/cycle |
|---|---:|---|---:|---:|---:|---:|---:|
| INT16 × INT16 | 1 | `K=16 × N=16` | 16 拍 | 64 bit | 128 Byte | 16 | 64 |
| INT8 × INT8 | 2 | `K=16 × N=32` | 8 拍 | 32 bit | 128 Byte | 64 | 64 |
| INT4 × INT4 | 4 | `K=16 × N=64` | 4 拍 | 16 bit | 128 Byte | 256 | 64 |

算力口径说明：

- **权重与激活精度独立**：w 由 column 分组配置，a 为激活数值位宽，II 为有效调度间隔；本表整型配置均取 II=a。"1-bit"是每拍输入切片粒度，不是操作数精度；非对称组合同样合法，例如 W4×A8（N=64、II=8）原生吞吐 = 4096/(4×8) = 128 MAC/cycle。
- **原生 MAC/cycle = 4096/(w·II)**：`K=16 × N=256/w ÷ II`，按完整 MAC 计。
- **等效 INT8×INT8 MAC = 原生 × (w·a)/64 ≡ 64，与 (w,a) 组合无关**：位宽折算恰好抵消精度组合的差异，即一个 Macro 恒为 64 等效 INT8 MAC/cycle 的计算引擎。
- **与基线对齐**：基线半区 INT8 204,800 与 FP16 51,200（×4 折算）同为 204,800 等效；当前 CIM-MXM 半区 400 Macro 恒为 25,600 等效。1/8 的差距在任何精度组合下都成立，这正是后续以多 Plane 补偿峰值算力的量化基础。

三种精度共用同一份 512 Byte 权重映像，只改变 N 方向解释与 Adder Tree 车道重构；Shift-Accumulator 负责激活位权累加，与 K 方向归约相互独立。

【待补：Macro 内部结构配图（层级 + column 逻辑切分 + 共享 Adder Tree 三合一）】

### 3.2 CIM Core、CIM Cluster 与等算力 Plane 组织（纯整型）

本节先确定等算力 CIM-MXM 的 Macro 数量与阵列组织，作为后续 LW 带宽推算的前提。定义：**一个 CIM Core 由 4 个 CIM Macro 组成，一个 CIM Cluster 由 5 个 CIM Core 组成**；CIM Cluster 是独立的 activation 广播域。专利 idea 中不再沿用“逻辑 Supercell”的名称。本节只讨论纯整型计算，不涉及 BFP 或 NIM 的内部实现。

统一采用以下层级：

```text
CIM-MXM（每半区 2 个 Plane）
└── CIM Plane
    ├── 20 条 SuperLane
    └── 每条 SuperLane 包含 4 个 CIM Cluster
        └── CIM Cluster = 5 个 CIM Core
            └── CIM Core = 4 个 CIM Macro
                └── CIM Macro（定义不变）
```

| 层级 | 组成 | 职责 |
|---|---|---|
| CIM Macro | 现有 SRAM CIM 单元 | 权重存储、位级乘加和本地读出 |
| CIM Core | 4 Macro | N 切分和等效 baseline Supercell 的计算 |
| CIM Cluster | 5 Core | 独立 activation、权重、任务、输出及 NIM 逻辑通道 |
| CIM Plane | 每 SL 4 Cluster，共 20 SL | K=320 累加、LW、collector 和单个多通道 NIM |
| CIM-MXM | 2 Plane | 保持 baseline 的 Plane 级组织 |

计数时需要区分两个维度：一个 Plane 有 `20 SuperLane × 4 Cluster × 5 Core = 400 Core`；而单任务 N 只由**每条 SuperLane 上的一个 Cluster（5 Core）**决定，20 条 SuperLane 在 K 方向累加，不再增加 N。

#### 3.2.1 等算力替换关系

INT8 下，一个 baseline Supercell 为 256 MAC/cycle，一个 CIM Macro 为 64 MAC/cycle，因此：

```text
1 CIM core = 4 CIM Macro = 256 MAC/cycle
```

保留 baseline 的 **2 个 Plane** 和每个 Plane 的 **20 × 20 个 core 位置**，得到：

```text
CIM-MXM（每半区）
= 2 Plane × 20 SuperLane × 20 CIM core × 4 Macro
= 3,200 Macro
= 204,800 MAC/cycle（INT8 峰值）
```

| 项 | Baseline MXM | 等算力 CIM-MXM |
|---|---:|---:|
| Plane / 半区 | 2 | 2 |
| SuperLane / Plane | 20 | 20 |
| 逻辑计算位置 / Plane | 20 × 20 Supercell | 20 × 20 CIM core |
| 每个计算位置的物理单元 | 1 Supercell | 4 Macro |
| 物理阵列 / Plane | 20 × 20 Supercell | **20 × 80 Macro** |
| 计算单元总数 / 半区 | 800 Supercell | 3,200 Macro |
| K / Plane | 320 | 320 |
| INT8 峰值 / 半区 | 204,800 MAC/cycle | 204,800 MAC/cycle |

#### 3.2.2 Core 内的数据组织与 PSUM

一个 CIM core 内的 4 个 Macro 按 N 方向并列：

```text
CIM core[c]
  = Macro[4c+0] + Macro[4c+1] + Macro[4c+2] + Macro[4c+3]
```

- 4 个 Macro 接收同一份 bit-serial activation；
- 各 Macro 保存该 core 下**不同的 N 分片**，不复制权重；
- 每个 Macro 的部分和沿 20 条 SuperLane 独立向上累加；
- core 内 4 路输出属于不同 N，不做彼此相加；K 方向仍为 `20 SuperLane × 16 = 320`。

因此，原有跨 SuperLane 的 K 累加可以保留，但每个 core 位置从一路 PSUM 扩为四路独立 PSUM。浮点模式下，**各输出通道分别配置对阶累加单元，mantissa 累加器规格统一为 64 bit**；每次对阶累加的目标是在 1 拍内完成并传递给下一 Core，以满足相邻 Core 启动 II=1 的交接要求，**该时序目标需通过 ASIC 综合验证，验证前不视为已保证**。整数模式旁路对阶逻辑。

**EI/EW 分发路径（定版）**：EI 随对应 activation 组经原有广播通路进入 Core，由 Core 内各输出通道共享；EW 由 NIM 在独立 capture 窗口分发并写入各 Core 的本地 EW buffer。首次使用前由编译器保证元数据已就绪，不在本文展开具体时序。

需要注意，这一结构保持的是等算力、Plane 数和 core 位置，不是 N 粒度不变。INT8 下每个 core 从 baseline 的 N=16 扩为 `4 × 32 = 128`，每个 CIM Plane 的 N 从 320 扩为 2,560；负载映射需要按更宽的 N 阵列重新组织。

#### 3.2.3 Macro 输出上限改为 192 B 后的影响

Macro 的输出不再按固定 128 B 假设，当前设计上限为 **192 B/Macro**。该上限只改变结果收集与排空，不改变算力、N 切分、K 累加或 LW 带宽结论。

设某模式实际输出为 `B_m ≤ 192 B`、激活 II 为 `a`：

```text
单 core 平均输出速率 = 4·B_m / a  Byte/cycle
两个 Plane 合计     = 8·B_m / a  Byte/cycle
```

若按 192 B 上限配置接口，并沿用 INT8 的 II=8：

| 层级 | 一次操作的输出 | 平均输出速率 |
|---|---:|---:|
| Macro | 192 B / 8 拍 | 24 B/cycle |
| CIM core（4 Macro） | **768 B / 8 拍** | 96 B/cycle |
| 两个 Plane 的同一 core | **1,536 B / 8 拍** | **192 B/cycle** |
| 一个 Plane 的完整 N 输出（每 SL 20 core） | **15,360 B / 8 拍** | 1,920 B/cycle |
| 两个 Plane | **30,720 B / 8 拍** | **3,840 B/cycle** |

相比此前按 128 B/Macro 的估算，输出侧上限提高 **50%**。192 B 是接口上限，不代表所有精度模式都产生相同字节数；实际持续速率仍需由 `B_m` 与该模式的 II 共同计算。

#### 3.2.4 对 Plane 内部 collector 的要求

1. **接口按模式定义**：不能把 128 B 当成固定 Macro 片段，需支持最大 192 B 的 Macro 输出。
2. **Core 级分组收集**：每轮最多接收 `4 × 192 = 768 B`，四路按独立 N 分片保持顺序。
3. **内部缓冲**：若需暂存一整波结果，一个 Plane 的最大规模为 `20 × 768 B = 15 KiB`，两个 Plane 为 30 KiB；实际是否需要全波暂存由 collector 的排空方式决定。
4. **时间整形**：结果按 II 窗口突发到达，collector 必须在固定时序内完成分组和排空，不能直接沿用 baseline 的单拍固定 128 B 片段假设。

#### 3.2.5 Core 启动与结果排出的阶梯时序

Baseline 文档中的结果转置只解决 `core c → writer SuperLane 19-c` 的空间映射，不能直接使用：同一 SuperLane 内的 20 个 core 若同时启动计算，就会在转置后形成集中的结果波前，无法与后续 ICU 指令沿 SuperLane 方向逐拍传播的节奏对齐。

在未拆分的单一广播域中，本设计在单个 SuperLane 内采用**相邻 core 隔 1 拍启动**的阶梯流水。令 core 位置为 `c = 0..19`：

```text
core[c] 的计算启动时刻 = T_start + c
```

20 个 core 的启动时间跨度为 19 拍（时间差约 20 拍），每拍只有一个 core 启动。固定的计算延迟只整体平移该阶梯，不改变相邻 core 的间隔：

```text
core[c] 的结果到达边界 = T_start + c + L_compute
```

于是结果也按 `c = 0, 1, ..., 19` 的顺序每拍到达一个 core。转置网络继续负责空间重映射，而**启动间隔负责把并行阵列转换为阶梯结果流**。这里约束的是 core 间启动间隔为 1 拍，不是 bit-serial 激活的内部 II；后者仍由激活位宽决定。

后续处理采用同样的传播节奏：

- NIM（或 SXM/MEM）的处理命令沿 SuperLane 方向每拍前进一个位置；
- 第一个 core 的结果先到达，后续命令可先处理最底部 core 的 `4 × 192 B` 数据；
- 下一拍，第二个 SuperLane 的结果与相应处理命令同时到达；
- 指令传播间隔与 core 启动/结果到达间隔均为 1，因而不需要额外的动态等待或仲裁。

Plane 0/1 各自保留独立结果队列和 writer 时序；同一 `{SR boundary, lane, stream, cycle}` 仍只允许一个有效 writer。该设计只规定计算与结果流水，不落到具体指令集编码。NIM 的数值转换及后续 BFP 处理在数据按此阶梯到达后执行，不改变 Plane 内的时序关系。

**本节结论：**等算力 Plane 组织固定为“2 Plane × 20×20 CIM core × 4 Macro”；阵列计算与 LW 带宽不因 192 B 输出上限而改变。结果转置由空间映射与 core 错峰启动共同完成，Plane 内已经形成与 ICU 跨 SuperLane 传播对齐的阶梯结果流；NIM 侧如何处理不在本节展开。

#### 3.2.6 CIM Cluster 划分与单 NIM 多通道写回

为降低单个计算任务的 N 粒度，每条 SuperLane 上的 20 个 Core 划分为 **4 个 CIM Cluster**，每个 Cluster 包含 5 个 Core，并分别形成独立的 activation 广播域：

```text
CL0 = core 0–4
CL1 = core 5–9
CL2 = core 10–14
CL3 = core 15–19
```

每个 Cluster 执行一个独立任务，具有独立的 activation、权重和输出；不同任务的权重不是复制关系，因此不增加重复权重或重复 LW 数据。K 仍为 320，单个 Cluster 任务的 N 粒度为：

| 权重精度 | 每 Macro N | 每个 CIM Cluster（5 Core × 4 Macro）N |
|---|---:|---:|
| INT16 | 16 | **320** |
| INT8 | 32 | **640** |
| INT4 | 64 | **1,280** |

与未拆分时整个 Plane 的 N=1,280/2,560/5,120 相比，单任务 N 均降为四分之一。两个 Plane 采用相同的 Cluster 划分，最多同时承载 8 个独立任务。

**Activation 与计算流水。**每个 Plane 的每条 SuperLane 由一条全 Plane 广播通路改为四条独立广播通路；这里增加的是独立 activation 通路数，不是同一份 activation 的重复广播。每个 Cluster 内部按 §3.2.5 让 5 个 Core 逐拍错峰启动，形成 5 拍局部启动阶梯；Cluster 间不进行 PSUM 归并。

**NIM 配置。**每个 Plane 仍只配置 **一个物理 NIM**，但其内部设置 **4 套逻辑处理通道/上下文**，分别对应 CL0–CL3。各通道保存本 Cluster 任务的精度配置、后续 BFP 参数和输出配置，避免要求四个独立任务共享一套数值处理状态。NIM 的具体数值实现及吞吐评估留到 BFP 章节，本节只确定通道划分和写回时序。

**结果规模。**按 192 B/Macro 上限：

```text
每个 CIM Cluster 一轮结果 = 5 Core × 4 Macro × 192 B = 3,840 B
四个 CIM Cluster 合计    = 4 × 3,840 B = 15,360 B
```

结果总量与未拆分 Plane 相同，不增加 Macro 输出数据；变化只是由一股结果流变成四股独立结果流。

**固定交错写回。**四个 Cluster 的结果由每 Plane 的多通道 NIM 按静态交错表接收，不采用运行时仲裁。例如四个 Cluster 对齐启动时，可以按以下顺序排空：

```text
CL0.core0 → CL1.core0 → CL2.core0 → CL3.core0
→ CL0.core1 → CL1.core1 → CL2.core1 → CL3.core1
→ ... → CL0.core4 → CL1.core4 → CL2.core4 → CL3.core4
```

这样每个 Plane 每拍最多向 NIM 交付一个 Core 的最多 `4 × 192 B = 768 B` 结果，四个逻辑通道按固定顺序轮流处理各自任务；Plane 0/1 继续使用各自独立的写回时序。上例用于说明固定交错关系，具体 slot 表可随实现调整，但必须在编译期确定并满足唯一 writer 约束。

**本节结论：**每 SL 4 个 CIM Cluster 将 INT4 单任务 N 降至 1,280，且不复制权重、不增加 Macro 结果总量。代价是每 SL 四条 activation 通路、一个 NIM 内四套逻辑上下文，以及一张固定的 Cluster 交错写回表。

### 3.3 多 Plane 组合的带宽约束（核心问题）

在 §3.2 确定的等算力阵列组织下，本节推导 baseline 与 CIM-MXM 的 LW 带宽需求。

#### 3.3.1 SRF 单向带宽

```text
单条 SuperLane：16 lane × 32 stream × 8 bit = 4,096 bit/cycle = 512 Byte/cycle
整片 20 条：    20 × 512 Byte = 10,240 Byte/cycle = 81,920 bit/cycle
```

这是**一个传播方向**的总量；另一方向独立。LW 与 ABC 都在同一方向的 stream 上排队，不能互相借用。

#### 3.3.2 Baseline 的 LW 需求正好吃满带宽

Baseline 一个 Supercell 的一套权重为 `16 × 16 = 256 Byte`，恰好占 **16 条 stream**（16 × 16 Byte）。

```text
单个 Plane 一行权重 = 20 Supercell × 256 Byte = 5,120 Byte
两个 Plane 同时装载 = 2 × 256 Byte/cycle = 512 Byte/cycle = 32 stream = 100% 单向带宽
```

即：**一个 Plane 的 LW 占 16 条 stream，两个 Plane 合起来 32 条，刚好用尽单向 512 Byte/cycle。**baseline 的 SRF 带宽实际上是按“2 个 Plane 的 LW”定尺寸的，没有预留余量。

#### 3.3.3 扩阵列的前提：N 切分而非复制

按 §3.2，等算力 CIM-MXM 由 **2 个 Plane、每 Plane 20 SL × 4 CIM Cluster（合计 400 Core、1,600 Macro；两个 Plane 合计 3,200 Macro）**组成。扩展到该规模的方式决定带宽后果，必须先区分：

| 扩展方式 | 权重数据 | 激活数据 | 带宽后果 |
|---|---|---|---|
| **复制式**（每阵列都算完整 N） | 同一份权重复制 8 份 | 同一份激活广播 8 份 | 权重带宽 **8×**，站不住 |
| **N 切分**（各阵列负责不同 N 分片） | 8 份**互不重复**的分片 | 同一份激活广播 8 份 | 权重带宽与 baseline **相同** |

本节按 **N 切分**推导，即各 Macro 合计覆盖的权重与 baseline 两 Plane 相同，不做复制。

#### 3.3.4 等算力下装载开销的通用式

INT8 下 4 个 CIM Macro 相当于 1 个 baseline Supercell（64 vs 256 MAC/cycle），§3.2 的 2 个 Plane（3,200 Macro）对应 baseline 的 800 Supercell。逐项对齐：

| 项 | Baseline（每 SuperLane） | CIM 2 Plane（每 SuperLane） |
|---|---:|---:|
| 单元权重 | 20 Supercell/Plane × 256 B × 2 | 20 core × 4 Macro/core × 512 B × 2 Plane |
| 一次完整装载 | **10,240 B** | **81,920 B** |
| 装载时间（512 B/cycle） | **20 拍** | **160 拍** |
| 计算窗口 | M 拍（II=1） | 8M 拍（II=8） |
| **装载占比** | **20/M** | **20/M** |

**两者装载占比完全相同。**比值不变的原因是：CIM 的总权重字节是 baseline 的 8 倍，但同一份权重服务的计算窗口也是 8 倍（II=8），两者相消。

**推广到任意精度组合（w = 权重位宽，a = 激活位宽）：**

```text
单个 Macro 算力      = 4096/(w·a) MAC/cycle
等算力所需份数 N     = w·a/8（相对 20×20 Macro 基准阵列，不是物理 Plane 数）
每阵列一行装载       = 20 Macro × 512 B = 10,240 B，满带宽时 20 拍
N 份基准阵列合计装载 = 20N 拍
计算窗口             = a·M 拍（II = a）
装载占比             = 20N/(a·M) = 2.5w/M
```

**装载带宽只由权重位宽决定，与激活位宽无关**；本质是每个 MAC 消耗的权重字节 = `w/8`。激活位宽只通过 II 影响窗口长度，而它同时改变等算力所需的阵列数，两者恰好相消。

| 配置（w × a） | 等效基准阵列份数 N | II | 装载占比 | 相对 baseline |
|---|---:|---:|---:|---:|
| INT8 × INT8 | 8 | 8 | 20/M | 1× |
| INT8 × INT4 | 4 | 4 | 20/M | 1× |
| INT4 × INT8 | 4 | 8 | 10/M | **0.5×** |
| INT4 × INT4 | 2 | 4 | 10/M | **0.5×** |
| INT16 × INT16 | 32 | 16 | 40/M | **2×** |

即：**INT8 权重与 baseline 持平，低精度权重（INT4）反而减半，高精度权重（INT16）翻倍。**

**结论：N 切分下，INT8 与 INT4 权重都不存在权重带宽造成的 starvation；只有在 INT16 权重下装载开销是 baseline 的 2 倍。**

前提是装载可用满 512 B/cycle。按 §3.1 的 word line 定义（`2L` Byte/次）：

| L | 一条 word line | 占 stream | 取满 512 B 所需并发 Macro |
|---:|---:|---:|---:|
| 16（全 N） | 32 B | 2 | 16（每阵列 2 个） |
| 8 | 16 B | 1 | 32（每阵列 4 个） |

若只做到 8 个 Macro 并发（每阵列 1 个），装载只能用 256 B/cycle，占比翻倍。**因此“16 并发、L=16”是取满带宽的最小配置。**

**LW 的 Core 轮转（定版）。**“每拍写哪 8 个 Macro”按 Core 层级定义：**每周期每 Plane 装载 2 个 CIM Core**，每个 Core 的 4 个 Macro 各写入一条 word line：

```text
2 Core × 4 Macro × 32 B = 256 B/cycle/Plane（与 16 stream 捕获一致）
两个 Plane = 4 Core/拍 = 16 条 word line
```

- **轮转方式**：按 Core 序号简单轮转（Core 0,1 → 2,3 → … → 18,19），10 拍完成一轮全行扫描，每个 Macro 写入 1 条 word line；不做 Cluster 分组对齐。
- **word line 推进**：外层循环为 word line、内层为 Core——每轮 10 拍扫描让全部 20 Core 的每个 Macro 各推进 1 条 word line；16 轮扫描（160 拍）写满一套完整 context。
- 由此每条 SuperLane 行的装载总时间 160 拍，与上表一致；就绪状态（按 Cluster × context 的 20 个 Macro × 16 条 word line 累积）在轮转中自然推进，Cluster 边界落在半拍上不影响判定。

#### 3.3.5 本节结论与遗留问题

**带宽不是 CIM 相对 baseline 的退化项。**在 N 切分 + 满带宽装载的条件下，INT8/INT4 权重的装载占比与 baseline 持平或更低，激活字节反而因列打包低于 baseline。原先“8 倍算力导致 MXM 饿死”的判断不成立，该说法只在复制式扩展下有效。

由此暴露的真正约束转移到别处：

**已关闭：阵列 N 粒度过大。**每条 SuperLane 划分为 4 个 CIM Cluster，每个 Cluster 包含 5 个 Core，单任务 N 降为 INT16=320、INT8=640、INT4=1,280；不同任务使用各自权重，不构成复制。每 Plane 只配置一个多通道 NIM，以四套逻辑上下文和固定交错表完成四个 Cluster 的结果写回，详见 §3.2.6。

**已关闭：Plane 内 PSUM 结果写回时序。**单个 SuperLane 内的 core 按每拍一个位置错峰启动，结果按相同顺序逐拍到达；转置负责空间重映射，错峰启动负责形成与 ICU 跨 SuperLane command wave 一致的阶梯结果流，详见 §3.2.5。NIM 接收后的数值转换与 BFP 处理另章讨论，不属于 Plane 内遗留问题。

**已关闭：M 的实际取值范围。**M 由目标负载和编译器映射决定，不作为当前阵列结构的待决问题。§3.3.4 已给出装载占比与 M 的关系；具体负载能否提供足够的复用度、能否达到目标利用率，留到 workload evaluation 验证，不宣称本结构在任意 M 下都能跑满。

**已关闭：激活扇出。**bit-serial 输入降低了每周期的数据宽度，Macro/core 间共享激活主要转化为缓冲树、驱动能力和静态时序问题，不构成新的阵列组织或调度机制，不再作为本 Idea 的技术挑战。ASIC 实现阶段仍需对扇出网络进行时序验证。

**已关闭：LW 的装载对象轮转。**每周期每 Plane 装载 2 个 Core（每个 Macro 各写 1 条 word line），按 Core 序号简单轮转，10 拍一轮、16 轮共 160 拍写满一套 context；word line 为外层循环、Core 为内层，详见 §3.3.4 末尾的定版描述。

【challenge 方向（待展开）：围绕 baseline 对多精度、尤其是低精度的支持不足。已知线索是 baseline MXM 只有 INT8 / FP16 两种模式（附录 A.4），低精度只能以“更多输出位置”而非“更低位宽”的方式被利用，需要从 RTL 实现与面积/能效开销两个层面把这一不足量化出来，再与 CIM 的列打包能力形成对照。本节暂不预设结论。】

### 3.4 NIM 微架构与 Plane 外部数据通路

本节将 Plane 外部的数据通路落实为”硬件模块—吞吐—资源—SRAM”模型。阵列内部只处理整数尾数；NIM 负责激活预对齐、组级指数合并、结果转换和静态写回。”预对齐 + 整数 CIM + 指数回赋”是 ReDCIM 等已有技术的流程骨架，本节不把该骨架作为创新点。

> **跨 core 累加的修正**：K=320 归约不是全程整数——激活按 16 元素组各自预对齐、各组 EI 不同，跨 core / SuperLane 的部分和累加需先做**两两对阶**（EI+EW 参与、指数随链演变），再相加。**落点与 baseline 契合：core 传递时做两两对阶累加**——baseline Supercell 同样负责"本地乘加 + 跨 SuperLane 部分和累加"，CIM core 对应之，K=320 归约沿 core 链完成，NIM 仍在末端转换、collector 职责不变。**对阶累加按输出通道独立配置，mantissa 累加器规格统一为 64 bit**；对阶造成的精度损失属于 BFP 方案取舍，不再作为本章评估项。详见 [bfp-cim-int-fp.md](bfp-cim-int-fp.md) §7.7.5。

#### 3.4.1 NIM 组织与功能边界

每个 Plane 配置一个物理 NIM。每个 NIM 沿 20 条 SuperLane 划分为 20 个 NIM tile；每个 tile 服务该 Plane 在该 SL 上的 20 Core / 80 Macro，并按当前组织进一步划分为 4 个 Cluster。

各 Cluster 具有独立的 activation、任务状态和输出，共享 NIM 的物理处理资源；EW 则按 Core 分区保存在本地 buffer 中，不集中在 NIM 末端缓存。逻辑上为四个 Cluster 分别保存 EI、精度配置、active-context 选择和输出配置，不复制权重或 EW 数据。

NIM 的功能边界固定为：

- FP 模式：对 16 个激活元素求组级最大指数 EI，按 `EI−E` 右移尾数，输出 Mantissa+ 给 CIM；
- INT 模式：旁路指数处理，激活整数直接进入 CIM；
- 结果侧：将整数结果与 EI/EW 合并，归一化并转换为 FP32，随后按静态 writer slot 写入 SRF；
- 不承担 CIM 阵列内部 MAC、collector 的纯打包或 VXM 的后续通用向量计算；架构文档中的卷积访问模式生成（Custom Delay）功能不属于本 Idea，已从 NIM 职责中删除。

#### 3.4.2 硬件模块与运算资源

| 模块 | 功能 | 当前资源模型 |
|---|---|---|
| Activation capture | 每个 NIM tile 每拍接收 1 组 activation；按 CL0→CL1→CL2→CL3 四拍轮转服务 | 每组 16 个元素；每个 Cluster 每 4 拍获得一组；NIM 输入 II=1 组/拍 |
| 指数最大值单元 | 求 16 个输入指数的 EI | **四个 Cluster 共享一棵 16 输入比较器树，共 15 个指数比较器**；每拍最多处理一组，与输入规格匹配 |
| 预对齐移位阵列 | 尾数按 `EI−E` 右移 | 16 路输入为一组；移位器数量和复用比例由处理 II 决定 |
| EI/配置状态 | 保存当前任务的 EI、精度和 active-context 选择 | 每 Cluster 少量寄存器，不设置大容量 SRAM |
| Core EW buffer | 保存本 Core active context 的权重指数，供对阶累加直接读取 | 每 Core 最大 256 B（INT4）；按 Core 分区，不复制 EW 数据 |
| Core 对阶累加单元 | 跨 Core 部分和按输出通道逐对对阶后累加 | **每输出通道分别配置，mantissa 累加器规格统一为 64 bit**；指数比较、移位和累加以 **1 拍完成并传递为时序目标，需通过 ASIC 综合验证**；INT 模式旁路 |
| EI/EW 分发路径 | EI 随 activation 组广播进入 Core；EW 由 NIM 在独立 capture 窗口写入 Core 本地 buffer | 首次使用前由编译器保证就绪，不在本文展开具体时序 |
| Core 结果缓冲 | 暂存 collector 输入结果 | 每份最大 768 B；单/双缓冲由流水时序决定 |
| 指数合并单元 | 计算 `EI + EW[n] + 格式常数` | 按 N 预先计算并缓存，避免每条转换 lane 重复配置指数加法器 |
| 归一化与 FP32 转换 | 符号处理、前导零检测、移位、指数调整和舍入 | **固定 64 个转换 lane**，每 lane 每拍输出一个 FP32 |
| 输出写回单元 | 按固定表写入 SRF | 每 Plane 的 NIM 占用 16 stream = **256 B/cycle** |

其中，最大指数求取使用比较器树而不是浮点加法器。指数合并不在每个 activation 组到来时全量预计算 S[n]：**context 装载时按每 Core 的 4N 个输出通道预计算并缓存 `EW_base[n] = EW[n] + C_format`，对阶时由各输出通道现场计算 `S_c,n = EI_c + EW_base[n]`**，避免为每组激活引入最多 256 项的预计算和缓存开销。

#### 3.4.3 输入位宽与阵列结果字段

权重整数位宽 `w` 与激活数值位宽 `a` 独立配置：`N = 256/w` 决定每个 Macro 的输出路数，CIM 的有效输入间隔由调度 II 决定，不要求 `a=w` 或所有格式都取 II=a。

**Activation 输入规格（定版）**：每个 NIM tile 每拍接收一组 16 元素，按 CL0→CL1→CL2→CL3 四拍轮转；每个 Cluster 每 4 拍获得一组，NIM 的输入启动间隔为 1 组/拍。编译器按 CIM 的有效 II 插入所需空闲拍，NIM 输入快于 CIM 消费不构成额外问题。

FP 模式不采用 guard bit，激活输入直接取完整 Mantissa+ 位宽：

| 输入格式 | 原生 mantissa | 数值位宽 a | 有效调度 II | 每组原始输入数据量 | 预对齐后 CIM 数据量 |
|---|---:|---:|---:|---:|---:|
| INT4 | — | 4 | 4 | 8 B | 8 B |
| INT8 | — | 8 | 8 | 16 B | 16 B |
| INT16 | — | 16 | 16 | 32 B | 32 B |
| FP16 | 10 bit | 12 | 12 | 32 B | 24 B |
| FP8 E4M3 | 3 bit | 5 | 5 | 16 B | 10 B |
| FP8 E5M2 | 2 bit | 4 | 4 | 16 B | 8 B |
| FP4 E2M1 | 1 bit | **3** | **4** | 8 B | 6 B |

FP4 的 Mantissa+ 数值位宽为 3 bit，但**有效调度 II 定为 4**，不按 II=a=3 组织输入；多出的一个周期作为调度空档，与后文 4 拍 Core 输出排空一致。

K=320 时，每路带符号结果所需位宽为：

```text
R = w + a + floor(log2 320) = w + a + 8
```

| 权重 w | 有效结果通道 C(w) | 不溢出范围 |
|---|---:|---|
| 16 | 64 bit | a≤40，覆盖全部配置 |
| 8 | 32 bit | a≤16，全覆盖 |
| 4 | **24 bit** | **a≤12** |

W4 的 24 bit 通道覆盖 W4A4、W4A8、FP8 和 FP16；W4A16 需要 R=28，当前不支持。**对阶累加按输出通道独立配置，mantissa 累加器规格统一为 64 bit**；该位宽只用于动态范围和溢出设计，不承担任何精度保证。本章不设置“无损”目标，也不开展精度损失评估。

#### 3.4.4 SRAM 与缓冲资源

| 资源 | 当前容量模型 | 说明 |
|---|---:|---|
| Core EW buffer（INT16 / INT8 / INT4） | 64 / 128 / **256 B / Core** | 每 Core、active context；按输出通道保存，供本地对阶累加使用 |
| NIM tile 的 EW 总量（INT16 / INT8 / INT4） | 1.25 / 2.5 / **5 KiB** | 20 个 Core 合计；Cluster 划分和 Core 级存储均不增加 EW 数据量 |
| EI/任务配置 | 少量寄存器 | 每 Cluster 独立，不另设大容量 SRAM |
| 激活组串并转换 | 约 24 B × 4 Cluster ≈ 96 B | **寄存器堆实现**；16 元素并行进、串行 bit-serial 出 |
| Core 整数结果输入 | **双缓冲，2 × 768 B = 1,536 B** | collector 每 4 拍交付一份（W4），双缓冲使当前转换与下一份输入重叠 |
| Core FP32 输出 | **不加缓冲** | 64 lane 转换流水每拍 64 个 FP32 直接对接 writer，进率=出率 |

EW 的 capture 由 NIM 调度，数据在 LW/IW 之外的窗口写入**对应 Core 的本地 EW buffer**，而不是集中在 NIM 末端保存。每个 Core 只缓存自身 active context 的 EW，供本 Core 对阶累加直接读取；**EI 则随对应 activation 组经原有广播通路进入 Core，由各输出通道共享**。NIM 仍负责激活预对齐、EI 生成和链尾 FP32 转换。满 32 stream 时，整个 tile 的理想 capture 时间为 INT16 2.5 拍、INT8 5 拍、INT4 10 拍。**首次 ACC 前由编译器保证对应 context 的 EW 已写入 Core buffer；按每 Core 的 4N 个输出通道预计算 `EW_base[n] = EW[n] + C_format`，EI 在对阶时加入。**硬件不设运行时仲裁。

不按整个 Plane 的 15 KiB 结果量配置集中缓冲；缓冲只按流水线上正在处理的 Core 结果份数配置。

#### 3.4.5 64-lane 转换与写回吞吐

固定 **64 个转换 lane** 后，每拍最多产生 64 个 FP32：

```text
64 lane × 1 FP32/lane/cycle × 4 B = 256 B/cycle
```

这与每 Plane NIM 的 16-stream 写回能力完全一致。两个 Plane 同时输出时，合计 512 B/cycle，与 VXM 每个 SuperLane 的输入能力一致。

| 权重 w | 每 Macro N | 每 Core 输出结果数（4 Macro） | 64 lane 转换拍数 | 单 Core FP32 字节数 | 256 B/cycle 写回拍数 |
|---|---:|---:|---:|---:|---:|
| 16 | 16 | 64 | 1 | 256 B | 1 |
| 8 | 32 | 128 | 2 | 512 B | 2 |
| 4 | 64 | 256 | 4 | 1,024 B | 4 |

因此转换 lane 和 writer 在两个平面上都是匹配的：

```text
单 Core 排空拍数 = ceil(16/w)
W4 = 4 拍，W8 = 2 拍，W16 = 1 拍
```

**K > 320 的分段累加在 MXM 外完成。**单个阵列的归约边界恒为 K=320（`20 SuperLane × 16`）；模型层 K 更大时按 K tile 分段，各段结果经 NIM 转换为 FP32 后写回 stream，由下游（SXM ACC03 或写回 MEM 后续算）逐段累加，跨 tile 部分和不进入 CIM 阵列内部。因此结果通道位宽 `R = w+a+8` 不随模型总 K 增大，MXM 与 NIM 的接口设计也不受 K 分段影响。

#### 3.4.6 Core 结果时序与 FP4 闭合条件

输出转置后，每个 writer 的基本归属是一个 CIM Core；不同 Core/Cluster 的结果可分配到不同 writer SuperLane 并行写回，不能把 Cluster 或 Plane 的结果累计到同一个 writer 上串行计算。

若同一 writer 的相邻 Core 结果事件间隔为 `T_next`，避免持续积压的条件为：

```text
T_next ≥ ceil(16/w)
```

- INT4 最低为 a=4，W4 Core 的转换和写回均为 4 拍，**整型模式恰好平衡，不存在持续积压**；
- **FP4 E2M1 的数值位宽 a=3，但有效调度 II 已定为 4**，因此同一 writer 上 Core 结果的到达间隔与 4 拍 FP32 输出排空一致，不再存在 a=3 的持续输入/输出失配；
- FP8 E4M3（II=5）和 FP16（II=12）均大于 4 拍，输出侧也不是瓶颈。

NIM 的处理 latency 只改变首次输出时刻，不能代替吞吐约束。若采用双缓冲，可以让当前 Core 的转换/写回与下一 Core 的输入或预处理重叠；对于 II 大于 NIM 输入节拍的格式，由编译器插入空闲拍，保证持续运行时不发生缓冲增长。

#### 3.4.7 NIM 流水级与已定版参数

**输入侧流水（每 tile，II=1 组/拍）：**

| 级 | 功能 | 资源 |
|---|---|---|
| S0 | 从 stream 捕获 16 元素组 | 每组 8–32 B，四拍轮转 |
| S1 | 比较器树求 EI | 15 个指数比较器（共享一棵） |
| S2 | 计算偏移 `EI−E`，尾数右移 | 16 个并行移位器 |
| S3 | 串并转换，按 bit-serial 送 CIM | 寄存器堆，约 96 B/tile |

EI 按_cluster 保存至对应 Core 结果返回（指数回赋输入），随任务切换更新。

**结果侧流水（64 lane，逐拍流水）：**

| 级 | 功能 | 资源 |
|---|---|---|
| R0 | 从 Core 双缓冲读出链尾累积 mantissa 和最终累积指数 S_acc | 2 × 768 B；S_acc 为跨 Core 对阶链上逐步取 max 后的最终指数 |
| R1–R2 | 符号处理、前导零检测、归一化移位、指数调整 | 64 lane；LOD 深度为电路细节，不在此定级 |
| R3 | 舍入、组装 FP32、写入 SRF writer | 64 lane × 4 B/拍 = 256 B/cycle，直接对接 writer，无输出缓冲 |

**已定版：**

1. 每 Plane 一个物理 NIM、每 SL 一个 NIM tile，四个 Cluster 独立管理任务上下文；
2. 每个 NIM tile 每拍接收一组 16 元素，按 CL0→CL1→CL2→CL3 四拍轮转；四个 Cluster 共享一棵 16 输入指数比较器树，共 15 个比较器；
3. 输入侧 S0–S3 四级流水，串并转换用寄存器堆（约 96 B/tile）；
4. 结果侧 64 个 FP32 转换 lane 逐拍流水，匹配 16 stream / 256 B/cycle 写回能力，不加输出缓冲；
5. Core 输入双缓冲（2 × 768 B），使当前转换与下一 Core 输入重叠；
6. W4 的 Core 结果以 4 拍完成转换和写回，整型模式不积压；
7. FP4 的数值位宽 a=3、有效调度 II=4，Core 结果到达与输出排空一致，FP4 的输出问题关闭；
8. EW 采用 **Core 级 buffer**：每 Core 仅保存 active context 的 EW，最大 256 B（INT4），按 Core 分区、就近供对阶累加读取；Cluster 和 Core 级分布均不增加 EW 数据量；
9. EW capture 由 NIM 调度并写入对应 Core 的 buffer；按每 Core 的 **4N 个输出通道**预计算 `EW_base[n]`，EI 在对阶时加入。**首次 ACC 前由编译器保证对应 context 的 EW 已写入 Core buffer**，硬件不设运行时仲裁；
10. 当 CIM 消费间隔大于 NIM 输入节拍时，由编译器在静态调度中插入空闲拍；
11. **跨 Core 对阶累加按输出通道独立配置，mantissa 累加器规格统一为 64 bit；对阶精度损失不纳入评估。**
12. **每次对阶累加以 1 拍完成（hop latency = 1）为时序目标**，用于匹配相邻 Core 的 II=1 启动与部分和交接；**该目标需通过 ASIC 综合时序验证，验证前不视为已保证。**
13. **EI/EW 分发路径定版**：EI 随对应 activation 组经原有广播通路进入 Core；EW 由 NIM 在独立 capture 窗口分发并写入各 Core 的本地 EW buffer。首次使用前由编译器保证就绪，本文不展开具体时序。

**留作电路实现细节（不进入架构层级）：** LOD 流水深度、移位器与转换 lane 的具体位宽切分、比较器树的物理级数。这些在架构图中以单一模块方块表示。

### 3.5 权重 Context 切换与 IW 设计

本节定义权重的驻留组织、装载就绪判定和 context 切换机制。四个操作（LW / 就绪 / IW / ACC）的粒度各自跟随其底层物理结构，而不是沿用 baseline 的全行同步语义。

#### 3.5.1 Context 的物理归属：Macro 级 SRAM

**4 套 weight context 是每个 CIM Macro 自身的 SRAM 结构**（`4 × 512 B = 2 KiB/Macro`），与 baseline 的 weight register bank 属于完全不同的物理形态：register bank 理论上可讨论集中式组织，SRAM bitcell 长在每个 Macro 内，**不存在池化或集中分配的设计空间，也没有分配器**。

由此：

- context 寻址 = `(Macro, context_id)`，每 Macro 一个 2 bit active 指针；
- “一个任务占用一个 Cluster 的某套 context”只是**编译器的映射约定**（任务占满该 Cluster 的 20 个 Macro 的同一 context_id），不是硬件分配机制；
- 无运行时分配状态，全部静态可验证。

#### 3.5.2 就绪判定：Cluster 级

装载按 §3.3.4 定版的 Core 轮转执行：每拍 2 Core、10 拍一轮、16 轮共 160 拍写满一套 context。该轮转覆盖整行 20 Core，Cluster 内全部 Macro 在同一轮扫描中同步推进，因此**就绪事件天然是 Cluster 粒度**：

```text
ready(Cluster, context) = 该 Cluster 的 20 Macro × 16 word line 全部写入完成
```

四个 Cluster 的就绪时刻可以不同：LW 可以为不同 Cluster 的不同 context 交错安排扫描轮次（编译器静态编排），互不阻塞。

#### 3.5.3 切换执行：Core 级滚动

Baseline 的 IW_BUFFER 之所以能全行同拍切换，是因为它没有 Core 级错峰——一个 ACC wave 让本 SL 全部 Supercell 同拍计算、同拍排空。本架构为结果转置引入了错峰启动（§3.2.5/§3.2.6），**各 Core 的旧 context 排空时刻天然相差 1 拍**，切换因此按 Core 滚动执行：

```text
core[c] 在自身引用旧 context 的最后一个 ACC 排空后 +1 拍，切换 active 指针
```

- 切换时刻恰好贴住该 Core 的下一次计算启动，**无“等待最慢 Core”的空泡**（Cluster 同拍切换会让 core 0 白等 core 4 排空，每次切换引入最多 4 拍空泡）；
- 切换时刻差与错峰启动共用同一套 stagger 偏移，不引入新的时序参数；
- 权重的 active 指针本就是 per-Core 私有状态（各 Core 的 Macro 持有该任务的不同 N 分片），Core 级切换是物理状态的天然粒度；activation 才是 Cluster 共享的，不受影响。

#### 3.5.4 IW 指令语义

```text
IW(cluster_id[1:0], context_id[1:0])
```

- 不含 stream_group / weight_index：装载位置归 LW 管，IW 只执行 ownership 切换；
- 指令以 command wave 沿 20 条 SuperLane 逐拍传播（与 LW/ABC/ACC 同构）；到达某 SL 后，该 SL 上目标 Cluster 各 Core 按自身排空时刻滚动完成切换——**Core 级滚动由硬件按既有 stagger 偏移自动展开，不需要指令逐 Core 发射**；
- 前置条件由编译器静态保证：目标 `(Cluster, context)` 已就绪，且各 Core 引用旧 context 的 ACC 均已排空；硬件不设运行时仲裁。

#### 3.5.5 互锁与 IW_STREAM 的删除

- **互锁粒度为 Core**：某 Core 的切换与其它 Core / 其它 Cluster 的 ACC 不互斥。Baseline 的 IW+ACC 全局互斥源于全行同拍的 ownership 可见性；粒度细化到 Core 后该约束自然解除，只有同一 Core 的切换与其自身 ACC 需要先后顺序（由滚动切换的定义天然满足）；
- **IW_STREAM 删除**：baseline 的 IW_STREAM（从 stream 直接覆盖 active bank、不切 ownership）在 4-context 后台装载结构下无必要用途，且直接覆盖 active context 会破坏就绪状态语义，不进入本架构。权重更新一律走 LW 装载非活动 context + IW 切换。

#### 3.5.6 与 LW/ACC 的粒度统一

| 操作 | 粒度 | 由什么物理结构决定 |
|---|---|---|
| LW 装载 | Core（2 Core/拍轮转） | SRAM 写口宽度（word line）与 stream 捕获宽度 |
| 就绪判定 | Cluster（20 Macro × 16 word line） | 行轮转装载的天然完成边界 |
| IW 切换 | Core 滚动 + Cluster 寻址 | 错峰排空时刻 + per-Macro active 指针 |
| ACC 计算 | Cluster（activation 广播域） | 广播通路的物理划分 |

**四个操作的粒度各自跟随其底层结构，且由同一套 stagger 偏移贯穿**：错峰启动决定排空时刻 → 排空时刻决定滚动切换 → 切换后各 Core 按 stagger 进入新 context 计算。这条“切换粒度跟随计算错峰粒度、而非沿用全行同步”的因果链是本节的核心设计点。

## 4. 本Idea的技术保护点

> 本章确定保护点的内容与结构。**具体权利要求的规范化措辞由专利代理人负责**；本章只把保护点的技术内容讲清楚。主保护点给一个正式版（供代理人参考结构）和一个通俗版（供评审与内部沟通）。

### 4.1 主保护点：多精度 CIM 阵列接入确定性 stream 数据流的组织与接口时序

**核心创新定位**：本 idea 是**组合创新**，不是单点突破。核心创新是**在同一 CIM 阵列内按任务域组织独立计算，并允许不同任务域以不同精度组合并行执行；配合每任务域独立的数值处理通道与编译期静态写回，使多精度 CIM 阵列能够以确定性方式接入 stream 数据通路**。技术效果：在不引入运行时仲裁和不确定延迟的前提下，实现多精度 CIM 阵列与 stream 静态调度通路的协同工作。

#### 正式版（供专利代理人参考结构）

一种矩阵计算装置，应用于确定性数据流处理器，所述确定性数据流处理器的功能单元沿 stream 通路排布，并由编译期静态调度确定各功能单元在 stream 上的操作时序，所述装置包括：

- 多个存内计算宏，其权重驻留于存储阵列，激活值以逐位串行方式输入；
- 所述多个存内计算宏组织为计算核心与独立激活广播域的嵌套两级结构：计算核心由多个存内计算宏构成，各宏保存不同的输出通道分片、权重不重复、部分和独立累加；独立激活广播域由多个计算核心构成，每个广播域接收独立的激活输入、构成独立的计算任务域；**多个所述独立激活广播域构成同一矩阵计算 Plane**；
- 权重精度与激活输入位宽在各任务域间独立配置，权重精度决定输出通道数量、激活输入位宽决定串行输入拍数间隔，二者独立配置以支持非对称精度组合，同一矩阵计算 Plane 内的多个任务域以不同精度组合同拍执行计算；
- **在浮点模式下**，各独立激活广播域的激活输入经位于 stream 通路上的数值转换单元进行组级指数预对齐，**在整数模式下，激活输入旁路所述预对齐**；所述数值转换单元为各任务域维护独立的处理通道，将阵列整数累加结果与组级指数合并转换并写回 stream；**所述数值转换单元的预对齐、结果转换及写回时刻均由编译期静态调度确定，各处理通道按编译期确定的固定交错次序写回**。

#### 通俗版（供评审与内部沟通）

一句话：**把多精度、权重驻留的 CIM 阵列嵌进 Groq 式 LPU 的确定性数据流里，靠的是一套组织与接口机制。**

拆开讲我们做了什么：

1. **阵列组织**：CIM 宏按"计算核心 → 独立激活广播域（任务域）"两层组织；同一核心内的宏各管一段输出通道、权重不重复、各自累加，同一广播域跑一个独立任务。
2. **多精度异构**：每个任务域的权重精度和激活位宽各自独立配置，所以同一片阵列的不同任务可以**同一拍用不同精度**算（支持 W4A8 这类非对称组合）。
3. **数值转换单元（NIM）**：位于 stream 通路上，**为每个任务域维护独立逻辑通道、并共享物理转换资源**，负责激活的块浮点预对齐、把整数结果与组级指数合并转成浮点，再按编译期排好的固定顺序写回 stream——**整个节奏跟 LPU 的确定性时序对齐**。

**与已知方案的差异化假设（待检索验证）**：现有 CIM（ReDCIM 等）没有 LPU 的 stream/确定性时序，Groq baseline 没有 CIM、NIM 也不做预对齐；只有两者结合才需要这套接口与时序组织。此差异结论需经 §8 的在先检索闭合。

### 4.2 从保护点（两个方向）

1. **Core 级 EW buffer 与逐通道对阶累加**：在浮点模式下，各输出通道分别设置对阶累加单元；权重组级指数 EW 按输出通道组织，在独立于 LW 的静态调度窗口内经 SRF 按 SuperLane 分发，并写入各 Core 的本地 EW buffer。每个 Core 仅保存自身 active context 的 EW，供本 Core 对阶累加，并在链尾用于最终指数回赋与 FP32 转换。一条 capture 指令可覆盖一个或多个 context，EW capture 不在计算关键路径上，由编译器静态编排。
2. **数值转换单元的物理资源共享与独立上下文**：同一物理数值转换单元服务一个矩阵计算 Plane，内部共享物理转换资源，并为多个任务域分别保存独立的处理上下文（EI、精度配置、输出配置）；**EW 则按 Core 分区保存在本地 buffer 中**。各任务域的结果按编译期确定的固定交错次序复用所述物理转换资源。即在主保护点的“独立通道与静态写回”之上，进一步限定“**共享物理资源 + 独立上下文 + Core 级 EW 分区**”。

### 4.3 不作为保护点的内容（边界）

- CIM 宏内部的多精度 column 切分与共享加法树（§3.1，ReDCIM/Column-MAC/UNPU 已公开）；
- core 错峰阶梯启动（继承 baseline Supercell 的 stagger）；
- 权重多 context 驻留本身（Axelera US20250130771A1 / 清微 CN122733787A 已公开）；
- NIM 的具体数值实现（特殊值、舍入模式、归一化电路、精度 profiling）——属 RTL 实现，不进专利文档。

## 5. 本Idea的技术效果（阶段结果，2026-11-10 回填）

本章以 **Qwen3-8B 单层 FFN** 为负载，比较权重受限的扩展 baseline 与本方案在相同工作量下的延迟与能耗。延迟与能耗均覆盖 INT8/FP8/INT4/FP4 四种格式，能耗采用 action-based 模型（7 nm、0.8 V、800 MHz）。评估工具、参数配置与测试归档于 `tools/qwen3_ffn_cim_eval/`（延迟模型、动作能耗模型、Aladdin/CACTI prior 生成脚本与 14 项单元测试）。

### 5.1 对照设置

**负载定义**：Qwen3-8B（hidden_size=4096、intermediate_size=12288）一层 FFN，包含 gate、up、down **三个 GEMM** 与两边相同的 SwiGLU：

| GEMM | 形状（M × K × N） |
|---|---|
| gate | M × 4096 × 12288 |
| up | M × 4096 × 12288 |
| down | M × 12288 × 4096 |

每层 MAC 数 = `M × 3 × 4096 × 12288`；一层权重 INT8/FP8 为 144 MiB、INT4/FP4 紧密打包为 72 MiB，满足 220 MiB 片上 SRAM 驻留设定。复用长度扫描 `M = 1 / 4 / 16 / 64`。SwiGLU 两边工作量相同，不作差异项；gate/up 与 down 之间经 SwiGLU 依赖衔接，down 的 LW 可提前执行。

**延迟口径**：分析式 Python 模型（`latency_model.py`），对每个 GEMM 做原生 K/N 切分后按资源流水调度：

- LW（全芯片 20,480 B/cycle）→ ACC → 结果写回（20,480 B/cycle）三段资源重叠，重叠部分不重复计入总延迟；
- baseline 2 套权重 context，CIM 4 套 Macro 级 SRAM context；重用 context 需等旧 ACC 排空；
- CIM 以 **Cluster 任务**（K=320 × N=640（INT8/FP8）或 1280（INT4/FP4））为最小调度单位，gate/up 联合打包为全芯片 16 Cluster（4 Plane × 4 Cluster）wave，down 单独打包；尾 wave 保留实际任务数，不要求全芯片同进同出；
- 单 Cluster 任务 ACC 占用为 `M × II`（II：INT8=8、FP8=5、INT4/FP4=4）；K 超出原生边界的分段在 MXM 外以 FP32 累加；
- 原先按全芯片原子 N tile 的 CIM 映射会留下大量空闲 Cluster，该口径已废弃并撤回其结论。

**Baseline 口径（权重受限的理想化扩展）**：每个 Supercell 有效权重状态固定 256 B；任务 1 的乘积生成前端允许 FP8/FP4 达到 INT8 的约 4×（折合 1,024 MAC/拍/Supercell），但不能突破该权重状态上限，可兑现吞吐为：

| 模式 | 本地计算 | 每 Plane 原生 K | 全芯片峰值 |
|---|---|---:|---:|
| INT8 / FP8 | dot16 | 320 | 409,600 MAC/cycle |
| INT4 / FP4 | dot32 | 640 | 819,200 MAC/cycle |

每 Plane N=320、全芯片 4 Plane；每个原生 tile 的 ACC 占用为 M，K/N 尾块同样占满一次调度（不按尾块比例缩短）。

### 5.2 延迟评估

FFN 层总延迟如下；加速比 = baseline 总延迟 / CIM 总延迟，小于 1 表示 CIM 略慢：

| 格式 | M | Baseline（cycle） | CIM（cycle） | 加速比 |
|---|---:|---:|---:|---:|
| INT8 | 1 | 7,384 | 7,414 | 0.996× |
|  | 4 | 7,394 | 7,456 | 0.992× |
|  | 16 | 8,090 | 7,664 | **1.056×** |
|  | 64 | 26,990 | 26,688 | **1.011×** |
| FP8 E4M3 | 1 | 7,384 | 7,408 | 0.997× |
|  | 4 | 7,394 | 7,429 | 0.995× |
|  | 16 | 8,090 | 7,549 | **1.072×** |
|  | 64 | 26,990 | 16,890 | **1.598×** |
| INT4 / FP4 | 1 | 3,700 | 3,721 | 0.994× |
|  | 4 | 3,703 | 3,740 | 0.990× |
|  | 16 | 4,282 | 3,817 | **1.122×** |
|  | 64 | 14,434 | 7,638 | **1.890×** |

INT4 与 FP4 延迟相同（同为 4-bit 权重、有效 II=4）。M=64 的资源分解（累计 busy，不可直接相加为总延迟）：

| 资源（M=64） | INT8 基线 / CIM | INT4 基线 / CIM |
|---|---|---|
| LW | 7,374 / 7,374 | 3,687 / 3,687 |
| ACC | 26,624 / 26,112 | 14,080 / 6,912 |
| Writer | 6,032 / 6,011 | 3,196 / 6,003 |
| 总延迟 | 26,990 / 26,688 | 14,434 / 7,638 |

结论：

- **小 M（1/4）**：LW 与流水排空主导，两边持平（差异 <1%），不宣称低时延收益；
- **大 M**：ACC 主导。INT8 两边 ACC busy 接近而基本持平；FP8 的 1.6× 峰值关系兑现为总延迟 1.598×；INT4/FP4 的 2× 峰值关系兑现为 1.890×（N 尾块与 writer 开销略稀释）；
- Writer 等待在全部扫描中≈0，不是瓶颈；INT4 下 CIM writer busy 接近翻倍（结果路数多一倍），未抵消 ACC 收益；
- 延迟模型不宣称 hop=1 对阶时序；FP4 的 II=4 是调度假设。

### 5.3 能效评估（四格式，action-based）

**方法学**：参照 dLLM_Acc `hardware_sim` 的 EM0–EM5 能耗建模——动作计数与系数查找分离；正工作量的必要动作缺系数时总量 unavailable（null≠0，不输出部分和）；compound 系数来自 estimator prior 或测量拟合，不与已单独计费项重复。工作点固定 **7 nm、0.8 V、800 MHz**；800 MHz 是统一评估假设，不是 Fmax 结论，也不改变 cycle 数。

**来源权威规则**（与 12nm 源 profile 自身约定一致）：算术加法使用 TPUv4i Table 2 硅后参考（7nm INT8 mul 0.070、INT32 add 0.030、FP16 mul 0.340、FP32 add 0.380 pJ）；Aladdin 只覆盖 TPU 没有的结构性原语（比较器、移位器、寄存器）；CACTI 覆盖 SRAM 写入。Aladdin 浮点原语经 FP16 交叉校验比 TPU 高 2.1–3.3×，不作为 primary。

**两项来源一致性修订**（定义 primary 系数集，均为来源对称性修正而非结果调整）：

1. **Baseline FP 乘法按任务 1 分拆结构计价**：被评估的 baseline 就是分拆数据通路（FP8 = 1× 4×4 整数乘法器、FP4 = 4× 2×2），"原生 FP 乘法器"价格在本对照中不对应任何真实硬件。乘法从 TPU INT8 mul 锚点按宽度平方规则推出（两种格式均为 0.0175 pJ），E32M32 累加仍为 TPU FP32 add 0.380。方法验证：FP16 结构价 4×INT8 mul = 0.280 vs TPU 原生 FP16 mul 0.340（比值 0.824）。
2. **CIM 对阶 hop 按功等价 TPU FP32 add 计价**：hop 的工作（指数比较＋宽尾数对齐＋宽加）与一次浮点加法等价，不使用 40nm 缩放原语组合对比硅后值的来源混用。整型原语组合值（0.152 pJ）保留为乐观变体。

**动作集**：每架构保留 `array_mac`（区分精度）、`weight_write`、`support_active`（baseline 为 Plane 粒度、CIM 为 Cluster 粒度）、`activation_capture` 四项计入 **MXM 内部能耗**。FP 模式追加：CIM 侧 `fp_prealign`（NIM 输入预对齐）与 `fp_ew_capture`（EW buffer 写入），FP 版 support compound 以对阶累加**替换**整型 PSUM（非叠加）；baseline 侧 `fp_result_narrow`（E32M32→FP32 窄化）与 `fp_aux`（分类／E32M32 转换／分量归约的固定辅助逻辑）。`srf.transfer`、`mem.weight_read`、`mem.input_read`、`mem.sram_write`、`k_segment.accumulate_fp32`、`shared.swiglu` 单独归因为外部项。主对照口径为 MXM 内部，避免 MEM 权重读取（小 M 时占主导）掩盖模块差异。

**当前参数与证据等级**：

| 参数 | 数值 | 来源与边界 |
|---|---:|---|
| CIM array MAC（INT8/INT4/FP8/FP4） | 0.0660066 pJ/MAC | 项目选定 30.3 TOPS/W@7nm 参考；INT4/FP4/FP8 均为方案 A 延伸（同单位 MAC 能耗）；FP8 II=5 使该复用偏保守；不对 CIM 使用逻辑工艺外推 |
| Baseline array MAC（INT8/INT4） | 0.1 pJ/MAC | TPU 7nm INT8 乘＋INT32 加；INT4 为方案 A |
| Baseline array MAC（FP8 / FP4） | 0.3975 / 0.3975 pJ/MAC | 任务 1 分拆结构：TPU INT8 mul 锚点×宽度平方规则（1×4×4 或 4×2×2，均 0.0175）＋TPU FP32 累加 0.380 |
| Baseline `fp_aux`（FP8 / FP4） | 0.049608 / 0.056816 pJ/MAC | Aladdin 结构原语：2×分类比较＋E32M32 转换＋FP4 分量归约；任务 1 的面积主导项 |
| CIM resident SRAM 权重写入 | 0.01773817 pJ/byte | CACTI：512 B context、16×32 B word line；sqrt(7/22) 缩放＋(16/64)^0.78 深度归一 |
| Baseline 权重寄存器写入 | 0.00859133 pJ/byte | 现有 12nm 系数按公共规则缩放到 7nm |
| Baseline Plane support（INT / FP） | 182.4 / 2,310.4 pJ/plane-active-cycle | TPU 锚定：INT32 add×(19×320) / FP32 add×(19×320)；INT→FP 跨度 12.7× 为纯 TPU 口径 |
| CIM Cluster support（INT8 / INT4） | 74.123 / 296.492 pJ/cluster-active-cycle | TPU 锚定整型 PSUM＋整数结果转换代理＋768 B 结果缓冲（Aladdin/CACTI） |
| CIM Cluster support（FP8 / FP4） | 1,014.0 / 2,535.0 pJ/cluster-active-cycle | 对阶累加（功等价 TPU FP32 add）＋FP32 结果转换＋结果缓冲；替换整型路径；整型原语变体 459.4/1,148.6 为乐观界 |
| CIM `fp_prealign` / `fp_ew_capture` | 0.935261 pJ/组 / 0.013131 pJ/byte | 15 比较器＋16 移位器＋192 bit 寄存器堆 ／ CACTI 256 B EW buffer |
| Baseline `fp_result_narrow` | 0.38 pJ/result | TPU FP32 add 代理 |

Support prior 均为 estimator-backed，不含 active-window 静态基线；SRF/MEM/K 分段/共享 VXM 不重复计入 support。

**MXM 内部能耗结果**：

| 格式 | M | Baseline | CIM | CIM/基线 | 降低 |
|---|---:|---:|---:|---:|---:|
| INT8 | 1 | 16.704 µJ | 13.117 µJ | 0.785× | 21.5% |
|  | 4 | 62.926 µJ | 44.435 µJ | 0.706× | 29.4% |
|  | 16 | 247.811 µJ | 169.703 µJ | 0.685× | 31.5% |
|  | 64 | 987.353 µJ | 670.777 µJ | 0.679× | 32.1% |
| FP8 | 1 | 72.839 µJ | 16.806 µJ | 0.231× | 76.9% |
|  | 4 | 287.465 µJ | 58.818 µJ | 0.205× | 79.5% |
|  | 16 | 1,145.967 µJ | 226.865 µJ | 0.198× | 80.2% |
|  | 64 | 4,579.976 µJ | 899.052 µJ | 0.196× | **80.4%** |
| INT4 | 1 | 15.911 µJ | 11.800 µJ | 0.742× | 25.8% |
|  | 4 | 61.697 µJ | 43.182 µJ | 0.700× | 30.0% |
|  | 16 | 244.842 µJ | 168.709 µJ | 0.689× | 31.1% |
|  | 64 | 977.421 µJ | 670.817 µJ | 0.686× | 31.4% |
| FP4 | 1 | 71.380 µJ | 15.656 µJ | 0.219× | 78.1% |
|  | 4 | 283.573 µJ | 58.236 µJ | 0.205× | 79.5% |
|  | 16 | 1,132.346 µJ | 228.553 µJ | 0.202× | 79.8% |
|  | 64 | 4,527.438 µJ | 909.822 µJ | 0.201× | **79.9%** |

FP 差距（约 5×）在修订后**全部来自一个可推导的算术因子**：对阶 hop 与 baseline 累加已按同价（TPU FP32 add）计费，消除了原语定价差异，残余差距即每 16 个 K 元素共享一次指数处理的结构摊销 `320/19 ≈ 17×`（CIM 阵列侧整数 mantissa MAC 0.066 相对 baseline 结构乘法 0.0175＋累加 0.380＝0.3975 的比值为 6.0×，加上 support 结构差异后收敛到约 5×）。该摊销由分组算术决定、与 M 无关、任何评审可直接验证。

**M=64 边界拆解**（µJ）：

| 能耗边界 | INT8 基线/CIM | FP8 基线/CIM | INT4 基线/CIM | FP4 基线/CIM |
|---|---|---|---|---|
| **MXM 内部** | **987.4 / 670.8** | **4,580.0 / 899.1** | **977.4 / 670.8** | **4,527.4 / 909.8** |
| SRF 边界 | 2.9 / 2.8 | 2.9 / 2.8 | 1.5 / 2.0 | 1.5 / 2.0 |
| MEM 权重读取 | 181.2 / 181.2 | 181.2 / 181.2 | 90.6 / 90.6 | 90.6 / 90.6 |
| MEM 其他读写 | 10.1 / 10.1 | 10.1 / 10.1 | 9.4 / 9.4 | 9.4 / 9.4 |
| 外部 K 分段累加 | 11.0 / 11.0 | 11.0 / 11.0 | 5.5 / 11.0 | 5.5 / 11.0 |
| 共享 SwiGLU | 3.8 / 3.8 | 3.8 / 3.8 | 3.8 / 3.8 | 3.8 / 3.8 |
| **含外部项总量** | **1,196.3 / 879.6** | **4,788.9 / 1,107.8** | **1,088.2 / 787.5** | **4,638.2 / 1,026.5** |

含外部项的完整 workload 能耗比（M=1→M=64）：INT8 0.982→0.735；FP8 0.781→**0.231**；INT4 0.963→0.724；FP4 0.659→**0.221**。FP 模式下 baseline MAC 主导甚至压过 MEM 权重读取，因此完整总量与模块口径结论一致。INT4/FP4 下 CIM 的外部 K 分段累加高于 baseline（原生 K=320 vs 640），属已知代价。

**面积与能耗占比的观察**：任务 1 中固定辅助逻辑占 baseline FP 扩展面积的 >50%，能量估算中仅占 MAC 系数的约 12%（FP8 0.050/0.398）。原因是分类／转换为宽而浅的开关网络（面积大、单次翻转能量低），乘法器与宽累加器才是能量密集单元。这说明**低精度浮点扩展的面积代价与能耗代价不同构**——对论证 baseline 的扩展问题是面积／组织问题居首、能耗次之。

**尚未闭合**：静态功耗（CIM Macro 静态数据缺失，support prior 不含 active-window 基线；预计对大 M 结论影响小）；SRF hop 当前假设 1 hop/byte，可做敏感性扫描。

### 5.4 结果表达边界

本章数值均为**分析式模型输出**：延迟为静态资源流水模型，能耗为 estimator-backed action 模型，均不是周期精确仿真、ASIC 时序验证或硅后实测。随结论必须一并披露的假设：方案 A（INT4/FP4/FP8 阵列 MAC 复用 INT8 单位能耗）、30.3 TOPS/W 为项目选定参考值而非独立 7nm 实测、baseline FP 乘法为任务 1 结构×TPU 宽度平方规则、CIM 对阶 hop 按功等价 TPU FP32 add 计价（整型原语变体为乐观界）、`fp_aux` 仅含结构原语估算。FP 差距经上述修订后归约为 K/16≈17× 的结构摊销单因子，可由评审直接推导。小 M 下 INT 延迟与完整 workload 能耗均接近持平，应如实呈现。公共排除项（走线、ICU、时钟树、IO/PLL、PVT margin）沿用现有 profile 边界；面积综合结果未参与任何能耗换算。

## 6. 本Idea的发明人贡献说明

【待补充】
在定稿之前都空着

## 7. 本Idea的取证方法

**撰写指引（完成 Idea 胶片后请删除）：**

请说明针对本 Idea 的技术保护点可以通过何种方法取证（例如，测试、拆机分析、抓 log 日志、产品手册、产品演示取证等手段）。

例如，某厂商生产了某产品，如何证明该产品使用本 Idea 的技术点。

注意：针对测试、抓包、反编译等取证手段，请给出具体如何取证的分析。

因为我们的技术发明涉及到多精度的支持，那么只要这个芯片产品会对外提供，就需要提供相应的算法接口，也需要做上游的生态适配，因此会有对外文档展示这个技术点。我们可以找现成的一些产品的例子，他们是如何提这个内容的，比如 Nvidia 某一代产品的 TF32 的说明。

其次就是，SRAM CIM 和 LPU 数据流架构都是卖点，可以从相应产品的对外文档 white paper 中找到相应的技术点。我们可以找微纳核心的产品介绍，截图证明。

以上两段给出的是取证入口。以下按保护点补充取证对象、可观测表现、具体手段与边界。

### 7.1 取证对象与基本策略

取证对象是**对外销售芯片、板卡或云服务的厂商**。取证目标不是说明我方产品会公开什么，而是：该厂商把产品商业化后，我们依靠哪些外部可观测信息证明其使用了本 Idea 的技术方案。

基本策略是**以商业公开面为入口，以行为测试为佐证**。产品要接入上游框架和生态，必然公开精度模式、算子库、模型格式等接口信息；这些信息只能锁定"支持什么"，还需要黑盒测试确认"怎么实现"，两者组合才能落到具体技术特征上。

上面草稿中的两条观察——多精度必须提供算法接口并做生态适配、CIM/LPU 作为卖点必然出现在白皮书中——正是本策略的依据；它们提供的是接口层证据，机制层证据由 7.3 的测试补足。

### 7.2 保护点与取证方式

> **本节与 §4 强耦合。** 下表按当前 §4.1 / §4.2 的保护点排列；§4 的保护点、层级（独权/从权）或措辞一旦调整，本章需同步改写。第二列"外部可观测表现"是取证可行性的判据：填不出来的保护点，应回到 §4 调整措辞或降为从权。

| 保护点（按 §4） | 外部可观测表现 | 取证方式 |
|---|---|---|
| 主-1 存内计算宏权重驻留、激活逐位串行 | 精度-吞吐曲线；拆机可见 SRAM 阵列 | 产品文档 + 基准测试 + 拆机 |
| 主-2 计算核心 / 独立激活广播域两级组织，N 分片权重不复制 | 多任务可并发；权重总量不随任务域数量线性增长 | 产品文档 + 基准测试 |
| 主-3 各任务域独立精度、非对称组合、同拍并行 | SDK 可按任务配置精度；两任务并发总吞吐约等于各自之和；W4A8 可配 | SDK 文档 + 并发基准 |
| 主-4 浮点组级预对齐、整数模式旁路 | FP 误差按固定元素组成组出现；INT 结果精确 | 单算子数值测试 + 文档 |
| 主-5 NIM 独立通道 + 编译期固定交错写回 | 任务混合变化时单任务吞吐不变；时序重复性高 | profiler / 计时 + 文档 |
| 从-1 Core 级 EW buffer + 逐通道对阶累加 | 各输出通道的权重指数只影响本通道结果；EW capture 不伴随 LW 流量；计算不降速 | 逐通道指数探针 + 计数器 / trace + API 文档 |
| 从-2 NIM 共享物理资源 + 独立上下文 + Core 级 EW 分区 | N 任务并发时单任务吞吐约为 1/N、总吞吐恒定；结果互不污染；EW 存储随 Core 分布 | 转换密集型并发基准 + 数值测试 + trace |

从-1 的取证重点是 Core 级 EW 分区本身：除 capture 流量外，还要观察逐通道指数是否独立生效。

§4.3 已明确不作为保护点的内容（宏内部多精度切分、错峰启动、多 context 驻留本身、NIM 数值实现）不在本章列取证。

### 7.3 示例：某厂商产品的取证流程

以主-3（各任务域独立精度、同拍并行）为例：

1. 采购板卡或租用云实例；对购买/租用过程做公证，记录 SDK、驱动版本与校验和；
2. 查阅 SDK 文档，确认是否支持按任务或按层配置精度（含 W4A8 这类非对称组合）；
3. 单任务基线：分别运行 INT4 任务和 INT8 任务，记录各自的吞吐与延迟；
4. 并发测试：两个任务同时运行，测量总吞吐与各任务延迟；
   - 总吞吐约等于两者单独之和、各任务延迟不明显劣化 → 支持独立任务域以不同精度并行；
   - 总吞吐明显低于两者之和 → 更接近不同精度串行或共享执行单元，该保护点需重新核对；
5. 排除性检查：profiler 或计时结果显示没有按精度分时串行；重复多轮结果稳定；
6. 结论：该产品支持多任务不同精度的并行执行。

从-1 可加一条数值探针：给不同输出通道设置不同的权重指数范围，若各通道误差只由本通道 EW 决定，且 capture 窗口内没有 LW 流量，则支持 Core 级 EW 分区与逐通道对阶累加。

其余保护点按同一结构展开：文档锁定接口 → 测试观察行为 → 排除性检查 → 结论。

### 7.4 测试、抓包与反编译的具体分析

- **测试**：适用于可购买或可租用的产品。要求构造单算子、输出可直接观测的测试程序；量取 footprint、时延、吞吐与数值误差；每个量重复多轮并记录时钟、温度。测试只覆盖行为，不直接证明内部结构。
- **抓包**：仅适用于云服务形态。能取得 API 层的精度声明、算子列表和性能数字，不能取得内部实现；可作为入口证据，不能单独支撑机制类特征。
- **反编译**：适用于 SDK 中的量化工具、格式转换器与调度 API 的公开头文件或符号表。商用 SDK 多为二进制分发，可获得的通常是接口定义而非实现，需在检查项中写明这一限制。

### 7.5 边界与依赖

- 组合权项需要逐特征对应；组织层特征（主-2）主要通过产品文档和基准测试佐证，不依赖拆机直接识别两级组织；
- 举证责任在权利人一侧，不能依赖举证责任倒置；
- **本章随 §4 调整**：§4 的保护点增删、独权/从权归属或措辞变化，都会改变 7.2 的表格与 7.3 的示例；若某个保护点无法给出可观测表现，应优先调整 §4，而不是在 §7 中补论证。

### 7.6 外部例证：真实产品的公开材料

以下材料与本 Idea 无关，只用于说明"产品文档、参数表和公开演讲确实会暴露精度模式与阵列组织"这一取证入口在真实产品中存在。截图存于 [`docs/assets/patent-evidence/`](../assets/patent-evidence/)，来源与访问日期见该目录的 README。

| 材料 | 说明它能证明什么 |
|---|---|
| [NVIDIA A100 数据表 p1](../assets/patent-evidence/amp-a100-tf32-1.png) | 产品文档公开列出 TF32 / FP16 / INT8 及各自算力，说明精度模式属于商业公开信息 |
| [Groq TruePoint 技术文档 p3](../assets/patent-evidence/groq-truepoint-overview-3.png) | 厂商公开描述矩阵单元的数值表示与 FP/INT 原语，说明数值行为可以文档化 |
| [d-Matrix Corsair 白皮书 p7](../assets/patent-evidence/dmatrix-mxint-bfp-07.png) | CIM 产品公开 MXINT4/8/16、block floating point 及分格式算力表，说明 CIM 多精度与 BFP 有成熟公开面 |
| [d-Matrix Hot Chips 2025 p13](../assets/patent-evidence/dmatrix-bit-serial-13.png) | 公开 "dual bit-serial, 4-bit parallel MAC array"、MXINT8 64×64 / MXINT4 64×128，说明阵列组织与精度缩放可以被公开描述 |
| [微纳核芯官网首页](../assets/patent-evidence/nanocorechip-home.png) | 存算一体厂商公开以 3D-CIM 为产品卖点，说明 CIM 品类有对外技术叙事 |

运行时开关类证据已截取 NVIDIA cuBLAS 官方文档：[cublasSetMathMode()](../assets/patent-evidence/nvidia-cublas-setmathmode.png)、[CUBLAS_TF32_TENSOR_OP_MATH](../assets/patent-evidence/nvidia-cublas-tf32-math-mode.png) 与 [NVIDIA_TF32_OVERRIDE=0](../assets/patent-evidence/nvidia-cublas-tf32-override.png)，说明可通过公开 API 和运行时开关设计 A/B 差分测试。

这些材料只证明取证入口存在，不证明这些产品实施了本方案；引用时标注来源与访问日期。

## 8. 在先公开的对比文件检索情况

> 本章为**工作稿**：用于评审时说明检索覆盖范围、最接近对比文件与我方区别，以及尚未闭合的核查项。**不构成确定的新颖性或 FTO 结论**；最终对比文件清单与区别特征措辞由专利代理人定稿。证据原始出处统一在 `docs/reference/patents/search-results/`（公司级权项汇总、补充检索日志、分方向检索与 CIM 数据集）。截至本章编写，已归档并完成权项复核的文献共 **45 件（CN 23 + US 22）**，另有 NIM 专项补检 4 件 US。

### 8.1 检索口径与证据分级

- **来源**：CNIPA、Google Patents、USPTO 原文 PDF；分方向检索覆盖 CIM、数据流、权重驻留/切换、低精度/BFP、静态调度、三维集成。
- **分级**：A = 已核权项；B = 已核说明书/摘要；C = 检索摘要或二手线索。**C 级不支撑权项结论**。
- **法律状态单列**：授权 / 公开在审 / pending / 论文分别标注；pending 与论文只作背景或监控项，不作授权障碍或 FTO 结论。
- **边界**：未系统枚举全部 continuation 与全球同族；零命中只表示既定范围内未检出，不等于没有专利。

### 8.2 最接近对比文件与区别点（按技术主题）

下表按**与保护点对应的技术主题**组织，而非按申请人罗列。"区别点"列对应 §4.1 的差异化假设；标注"待核"的项需在定稿前回核原文。

| 主题 | 对比文件（号 / 申请人 / 状态） | 对比文件披露 | 我们的区别 |
|---|---|---|---|
| **CIM + 确定性数据流 / LPU** | US11243880B1、US11868250B1、US12411762B2、US11360934B1（均 Groq，授权） | 功能切片、superlane、stream、编译期静态调度；无 CIM、无 bit-serial 多精度阵列 | 用权重驻留 CIM 宏 + Core/Cluster/Plane 组织等算力替换 MXM；**阵列层级与独立任务域**是新增 |
| **BFP 预对齐 + 指数回赋** | ReDCIM（JSSC 2023 论文）；华中科大 CN116594954A（公开）；南科大 CN122152372A（公开）；东南大学 CN122691554A（公开）；阿里 CN113805940B（授权） | "预对齐 + 存内整数尾数 MAC + 指数回赋"骨架已公开；华中科大含双侧对阶与动态部署 | 骨架不作创新点；差异在**权重 INT 量化 + 组级 EW、尾数不右移**（vs ReDCIM 双侧 FP 尾数右移驻留），及 NIM 位于 stream 通路、与确定性时序耦合 |
| **NIM / 数值转换单元** | Groq US20220075598A1（公开）；US20250370927A1（**pending**，claim 18 写 NIM）；US11301212B1（授权）；US10725741B2 / US10853037B1（授权，compressed carry） | Groq NIM 仅格式转换，不做预对齐、无独立任务通道；NIM 未进入授权权项 | NIM per-Plane 多通道 + 激活预对齐 + 指数回赋 + 静态写回；**US20250370927A1 为 pending 监控项，不作阻断** |
| **权重多 context 驻留 / 切换** | Axelera US20250130771A1（公开）；清微 CN122733787A（公开）；清微 CN122045135A（公开） | 多权重集驻留、计算期预取、active-set 切换已公开 | **驻留本身不主张**（§4.3）；我们只在其上做 **Core 级滚动 IW + Cluster 就绪判定**（§3.5） |
| **多精度 / 可重构 CIM 阵列** | 中科奕芯 CN120469962A（公开）；清微 CN116303225A（公开）；清华 CN122885319A（公开，方向为加密 VMM）；ReDCIM / Column-MAC / UNPU（论文） | 宏内部多精度切分、可重构累加器已公开 | **宏内部结构不主张**（§4.3）；我们的多精度体现在任务域级独立配置与输出通路 |
| **错峰启动 / 静态调度** | Simple Machines US11048661B2（授权）；Intel US12147836B2（授权）；清微 CN121833570A（公开） | 按 schedule 插入延迟、静态调度已公开 | 错峰启动继承 baseline Supercell 的 stagger，**不主张**；我们主张的是与 CIM 结果通路耦合的固定交错写回 |

### 8.3 误归类与排除记录（节选）

以下为检索中已完成核对的典型排除项，说明检索并非照单全收：

- **EnCharge / Princeton**：US11669446B2 为 Princeton University 专利，不计入 EnCharge；
- **清微 CN122549501A**：摘要把两类 chiplet 的配置写反，技术对照以独权与说明书一致配置为准；
- **东方算芯 CN120909655B**："指令调度"实为时间戳/性能统计电路，非静态指令调度器；
- **US11392537B2**：受让人为 Microsoft Technology Licensing LLC，非 Qualcomm；
- **微纳核芯系列**：同日同申请人/发明人群体不自动等于法律同族。

### 8.4 待核查与边界（未闭合项）

1. **ReDCIM 团队（清华涂锋斌 / 尹首一等）的中国专利**：是否已有 FP/INT 统一管线权项——**这是当前最大的未闭合点**，直接影响 BFP 通路的新颖性判断，建议补申请人 = 清华大学 + 发明人检索。
2. **Groq US20250370927A1（NIM claim 18）实审走向**：pending，建议 6–12 个月后复查是否授权及 claim 是否保留。
3. **中科奕芯 CN120469962A**：在审，跟踪实审。
4. **阿里 CN113805940B 权 7 方法独权**：与我方 MEM 组织的二次核对。
5. **平头哥 CN119473214B 独热归约独权**：我方组级指数搜索须写死为比较器树以规避（已纳入 §3.4 设计约束）。

### 8.5 与 §4 差异化假设的回扣

- **已证实**：Groq baseline 无 CIM、NIM 不做预对齐（§8.2 主题 1、3）；权重多 context 驻留与宏内部多精度属现有技术（§8.2 主题 4、5），已据此在 §4.3 排除。
- **组合创新的论证**：§4.1 的"只有结合才需要这套组织"由 §8.2 主题对照表支撑——各对比文件均未同时覆盖"任务域独立精度 + NIM 多通道 + 确定性 stream 写回"。
- **措辞口径**：本章为工作稿；差异化假设经 §8.2 对照后成立与否，以代理人定稿与补充检索为准。

## 9. 配图清单与呈现要求

配图用于解释整体技术方案、数据流与时序，不要求每张图都对应保护点。已有的 CIM Macro/子阵列结构可以作为技术前提呈现，但需在备注中区分“技术前提”和“本方案的机制”，避免将已有结构误述为本方案创新。以下 **PNG 为当前正式配图**，早前的 SVG 仅作为草稿参考；不使用 AI 生成图或网络图，不直接搬用 ReDCIM、Groq 等外部论文或专利图，不展开晶体管、版图或具体比较器电路。

1. **图 1：整体阵列组织与 Cluster 广播域**
   - 文件：[cim-mxm-overall-architecture.png](../assets/patent-idea-review/cim-mxm-overall-architecture.png)；
   - 呈现 CIM-MXM Plane、20 条 SuperLane、每 SL 的 4 个 CIM Cluster，以及对应的 NIM tile；
   - 标出每个 Cluster 的独立 activation 组（图中为 16 Byte）和“独立任务与激活广播域”的关系；
   - 用于建立整体空间结构，对应 §3.2。
2. **图 2：CIM 子阵列与多精度归约**
   - 文件：[cim-subarray-architecture.png](../assets/patent-idea-review/cim-subarray-architecture.png)；
   - 呈现四个 column 组、位单元、局部读出计算电路和多级输出加法树；
   - 展示 4b/8b/16b 模式及对应的 4 组/2 组/1 组输出关系，说明同一子阵列如何支持不同权重精度；
   - 作为 Macro/子阵列的技术前提，不单独作为本方案创新点，对应 §3.1。
3. **图 3：CIM Core、Cluster 与 Macro 的内部组织**
   - 文件：[cim-cluster-architecture.png](../assets/patent-idea-review/cim-cluster-architecture.png)；
   - 左侧呈现 Core 由 4 个 Macro 构成、多个 Core 组成 Cluster；右侧展开 Macro 内的存储体、16 个子阵列、列单元、局部读出计算、多级输出加法树、移位累加器和部分和缓存；
   - 用于连接 Macro 内部结构与 Core/Cluster 的层级组织，对应 §3.1、§3.2。
4. **图 4：Core 错峰启动与结果阶梯流**
   - 文件：[cim-mxm-compute-pipeline.png](../assets/patent-idea-review/cim-mxm-compute-pipeline.png)；
   - 呈现不同 SuperLane、不同 Cluster 内 Core 按 T+0、T+1…逐拍启动的关系；
   - 说明 Cluster 是独立任务与 activation 广播域，Core 错峰形成与 ICU command wave 对齐的结果节奏；
   - 用于说明结果转置前的时序组织，对应 §3.2.5–§3.2.6。
5. **图 5：NIM Datapath**
   - 文件：[nim-datapath.png](../assets/patent-idea-review/nim-datapath.png)；
   - 输入侧呈现激活捕获、激活指数比较器树、尾数预对齐移位、共享指数 EI、移位寄存器堆及 Cluster 逐周期输入；
   - 结果侧呈现跨 SuperLane 累加（指数加法、尾数移位累加）、累加结果捕捉、前导零检测、指数调整、浮点归一化和 SRF 结果写回（256 Byte/cycle，16 stream）；
   - Core 级 EW buffer、EW_base 预计算及 EI 的就绪合同按 §3.4 的文字说明执行，图 5 重点展示数据通路，不展开 EW 缓存内部结构。
6. **图 6：权重装载、切换与计算重叠**
   - 文件：[cim-mxm-compute-timing-pipeline.png](../assets/patent-idea-review/cim-mxm-compute-timing-pipeline.png)；
   - 呈现 LW 在 0–160 拍装载权重 B、ACC 使用权重 A 与装载重叠、IW 按 Core 滚动切换到权重 B，以及随后 ACC 使用 B；
   - 用于说明权重驻留、后台预装和连续切换，对应 §3.3、§3.5。

各图只回答一个主要问题，不把全部层级、位宽和时序细节压入同一张图。若胶片篇幅允许，图 4 与图 5 可分别拆为“组织图”和“时序图”两页，避免过度压缩。
