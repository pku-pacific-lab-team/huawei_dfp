import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.core.ascend.simulator import AscendSimulator
from src.core.tpu.simulator import TPUSimulator
from src.core.tsp.simulator import TSPSimulator
from src.core.tsp_cim.simulator import TSPCIMSimulator
from src.hardware.ascend import AscendSpec
from src.hardware.tpu import TPUSpec
from src.utils.tsp_cim_config import TSPCIMConfigLoader
from src.utils.workload import parse_workloads

base_path=ROOT/'tmp/config_annotation_baseline.json'
base=json.loads(base_path.read_text(encoding='utf-8'))
configs={name:json.loads((ROOT/'configs/hardware'/f'{name}.json').read_text(encoding='utf-8')) for name in base['configs']}
for name,config in configs.items():
    assert {k:v for k,v in config.items() if k!='_documentation'}==base['configs'][name], name
ld=TSPCIMConfigLoader(); cim=ld.create_tsp_spec(ld.load_hardware_config())
sims={'ascend':AscendSimulator(AscendSpec(configs['ascend910_reference'])),
      'tpu':TPUSimulator(TPUSpec(configs['tpu_v4_reference'])),
      'tsp':TSPSimulator(cim.native_reference_spec),'tsp_cim':TSPCIMSimulator(cim)}
records=[]
for entry in base['reports']:
    shape=entry['shape']; name=entry['name']; sim=sims[name]
    w=parse_workloads({'gemm':dict(zip('MKN',shape)),'data_format':'INT8'})[0]
    options=dict(mode=entry['mode'],**entry['policy'])
    result=sim.simulate(w,**options) if name in ('ascend','tpu') else sim.simulate(*shape,**options)
    assert result==entry['report'], (name, shape, options)
    records.append({k:v for k,v in entry.items() if k!='report'})
out=ROOT/'validation/config_documentation';out.mkdir(parents=True,exist_ok=True)
summary={
    'scope':'Root-only maintenance annotations for the four hardware JSON profiles.',
    'baseline_sha256':hashlib.sha256(base_path.read_bytes()).hexdigest(),
    'baseline_location':'tmp/config_annotation_baseline.json (ignored local pre-change snapshot)',
    'runtime_inputs_unchanged':True,
    'report_count':len(records),
    'complete_reports_equal':True,
    'equality_includes':'All counts, timing, schedule, memory, provenance, execution_contract, schema versions and runtime reference IDs; no fields excluded.',
    'configurations':list(configs),
    'cases':records,
}
(out/'comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Four configurations unchanged after removing _documentation; all',len(records),'complete reports identical')
