# 架构、参数与验收说明

整理日期：2026-11-17（America/Los_Angeles）。本文汇总当前本地实现；来源材料的原始版本日期和 Git blob 保持不变。

本文是四架构及共享 CIM Macro 的现行技术说明。安装与运行见 [README](README.md)，参数来源核验结果见[核验结论](#source-audit)及[逐项证据台账](calibration/parameter_source_audit.json)。参数的完整元数据以链接的 JSON 为准；本文中的未知项、假设和执行范围与代码对应。

- [四个仿真器的代码结构](#simulator-structure)
- [共同约定与报告口径](#conventions)
- [Ascend 910](#ascend)
- [TPU v4](#tpu)
- [原生 TSP](#tsp)与[完整参数来源表](#tsp-parameters)
- [共享 CIM Macro 模型](#cim-macro)
- [CIM-TSP Core / Cluster / Plane](#cim-tsp)
- [文件组织与迁移](#migration)
- [验证与 issue #2 状态](#validation)
- [待确认参数与后续工作](#remaining)

<a id="simulator-structure"></a>

## 四个仿真器的代码结构

当前有四个独立 Python 仿真器类，分别服务 Ascend、TPU v4、原生 TSP 和 CIM-TSP。它们共享 GEMM 任务定义，按各自硬件边界进行分块和统计；没有统一的 Simulator 基类或公共事件调度器。下图表示共同的职责分层，具体实现仍由各入口选择。

```mermaid
flowchart LR
    W["workload JSON"] --> P["workload.py<br/>解析 Workload 与精度"]
    P --> E["四个 CLI 入口"]
    H["hardware JSON"] --> L["各架构 ConfigLoader"]
    L --> S["各架构 Spec<br/>校验参数、派生库存"]
    E --> X["对应 Simulator.simulate"]
    S --> X
    X --> T["对应 tiling<br/>检查容量或确定物理分片"]
    T -->|分块计划| X
    X --> R["计数、可选解析时延、来源与库存"]
    R --> O["终端 / JSON 报告"]
```

### 从入口到结果的调用链

四个入口均先构造硬件规格和任务，再调用仿真器；分块函数由 `simulate` 内部调用。`src/hardware` 负责描述和检查规格，`src/core` 负责分块与执行统计，`src/utils` 负责配置、任务和报告适配。

`src/core` 的 `ascend`、`tpu`、`tsp`、`tsp_cim` 四个架构包各含 `simulator.py` 和 `tiling.py`。`cim` 是 CIM-TSP 的支持包，保存 `macro_model.py` 和 Macro 聚合函数所在的 `simulator.py`，没有独立场景或 CLI。`tests` 对应四架构及 Macro 支持模型，跨架构检查归入 `tests/common`。硬件和工具层每种职责通常只有一个文件，继续采用架构前缀命名；详细位置与迁移关系见[目录迁移表](#directory-migration)。

| 仿真器 | 入口及规格装配 | 执行与分块 | 输出 |
|---|---|---|---|
| Ascend | [ascend.py](ascend.py) → [AscendConfigLoader](src/utils/ascend_config.py) → [AscendSpec](src/hardware/ascend.py) | [AscendSimulator.simulate](src/core/ascend/simulator.py) → [make_plan](src/core/ascend/tiling.py) | [ascend_report](src/utils/ascend_report.py)，报告 schema 4 |
| TPU v4 | [tpu.py](tpu.py) → [TPUConfigLoader](src/utils/tpu_config.py) → [TPUSpec](src/hardware/tpu.py) | [TPUSimulator.simulate](src/core/tpu/simulator.py) → [make_plan](src/core/tpu/tiling.py) | [tpu_report](src/utils/tpu_report.py)，报告 schema 4 |
| 原生 TSP | [tsp.py](tsp.py) → [run_reference / simulate_reference](src/utils/tsp_reference.py)；runner 使用 [TSPConfigLoader](src/utils/tsp_config.py) 构造 [TSPSpec](src/hardware/tsp.py) | [TSPSimulator.simulate](src/core/tsp/simulator.py) → [TSPTilingEngine](src/core/tsp/tiling.py) | [tsp_report](src/utils/tsp_report.py)，报告 schema 4 |
| CIM-TSP | [tsp_cim.py](tsp_cim.py) → [TSPCIMConfigLoader](src/utils/tsp_cim_config.py) → [TSPCIMSpec](src/hardware/tsp_cim.py) | [TSPCIMSimulator.simulate](src/core/tsp_cim/simulator.py) → [半片调度](src/core/tsp_cim/hemisphere.py) → [account_macro_tile](src/core/cim/simulator.py) → [CIMMacroModel / MacroContexts](src/core/cim/macro_model.py) | CLI 直接输出 JSON，报告 schema 5 |

Ascend/TPU 的 `simulate` 直接接收 `Workload` 对象；TSP/CIM-TSP 内核接收 `M,K,N` 与策略参数，外层 runner/CLI 补回完整的 workload 元数据。四者返回普通字典，统一指标定义不意味着报告 schema 或 API 完全相同。

### 四个执行内核分别做什么

| 维度 | Ascend | TPU v4 | 原生 TSP | CIM-TSP |
|---|---|---|---|---|
| 执行范围 | 一个 AI Core 的 Cube GEMM 路径 | 一个 TensorCore 的逻辑 GEMM | 一个 hemisphere 的 MEM/MXM/VXM 路径 | 一个 hemisphere：2 Plane、8 个跨 20 SuperLane 的 Cluster domain，3200 Macro |
| 数据/动作路径 | GM → L1 → L0A/L0B → Cube/L0C → UB → GM | HBM ↔ VMEM；聚合矩阵服务，C 在逻辑 VMEM 中跨 K 保留 | 本侧 MEM 装载权重、供给 activation → MXM；后续 K 分片读 PSUM，经 VXM 相加后回写 MEM | MEM → context 编程/复用 → 8 域逐位计算/归约 → 分布式 writer → MEM；跨 K 经 MEM/VXM 累加 |
| 分块依据 | L1/L0A/L0B/L0C/UB 可用容量；M/K/N 对齐 16/32/16；L1 K panel 与 L0 K block 分开 | 整体 A/B/C 必须装入 HBM；块内 A/B/C 装入 VMEM，超限缩块；不绑定 128×128 MXU 物理映射 | 检查整个补齐 A/B/C 在所选本侧 MEM slices 驻留；K≤320、N≤640，K/N 按 16 补齐，M 不补齐 | 固定域 K320×N640，K16×N32 Macro 分片；K/N 任务分派到 8 域，完整补齐 A/B/C 检查本侧容量 |
| 循环/复用 | 固定 MNK，输出驻留 L0C；不跨输出 tile 复用 A/B | 固定 MNK 的闭式求和；不跨输出块复用输入 | KNM/KMN/MKN/NKM；按 plane 权重 tag 避免重复安装 | M/K/N 六种排列；每个物理 Macro slot 的四个 context 保存独立权重 tag |
| 保留的执行状态 | 阶段 byte/MAC 累加、buffer 峰值、当前输出块 | 块数和闭式计数；不构造逐块事件 | `plane_tags` 跟踪权重驻留，`psum_progress` 检查 K 归约顺序 | 各域 `MacroContexts` 与 context 释放 wave；共享带宽预约及 wave 起止，未模拟逐 Core busy 状态 |
| 主要结果 | 补齐 MAC、五条路径 byte/次数、buffer 峰值 | 有效 MAC、HBM/VMEM 逻辑 payload、PSUM 读写；物理补齐量未评估 | 补齐 MAC、权重安装、MEM/stream byte、VXM add | useful/issued MAC、逐位动作、编程 wordline、context 切换、逻辑广播/归约 |
| 时间模型 | 显式配置服务，null 必需项报错；计算与五阶段搬运串行相加 | 单 TensorCore 七阶段串行估算，块内 MXU 分批并行；VMEM 服务显式配置为 assumed | 显式配置服务，null 必需项报错；安装 + 首行 + 后续行间隔，tile 间串行 | 半片 wave 行流水；LW 使用剩余共享带宽后台装载；资源约束与假设显式报告 |

三点差异直接影响结果解释：Ascend 明确模拟五条核内/核侧搬运路径，TPU 根据逻辑端点 payload 估算串行搬运；TSP/CIM-TSP 均检查完整任务在单侧 MEM 驻留，但尾部补齐和调度策略不同；CIM 的 `bit_serial_cycles` 是所有 Macro 的局部动作总和，不能与任务总周期直接比较。四者的参考配置均可在所声明的假设下运行 timing；硬件未标定项继续保留，代理服务单独披露。

### 配置依赖与公共实现

Ascend、TPU、TSP 各加载一份自身的参考配置。CIM-TSP 的规格由三份配置组合：`tsp_cim.json` 提供替换后的 Core/Cluster/Plane 与 NIM/LW 设计，`cim_macro.json` 提供 Macro，`tsp.json` 提供共享 MEM、lane、stream、VXM、clock 规格及原生对比基线。Loader 解析引用，`TSPCIMSpec` 检查跨配置几何和 stream 预算一致性。

```mermaid
flowchart LR
    TC["tsp_cim.json"] --> CS["TSPCIMSpec"]
    NC["tsp.json"] --> CS
    MC["cim_macro.json"] --> CS
    CS --> CI["TSPCIMSimulator"]
    CI --> H["hemisphere static waves + MEM/stream resources"]
    H --> C["account_macro_tile"]
    C --> M["CIMMacroModel + MacroContexts"]
    CI -.->|compare_mxm| R["simulate_reference"]
    N["tsp.py / run_reference"] --> R
    R --> NS["TSPSimulator"]
```

- [workload.py](src/utils/workload.py) 统一 `A[M,K] × B[K,N]`、INT8/INT32 约定、精度覆盖与路径解析；[dataformat.py](src/hardware/dataformat.py) 提供格式定义。
- [parameters.py](src/hardware/parameters.py) 的严格字段校验被 TSP、Macro、CIM-TSP 共用；Ascend/TPU 各自保留参数类及校验规则。
- [macro_model.py](src/core/cim/macro_model.py) 是 CIM-TSP 唯一的 Macro 动作实现；[simulator.py](src/core/cim/simulator.py) 的 `account_macro_tile` 在半片与单域路径间共享 context 复用和局部动作聚合。该文件并不是四架构的统一调度器。
- [tsp_reference.py](src/utils/tsp_reference.py) 确保独立 TSP 与 CIM 原生对比使用同一个 `TSPSimulator`。半片比较共享实际 MEM/stream 分配及 M 分组；报告解析周期比并列明策略差异，speedup/energy_ratio 为 null。
- [parameter_source_audit.json](calibration/parameter_source_audit.json) 与对应回归绑定配置版本、参数证据和核验判断；审计台账不参与运行期性能计算。

四个仿真器均不持有真实 A/B/C 数组，不执行数值 GEMM，也没有整片任务调度、逐周期资源争用或完整能耗/面积求解。推荐读代码时从各入口的 `main` 开始，依次看 Spec、`simulate`、tiling，最后看报告和测试；详细算法与限制见后续各架构章节。

<a id="conventions"></a>

## 1. 共同约定与报告口径

本阶段对应 [issue #2](https://github.com/pku-pacific-lab-team/huawei_dfp/issues/2) 的硬件规格、参数追溯、派生约束、动作与库存输入，以及四架构独立 INT8 GEMM 入口。CIM 采用现行项目评审材料中的 Core/Cluster/Plane 方案。

### 任务、范围和单位

任务是 `A[M,K] × B[K,N] → C[M,N]`。四个入口共用 [workload 解析](src/utils/workload.py)，当前参考执行支持 INT8 输入、INT32 累加/输出。唯一自带负载为 `tiny_gemm.json`（M512/K256/N512、INT8），四入口默认加载；可用 `--workload` 指定其他 GEMM 配置，显式精度覆盖仍记录在报告中。模型统计运算、搬运和逻辑动作，不计算真实矩阵数值或验证溢出语义。

| 入口 | 默认执行范围 | 输入/输出边界 | timing 能力 |
| --- | --- | --- | --- |
| `ascend.py` | 单 AI Core 的 Cube GEMM 路径 | 预排布 A/B 在 GM → 补齐 INT32 C 在 GM | 支持串行阶段公式；所有服务从配置读取，缺速率时拒绝 |
| `tpu.py` | 单 TensorCore 逻辑 GEMM | 逻辑 A/B 在 HBM → 逻辑 INT32 C 在 HBM | 串行任务估算，块内 MXU 分批并行，假设随报告披露 |
| `tsp.py` | 单 hemisphere | 已排布 A/B 在本侧 MEM → INT32 C/PSUM 在本侧 MEM | 支持压缩行服务公式；按任务使用配置值或显式代理 |
| `tsp_cim.py` | 单 hemisphere | 本侧 MEM 的 INT8 A/B → MEM 的 INT32 C | 8 域静态 wave、受约束行流水与后台 LW；假设随报告披露 |

CIM-TSP 物理 Core 为 4 Macro，具体层级由 `tsp_cim.json` 定义。issue #2 的四架构指 Ascend、TPU、原生 TSP、CIM-TSP。

一次 MAC 按 2 op；有效运算为 `2MKN`。尾块补齐、物理活动和有效运算分别报告。容量采用 byte/KiB/MiB/GiB；GB/s 为十进制，Gbit/s 与 byte/s 转换须乘 8。规格峰值用实际声明的作用域和时钟推导；不把单核/单侧周期除以芯片资源数量。不同输入输出边界、执行范围和动作层级的结果不能直接排名性能或能效。

<a id="explicit-model-parameters"></a>

### 显式模型参数与 JSON 读取约定

已有服务代理直接填写 value，并标 status=assumed；conditions 写明公式、参考条件、固定值是否需随硬件依据手工更新。null 只表示尚无该字段的可用数值，不再触发隐藏的服务默认值。剩余 null 的 conditions 明确说明当前仅作规格/库存或为后续算子预留。Macro 局部 timing 参数已退役，不再要求补齐。

TSP 自 schema 3 起，时间参数的 value 均为固定能力或固定延迟，已移除 derivation、reference_value 和 configured_derivation；当前 schema 4 保持这套服务定义。安装端口上限 10240 B/cycle 与 VXM 加法能力 320 op/cycle 不随分配改变；安装传播延迟为 19 cycle，额外 VXM 流水延迟为 0。实际带宽、载荷服务和逐块行计算时间由执行公式计算，放在 timing.derived_services；timing.parameters 始终保留配置原值。

固定服务直接修改 value，保持其真实来源状态。Ascend 六项与 TPU VMEM 带宽是固定配置，改变核数、阵列或时钟后应按 conditions 显式更新需要联动的服务值。计数算法和默认时间不变，配置身份、缺参列表和派生规格随新参数更新；assumed 输入产生的规格峰值仍为模型假设。

### 参数和缺项

四架构参考规格及共享 Macro 参数都记录数值、单位、作用域、来源、版本、条件和状态。Ascend/TPU 使用 `version`，TSP/Macro/CIM-TSP 使用 `source_version`，后者还包含 `verification`。已移除的通用 32 Macro 场景不属于现行硬件规格。

| 状态 | 含义 |
| --- | --- |
| `documented` | 有文档或项目要求支持；来源类型及核验状态决定证据强度 |
| `measured` | 来源明确的测量值 |
| `assumed` | 为场景或模型明确采用的假设 |
| `unknown` | 未确定；数值为 `null`，不会静默补值 |

未知值不会静默按零处理。已有代理现在以 assumed 数值直接写入硬件 JSON；硬件参数保持固定，任务派生服务单独报告。必需容量或服务为 null 时拒绝相应请求，不再因 null 自动启用代理。派生规格保留假设身份，documented 和测试通过均不代表芯片实测。

### 报告字段

各入口保持独立 schema；共享的是指标定义。消费报告时先检查 `model`、`schema_version`、`boundary` 和 `mode`。

四个 CLI 默认使用 `timing`，报告同时包含计数与解析时延；`--mode count` 仅统计工作量，核心模拟器与原生比较 API 的默认 count 不变。

四个 CLI 成功运行后默认写入工程根目录的 `results/<架构>.json`，文件名分别为 `ascend.json`、`tpu.json`、`tsp.json`、`tsp_cim.json`；输出父目录自动创建，终端同时显示报告路径。同一架构再次成功运行会覆盖对应文件，任务检查或仿真失败时不写入报告。`--output` 可覆盖默认位置，显式相对路径仍相对于启动时的工作目录；默认位置不随工作目录变化。JSON 字段、计数和模型边界保持原义。

| 内容 | 当前 JSON 位置及差异 |
| --- | --- |
| 任务与范围 | `workload`、`boundary`；分块策略在 Ascend 的 `strategy`、TPU 的 `counting_policy`、TSP/CIM 的 `policy` |
| 有效运算 | Ascend/TPU/TSP：`counts.useful_ops`；CIM-TSP：`2 × counts.useful_mac` |
| 补齐工作量 | Ascend/TSP：`counts.executed_padded_ops`；CIM：`2 × counts.issued_mac`；TPU 未评估物理补齐，该项为 null |
| 动作输入 | `action_counts`；核侧请求、逻辑 payload、Macro 捕获和逻辑归约各有边界，不等于统一的物理事务 |
| 派生量与来源 | `hardware_derived`、`parameter_provenance` |
| 硬件层级 | TPU：`hardware_hierarchy` 的 MXU/TensorCore/Chip；CIM-TSP：`topology`；结构层级不表示已执行整片任务 |
| 面积库存 | Ascend：`hardware_derived.area_inventory`；TSP：`hardware_inventory`；TPU/CIM-TSP 整片库存：`hardware_inventory.chip`；TPU 每核库存：`hardware_inventory.per_tensorcore` |
| 缺参 | Ascend/TSP 的 timing 缺项在 `timing.missing_parameters`；TPU/CIM-TSP 另有顶层 `missing_parameters`，CIM 不把共享 Nonlinear 预留项列为 GEMM 缺参；完整状态以 provenance 为准 |
| 时间、能耗、面积 | count 下时间为 null，能耗未评估；Ascend 面积 null 位于库存，其他入口另有 `area.total_mm2`；不同 schema 的状态字符串有差异 |

动作摘要与端点动作可能描述同一工作，不能重复计费。面积库存是单元数量和存储容量，不是 mm²；成本缺失时不输出能效/面积效率。规格峰值、Macro 忙碌周期总和与模拟得到的墙钟时间是不同指标。

<a id="ascend"></a>

## 2. Ascend 910

配置：[ascend910_reference.json](configs/hardware/ascend910_reference.json)。实现：[AscendSpec](src/hardware/ascend.py)、[Tiling/Simulator](src/core/ascend/)、[入口](ascend.py)。

### 执行边界

类型为**粗粒度 analytical 性能模型**。执行范围是**单 AI Core 的 Cube GEMM 数据路径**，不是完整 AI Core 的所有算子，更不是完整芯片执行时间。

芯片规格中的 32 核用于规格推导和面积库存。JSON 中 GM 服务的 37.5 B/cycle 来自 1200/32 的参考均分，但它是显式固定值，修改核数或 HBM 时需同步更新该服务值；不将核级延迟除以核数。Vector 尚不执行算子，特殊函数归入未来的 Vector 操作服务；不单列 SFU 资源。

```text
芯片规格（仅库存与峰值推导）
  Core 数 / L2 / HBM / NoC / 互联
                 |
                 | 核级参数供下方单核使用，不进行多核调度
                 v
预排布 INT8 A、B 在 GM
          |
          | gm_l1：有效端到端搬运服务
          v
         L1
       /    \
 l1_l0a    l1_l0b
    |         |
   L0A       L0B
       \    /
        Cube       MAC 含 INT32 累加
          |
         L0C       保留同一输出块的全部 K 归约
          |
       l0c_ub
          |
          UB
          |
        ub_gm
          |
补齐后的 INT32 C 在 GM
```

不计主机传输/启动、ND 布局转换、输出去 padding；不计算真实矩阵值。L0C→UB→GM 的 INT32 导出是显式建模假设，尚未在原始 910/CANN 上核验。GM 搬运统计是核侧请求量，不是经 L2 缓存之后的真实 HBM 流量。

### 参数依据与派生约束

每个数值参数都包含 `value/unit/scope/status/source/version/conditions`，参数名称由 JSON 路径标识。

| 参数组 | 作用域 | 当前依据或状态 |
|---|---|---|
| INT8 分形 M/K/N = 16/32/16 | core | CANN 8.0.0 alpha003 Mmad 功能说明、表 3；形状与 INT8→INT32 类型支持，不保证一周期完成 |
| architectural_cores = 32；Cube/Vector 各 1 单元/core | chip / core | Huawei 2022 原文 §4.1.1、图 9 已核对；原始 Ascend 910/Ascend-Max，不能推广到 910B/910C |
| 1 GHz | core | Huawei 2022 表 5 已确认参考频率；不代表目标 SKU 的实测 DVFS |
| L1 1 MB，L0A/B 各 64 KB，L0C/UB 各 256 KB | core | 图 9 有明确物理容量标签；当前 JSON 的二进制 byte 换算仍标 assumed；usable=physical 也是场景假设 |
| 32 MiB 共享片上存储 | chip | Huawei 2020 演示第 19 页写 On-chip Buffer 32 MB；L2 映射及 MB→MiB 解释仍标 assumed |
| HBM 1.2 TB/s → 1200 byte/reference-cycle | chip | Huawei 2022 §4.1.1、§4.1.3；除以 1 GHz 参考核频率，十进制带宽，documented 派生库存；不填入单核路径 |
| HBM byte 容量 | chip | 2020 演示第 20 页写 32 GB HBM Gen2；GB/GiB 精确归一化未确定，数值保留 null，原始标签入台账 |
| L2 带宽 | chip | 2022 表 5 为 94 GB/s/core（约 3 TB/s/chip），§4.1.3 写 4 TB/s；2020 演示写 3 TB/s。口径冲突，保留 null |
| NoC / 片外接口资料 | link / interface | 4×6 mesh、相邻链路 2 GHz/1024 bit/256 GB/s 和接口种类保留在来源台账；schema 4 移除未定义口径的芯片聚合速率，不参与当前执行 |
| Cube MAC/cycle，五条路径 byte/cycle | core | assumed；将原有模型代理显式写入 JSON，取法见 conditions；实际有效硬件服务仍未标定 |
| Vector 操作吞吐、特殊函数 | core | schema 4 移除通用 FP32 速率及独立 SFU 数量/速率；保留 Vector 单元库存，未来按操作与精度描述服务及共享资源 |

上述 **Huawei 2022** 指 [Communications of HUAWEI RESEARCH，June 2022](https://www-file.huawei.com/admin/asset/v1/pro/view/6ca306adab0a4852bacffce25f5573ec.pdf)：图 9 在 PDF 第 108 页/印刷第 104 页，表 5 与 §4.1.1–4.1.3 在 PDF 第 113–114 页/印刷第 109–110 页。**Huawei 2020** 指 [DaVinci 演示](https://www.cmc.ca/wp-content/uploads/2020/03/Zhan-Xu-Huawei.pdf)。[CANN Mmad](https://www.hiascend.com/doc_center/source/zh/CANNCommunityEdition/800alpha003/apiref/ascendcopapi/atlasascendc_api_07_0249.html)使用固定 API 版本。文件哈希、逐项位置及原始规格见[台账](calibration/parameter_source_audit.json)。

原文的 512 TOPS 名义 INT8 算力，以及表 7 的 456 mm² compute die、168 mm² I/O die 已单独记录；面积不是本模型推导结果，两者之和也不等于含 HBM/封装的整片面积。

容量检查：核内 usable ≤ physical；分块占用不得超过核内 usable。HBM 容量当前只用于库存，尚未实现任务显存容量校验；L2 带宽为非执行规格记录，不叠加到整体 GM 服务中。面积库存使用 physical，并区分逐核 SRAM、共享 L2、片外 HBM；没有面积系数时不输出 mm²。

派生公式：

- 一次 MAC 按 2 op；单 INT8 分形有 16×32×16 = 8192 MAC。
- 核峰值 TOPS = 核 MAC/cycle × 2 × GHz / 1000。
- 芯片理论峰值 = 核峰值 × 架构核数；这不是多核仿真结果。
- 带宽 Gbit/s = byte/cycle × GHz × 8。
- 芯片各类核内单元/存储库存 = 每核物理库存 × 架构核数；共享存储只计一次。
- 所需输入缺失时对应结果为 null，其他有依据的计数仍可输出。

### 分块、动作与时间公式

1. **读取任务。** 使用公共 workload，获取 M/K/N、声明精度及显式覆盖。只支持 INT8×INT8、INT32 累加和输出。不会默默把 BF16 改成 INT8。
2. **选择分块。** 默认 tile 上界 M/K/N=64/128/64，L1 K 面板上界 256。依据容量缩小 tile；M/N 向 16、K 向 32 对齐。输入 1 byte/元素、输出 4 byte/元素。
3. **检查容量。** L1 占用 (m+n)×k1；L0A=m×k；L0B=k×n；L0C=4mn；UB 分块导出。单缓冲，不建立 buffer 槽或生命周期事件。
4. **累计搬运量。** 每个 M/N 输出块从 GM 读完其 K 面板；A、B 分别送到 L0A/L0B。不假设不同输出块间的输入复用。
5. **累计计算量。** 每个内层块执行 mkn MAC。包含乘加和 K 方向累加；无需独立的固定 Accumulate 周期。
6. **输出。** 完成整个 K 后才把 C 经 UB 写回 GM。循环中的 K 面板不反复导出部分和。
7. **汇总。** 分开记录有效运算 2MKN 与补齐后执行运算 2Σmkn；输出各路径 byte、MAC action、容量峰值、规格库存和来源表。

`count` 不计算时间。CLI 默认采用 `timing`，六项服务率（Cube 一项、搬运五项）全部来自配置；任何一项为 null 均拒绝 timing。阶段公式保持原义：

```text
每个计算块周期 = ceil(m × k × n / core_MACs_per_cycle)
每次搬运周期   = ceil(bytes / route_bytes_per_cycle)
总周期         = Σ计算块周期 + Σ搬运周期
时间 ns        = 总周期 / GHz
有效吞吐 GOPS  = 2MKN / 时间 ns
```

这是串行阶段求和，不模拟流水重叠、指令发射、依赖间隔或存储争用。缺少时钟时仍可给出周期，ns、吞吐和峰值换算保持 null。芯片级带宽列入规格，GM 有效搬运时长已经覆盖所声明的路径成本。

### Ascend 显式配置的模型服务（2026-11-16）

六项代理均已写入 JSON 的 value，status=assumed，conditions 解释取法与条件。timing.parameters 的 selection=configured 表示读取固定配置；proxy_parameters 保留为已配置假设服务列表。missing_parameters 仅列仍为空的服务，参考配置中为空列表。AscendSpec.require_timing() 与模拟器使用同一缺参检查。

| 原字段 | 参考配置下的代理 | 条件 |
|---|---|---|
| `cube.macs_per_cycle` | 16×32×16×1 = 8192 MAC/cycle | 假设每 Cube 每周期服务一个完整 INT8 分形，含累加；不是公开资料证明的一周期指令时序 |
| `transfers.gm_l1`、`transfers.ub_gm` | 1200/32 = 37.5 B/cycle | 整片 HBM 名义 byte/reference-cycle 均分；作为完整 GM 路径代理，不另计 HBM/NoC，也不借用闲核带宽 |
| `transfers.l1_l0a`、`transfers.l1_l0b` | 16×32、32×16 = 512 B/cycle | 假设每周期搬一个输入分形，不声称等于实际端口宽度 |
| `transfers.l0c_ub` | 16×16×4 = 1024 B/cycle | 假设每周期搬一个 INT32 输出分形，不声称为有效实测带宽 |

配置值沿用原分形几何、Cube 数量、核数和 HBM 均分代理。取法是模型假设，不是持续硬件吞吐证据。任何必需服务缺失均拒绝 timing，即使整片 HBM 已知也不会自动补齐。配置服务齐全时不再依赖 HBM 库存值；修改取法的依据需显式更新服务值。固定启动、填充及 DMA 延迟仍省略。

报告保留 `model=single_core_serial_proxy_v1`、阶段分解与假设列表。动作计数不变，但 provenance/missing_parameters 与派生峰值反映显式 assumed 服务；例如 8192 MAC/cycle 推导的单核 16.384 TOPS 仍是假设规格。16/32/16 阶段为 1+28+1+1+1+28 = **60 cycle / 60 ns**；tiny 为 **97216 cycle / 97.216 μs**。

手算回归使用**人工参数**：Cube=8192 MAC/cycle、五条路径=512 byte/cycle。16×32×16 的任务得到 1 个计算周期、8 个搬运周期，共 9 cycle。该数值只验证公式，不是 Ascend 910 实测性能。

tiny INT8 默认分块得到 8,192 个基本分形、134,217,728 有效运算、2,097,152 byte 核侧输入请求、1,048,576 byte GM 输出。GM 核侧请求不等于经过 L2 后的真实 HBM 流量。

<a id="tpu"></a>

## 3. TPU v4

配置：[tpu_v4_reference.json](configs/hardware/tpu_v4_reference.json)。实现：[TPUSpec](src/hardware/tpu.py)、[Tiling/Simulator](src/core/tpu/)、[入口](tpu.py)。目标为 TPU v4，未采用 TPUv4i 配置替代。

整片建模采用与其他参考仿真器一致的“局部执行 + 整片规格/库存”边界：`TPUSpec` 显式给出 MXU → TensorCore → Chip 的结构、三级规格峰值以及每核/整片资源数量，执行端仍统计一个 TensorCore 的逻辑 GEMM。该扩展对应 issue #2 的硬件层级、派生算力和面积库存输入。

单 TensorCore count 使用逻辑 INT8/INT32 约定，不宣称已核验 TPU 原生整数数值语义、溢出规则或编译器实现。count 不做逐 MXU 分配或物理补齐；可选 timing 在同一逻辑程序内增加 MXU 分批和阵列填充/排空近似。不模拟 CMEM 执行、双缓冲或多核调度。`--tile M K N` 是逻辑块上界，默认 128/128/128，未引入 ISA 对齐限制。

### 整片结构与局部执行边界

```text
+------------------------------------------------------------------+
| TPU v4 Chip                 hardware_scope = chip                |
|                                                                  |
|  +------------------------------------------------------------+  |
|  | TensorCore x 2 (identical private-resource inventories)    |  |
|  |                                                            |  |
|  | +--------------------+  VPU x 1, Scalar x 1                |  |
|  | | MXU x 4            |  private VMEM: 16 MiB / TensorCore  |  |
|  | | 128 x 128 / MXU    |  Vector shared service: reserved    |  |
|  | +--------------------+                                     |  |
|  +------------------------------------------------------------+  |
|                                                                  |
| Shared CMEM: 128 MiB       SparseCore x 4, spMEM: 10 MiB total   |
| ICI: 6 links (inventory)   External HBM: 32 GiB / chip           |
| Register file: 0.25 MiB / chip (per-TensorCore split unknown)    |
+------------------------------------------------------------------+

One logical GEMM: HBM -> one TensorCore's VMEM -> matrix service
                     -> INT32 C in that VMEM -> HBM
counting_scope = single_tensorcore; chip_execution_included = false
```

框图展示结构归属，未定义内部连接协议。`hierarchy()`、`tensorcore_inventory()`、`inventory()` 全部从同一份已校验配置派生，不另设副本配置或逐 PE 对象。芯片共有 8 个 MXU；count 不指定活跃数量，timing 只允许一个 TensorCore 内最多 4 个 MXU 分批并行，不跨核分配任务。

私有库存按 TensorCore 数聚合，CMEM、HBM、SparseCore/spMEM、ICI 只按芯片配置计一次。每核 VMEM 仍是独立的 16 MiB；整片 32 MiB 是库存总量，不是单核可用池。单核分块只用 `vmem_usable_bytes`，完整任务只检查一次芯片 `hbm_usable_bytes`；CMEM 和 spMEM 不参与本逻辑执行。

<a id="tpu-parameters"></a>

### 参数来源与场景假设

完整参数名、数值、单位、作用域及 `status/source/version/conditions` 位于 [参考配置](configs/hardware/tpu_v4_reference.json)。硬件配置现为 `schema_version=3`，保留原标识 `model=tpu_v4_count`；报告为 schema 4，count 的 model 不变，timing 的 model 为 `tpu_v4_analytical`。新增共享 Vector 服务和 CMEM 容量假设，寄存器改用芯片级证据；已移除字段的配置和证据保存在来源台账 `retired_parameters`。额外的 GEMM 时间模型假设仍在 `timing.parameters` 披露。

参考资料：

- **P**：[TPU v4 论文](https://arxiv.org/pdf/2304.01433)，ISCA 2023，DOI [10.1145/3579371.3589350](https://doi.org/10.1145/3579371.3589350)，PDF 第 2 页第 2 节开头、PDF 第 7 页表 4，以及第 10 页 §7.5；来源复核日期 2026-11-14（America/Los_Angeles，即 UTC 2026-11-15）。原先“§2.2”的定位已修正。
- **G**：[Google TPU v4 文档](https://docs.cloud.google.com/tpu/docs/v4)，System architecture、Memory system、TensorCores、Inter-chip interconnect；原核验记录日期 2026-11-15。
- **A**：本文声明的逻辑计数假设，版本为 TPU count model v1。

| 参数 | 数值及作用域 | 来源/状态 |
|---|---|---|
| TensorCore / MXU | 2 TC/chip，4 MXU/TC，128×128/MXU | G、P；documented |
| 时钟 / 标称 INT8 峰值 | 1.05 GHz、275 TOPS/chip | P、G；documented |
| 每 cell 每周期 MAC | 1 | A；assumed，几何峰值与公开峰值相符；timing 显式沿用为理想计算服务，未校准有效速率 |
| VPU / ALU 库存 | 1 VPU/TC，128 lane/VPU，16 ALU/lane | G、P；documented |
| Scalar 库存 | 1/TC | G；documented |
| VMEM / CMEM | 16 MiB/TC、128 MiB/chip 共享 | P；documented |
| SparseCore / spMEM | 4/chip、合计 10 MiB/chip | P；documented，仅库存 |
| HBM | 32 GiB/chip，1200 GB/s/chip | G；documented，二进制容量/十进制带宽 |
| ICI | 6 links/chip，报告值 50 GB/s/link | G、P；documented；方向口径未核实 |
| 工艺 / 面积约束 | 7 nm、die <600 mm² | P；documented，严格上界 |
| VMEM/HBM 可用容量 | 本逻辑场景设为各自物理容量 | A；assumed，运行时保留空间未计入 |
| Vector 共享基准吞吐 | 2048 等价 op/cycle/TC | assumed；固定配置，假设每个参考 ALU 每周期供应一次基础操作；ALU 库存不能证明有效吞吐 |
| INT32 ADD / FP32 ADD、MUL 等价代价 | 各 1 equivalent_op/op | assumed；共用同一服务，FMA/特殊函数/归约代价未定义 |
| VMEM 带宽 | 1075200000000 B/s | assumed；4×(128+128) B/cycle×1.05 GHz，显式固定配置 |
| CMEM 可用容量 | 134217728 B/chip | assumed；全物理容量作为预留场景，未启用 CMEM 路径或复用收益 |
| CMEM 带宽 | null | unknown；当前未执行 CMEM 路径，容量不能推出带宽 |
| 寄存器库存 | 262144 B/chip | P；documented，只按芯片计一次，不推断每 TC 归属/分配 |
| SMEM 容量 | 已移出当前模型 | 无 Scalar 执行/分配模型；不表示硬件不存在 SMEM |
| Scalar 吞吐、独立 SFU 数量/吞吐、ICI 单向有效载荷带宽 | 已移除 | 用户弃用执行参数；特殊函数归入未来 Vector 服务；已知 Scalar/ICI 规格仍保留 |

`documented/measured/assumed/unknown` 含义与现有参考模型一致。unknown 必须为 null；每个字段必须存在，禁止 loader 静默补值。本文未确认的字段没有被宣称为实测或硬件不存在。

VMEM/HBM 全容量可用是显式计数场景，不是实际程序可分配容量保证。可在配置中减少 `usable_bytes`，其值不得超过已知物理容量。执行所需的可用容量缺失会拒绝计数；无关的未知带宽等不会阻止运算量统计。

<a id="tpu-vector-service"></a>

### 共享 Vector 服务与存储归约

2026-11-17 对照 [LLMCompass 作者实现](https://github.com/PrincetonUniversity/LLMCompass/tree/2e015fd2ee750e6cad8d7152df52551e5b41ef20)：`VectorUnit` 聚合吞吐，Softmax 以等价操作代价计入特殊函数，寄存器组织进入面积模型。这里只借用抽象方法，没有复制其 TPU v3 的速率、exp=15、启动开销或存储带宽。尤其 TPU v3 配置中的 16 GiB global buffer 对应 HBM 抽象，不能替换 TPU v4 的 128 MiB CMEM。

配置的 `vector_base_ops_per_cycle=2048` 是固定的假设值，取法为参考库存 1×128×16 ALU，并额外假设每 ALU 每周期一份基础操作。`vector_int32_add_cost=1`，`vector_fp32_basic_op_cost=1` 分别表示一个元素的 INT32 加法和 FP32 加法/乘法所需等价操作。修改几何不会暗中改写服务值，服务为 null 也不回退到几何推导。

`hardware_derived.vector_service` 报告作用域、共享资源策略、配置代价、派生操作速率、assumed/unknown 依赖，并明确 `included_in_gemm=false`。同一 TensorCore 的 INT32 与 FP32 工作量共享预算：

```text
rate[op] = vector_base_ops_per_cycle / cost[op]
cycles = ceil(sum(count[op] * cost[op]) / vector_base_ops_per_cycle)
```

`TPUSpec.vector_service_cycles({"int32_add": 2048, "fp32_add": 2048})` 返回 2 个理想服务占用周期；不能将两种模式当作两个并行执行单元。所有操作工作量先累加、再对服务总量取整，采用有理数避免额外浮点舍入周期。空工作量返回 0，只检查实际使用操作的配置；负数、非整数、布尔计数及未知操作均拒绝。当前仅支持 `int32_add`、`fp32_add`、`fp32_mul`，FMA、EXP、DIV、跨 lane 归约必须先定义代价/时序，不能静默取 1，也不能把 TPU v3 的 exp 代价当 TPU v4 标定。

这个 API 只估算计算服务占用，不含访存、布局补齐、指令依赖、流水和调度开销；它不是完整 Vector 算子模拟器。现有 GEMM 不调用该 API，跨 K 累加仍由 MXU 计算服务承担。

CMEM 可用容量以 α=1 预留 128 MiB/chip，属于 assumed；带宽仍为 null。GEMM 始终旁路 CMEM，不改变分块、HBM 流量或复用，不将 CMEM 加进 VMEM 容量。将来启用需要同时实现数据放置、带宽、共享分配和缓冲策略；只补带宽数值不会自动启用。SMEM 从当前 schema/库存退出；寄存器仅记录芯片总量，不做每核均分或溢出预测。

### 规格派生和面积库存

```text
MAC = 2 op
MXU MAC/cycle = 128 × 128 × 1 = 16384
MXU peak = 16384 × 2 × 1.05e9 / 1e12 = 34.4064 TOPS
core MAC/cycle = 4 × MXU MAC/cycle = 65536
core peak = 65536 × 2 × 1.05e9 / 1e12 = 137.6256 TOPS
chip MAC/cycle = core MAC/cycle × 2 = 131072
chip peak = core peak × 2 = 275.2512 TOPS
bandwidth Gbit/s = bandwidth byte/s × 8 / 1e9
```

标称 275 TOPS 与几何推导值分别输出。上述结果不是周期预测；依赖假设参数的派生量保留假设性质，不因公式计算升级为硬件事实。INT8 不额外乘位宽加速倍数。

`hardware_hierarchy.mxu/tensorcore/chip` 中的 `int8_macs_per_cycle` 和 `int8_peak_tops` 分别对应 MAC/cycle 和 TOPS；几何与层级倍数分别位于 `rows/columns/cells`、`mxus_per_tensorcore`、`tensorcores_per_chip/mxus_per_chip`。来源沿用 `parameter_provenance`，参与峰值的假设参数列于 `hardware_hierarchy.peak_assumed_inputs`。依赖项未知时只传播到相关派生量：时钟未知不影响 MAC/cycle 或库存，芯片核数未知不影响单 MXU/单 TensorCore 规格；count 入口仍要求核数与 VMEM/HBM 可用容量明确。

库存输出 8 MXU、2 VPU、4096 VPU ALU、2 Scalar、4 SparseCore；私有 VMEM 合计 32 MiB、共享 CMEM 128 MiB、spMEM 10 MiB、芯片寄存器 0.25 MiB。`hardware_inventory.chip.register_file_bytes` 不随核数乘除；每核库存不再输出 `private_register_file_bytes` 或 `private_smem_bytes`，SMEM 退出当前模型。spMEM 不借给 dense GEMM，不把这些存储求和冒充完整物理 SRAM。外部 HBM 与片上存储分列。面积 <600 mm² 作为约束记录，`total_area_mm2=null`。

### 报告 schema 4 与迁移

2026-11-17 硬件 schema 2 → 3、报告 schema 3 → 4：删除 `vector_int32_adds_per_cycle`、`vector_fp32_ops_per_cycle`、`smem_physical_bytes`、`register_file_physical_bytes`。新增 `vector_base_ops_per_cycle`、`vector_int32_add_cost`、`vector_fp32_basic_op_cost` 和 `register_file_chip_bytes`，单位/作用域见参考 JSON；寄存器新字段只能为 chip。参考 CMEM 可用容量采用完整物理容量假设，带宽保持 unknown。自定义配置需显式填写服务及代价，不能只改版本号；若旧配置已有两项已知速率，可选共同基准 R 并设 cost=R/旧速率，但这也明确采用共享预算，不能继续当作两套并行资源。

schema 1 用户还需删除之前已退役的 `scalar_ops_per_cycle`、`sfu_units_per_tensorcore`、`sfu_fp32_ops_per_cycle`、`ici_link_one_way_bytes_per_second`。所有旧硬件版本和退役字段均拒绝。每核/整片库存移除 `private_smem_bytes`、`private_register_file_bytes`，新增芯片 `register_file_bytes`；Vector 摘要位于 `hardware_derived.vector_service`。Scalar 单元数量、ICI 链路数量和公开带宽保持规格用途。历史配置与证据保留在台账；下表记录最初的层级迁移，当前字段变动以上述 schema 4 说明为准。

| 字段/API | 含义与迁移 |
|---|---|
| `hardware_hierarchy` | 新增 MXU、TensorCore、Chip 结构及三级规格峰值，不分配执行任务 |
| `hardware_inventory.per_tensorcore` | 新增单个 TensorCore 的私有物理库存：4 MXU、1 VPU、2048 VPU ALU、1 Scalar、16 MiB VMEM 等 |
| `hardware_inventory.chip` | schema 1 的平铺 `hardware_inventory` 移到此处，原库存字段名及含义保持；例如旧 `hardware_inventory.mxus` 改读 `.chip.mxus` |
| `boundary.hardware_scope` | `chip`，硬件规格范围 |
| `boundary.counting_scope` / `boundary.scope` | 均为 `single_tensorcore`；保留原 `scope` 便于统一读取执行范围 |
| `boundary.simulated_tensorcores` / `chip_execution_included` | 分别为 `1` / `false`，未包含整片执行 |
| `hardware_derived` | 原字段保留，增加 `mxu_int8_macs_per_cycle`、`mxu_int8_peak_tops`、`chip_int8_macs_per_cycle` |
| `TPUSpec.inventory()` | 仍返回平铺整片库存；每核库存与层级分别调用新增 `tensorcore_inventory()`、`hierarchy()` |

`counts`、`action_counts`、`memory` 和分块策略保持原义；硬件核数或 MXU 数变化不自动乘算单核动作，也不输出整片吞吐/时间。timing 中，核数影响假设分得的 HBM 带宽，MXU 数影响每批并行量。CLI 默认 `timing`，可显式选择 `--mode count`；核心 Python API 默认仍为 `count`；终端保留结构/库存摘要，timing 时另打印阶段时间与假设。

### 逻辑分块与动作公式

固定 MNK，单缓冲；同一个 C 块遍历全部 K，完成后写回 HBM。不同输出块之间不复用输入。同一输入面板在一个逻辑计算块内由聚合矩阵服务读取一次，不推测内部广播、权重装载或 PE 活动。

先把请求的块上界限制到实际尺寸。如果工作集超容量，依次减半当前最长维度，直到满足容量约束；该规则只用于获得合法逻辑块，没有搜索目标。尾块使用真实尺寸，无 padding。

```text
VMEM logical block = m*k + k*n + 4*m*n bytes
HBM logical allocation = M*K + K*N + 4*M*N bytes
```

要求 A/B/C 同时容纳于声明的 HBM 可用空间，不能用一个小块能放下替代整任务驻留检查。VMEM 只检查 A/B/C 逻辑存储，未纳入实际布局、编译器临时空间和寄存器溢出。

令 `I=ceil(M/m)`、`J=ceil(N/n)`、`R=ceil(K/k)`，对包含尾块的 MNK 循环求和：

```text
useful_MACs = M*K*N
useful_ops = 2*M*K*N
compute_blocks = I*J*R
output_blocks = I*J
A input transfers = J*M*K bytes
B input transfers = I*K*N bytes
final output = 4*M*N bytes
old PSUM reads = 4*(R-1)*M*N bytes
intermediate PSUM writes = 4*(R-1)*M*N bytes
```

实现使用上述闭式求和，结果与逐逻辑块计数一致，不保存事件列表。

C 是唯一的逻辑部分和区域。第一 K 块不读旧 C；各 K 块写出更新后的 C；最后一次写归为 final write，其余归为 intermediate PSUM write。最终另计一次 VMEM export read 和 HBM write。MAC 已包含逻辑累加，不再添加固定 VPU add 或独立归约成本。

Action 输出：`matrix_mac`，HBM read/write，VMEM input read/write，VMEM PSUM read/write，VMEM final write/export read。作用域均为 `single_tensorcore`，basis 为 `logical_arithmetic` 或 `logical_payload`。这是部分动作输入，不是完整物理能耗清单；未覆盖的内部活动没有按零能耗处理。搬运摘要与端点动作描述同一数据传输，不能同时乘能耗系数后重复相加。

`executed_padded_ops=null`，因为未评估真实执行补齐。count 的时间及两种模式的能耗、面积总量均为 null，状态 `not_evaluated`。timing 的阵列占用近似不会改变逻辑动作计数或宣称已统计物理补齐运算。

### 手算样例

16×32×16 INT8/INT32：8192 MAC、16384 op、输入搬运 1024 byte、输出 1024 byte，单块工作集 2048 byte，无跨块部分和访问。

3×5×7、逻辑块上界 2/3/4：8 个计算块、4 个输出块、105 MAC；A/B 搬运为 30/70 byte，最终输出 84 byte，部分和中间写和旧值读各 84 byte，VMEM 峰值 50 byte，HBM 驻留 134 byte。这些数值仅验证逻辑计数。

<a id="tpu-timing"></a>

### 可选任务时间模型

CLI 默认 timing，在既有逻辑分块上计算从 HBM 输入到 HBM 输出的单 TensorCore 总时间。实现仍位于现有 `src/core/tpu/simulator.py`；不增设调度器或配置文件，显式 count 的计算行为保持不变。

可以把执行过程理解为：先搬入一个逻辑块的 A/B，再读取已有的部分和，让矩阵阵列完成这一段 K，最后把结果存回 VMEM。该输出块的所有 K 段完成后，才把最终 C 搬回 HBM。每一步串行相加，输出块之间也串行执行。

```text
一个逻辑输出块 (m × n)，逐段遍历 K：
 HBM --A/B--> VMEM --A/B--> MXU
                |           ^
                +--旧 C-----+  第一段 K 无旧 C
                            |
                 阵列计算 + 填充/排空
                            |
                            v
                         VMEM C
                            |
                  最后一段 K 完成后
                            v
                          HBM C

块内输出划分：ceil(m/128) × ceil(n/128) 个 MXU 小块
每批最多 4 个小块并行；本批完成后才开始下一批。
```

结构和时钟沿用上述 P/G 来源。2026-11-16 复查的 [Google 架构文档](https://docs.cloud.google.com/tpu/docs/system-architecture-tpu-vm)支持 128×128 脉动阵列几何；[JAX 矩阵乘教程](https://docs.jax.dev/en/latest/pallas/tpu/matmul.html#matrix-multiplication-performance)提供计算量/服务率、搬运量/带宽和分块开销的分析方法。这里只采用方法，没有移植教程中其他 TPU 代际的参数。下表中的调度、服务宽度及延迟是本工程的近似，公开资料未给出相应的 TPU v4 有效指令时序。

| 时间模型输入 | 参考配置下的值 | 条件 |
|---|---|---|
| 活跃 MXU 上限 `U` | 4 | 单核库存已知；输出小块可在这 4 个单元分批并行属于假设 |
| 单核 HBM 份额 | 1200/2 = 600 GB/s | 假设两核均分，不借用另一核闲置带宽 |
| VMEM 服务率 `V` | 1075200000000 B/s ÷ 1.05 GHz = 1024 B/cycle | JSON 显式配置的 assumed 带宽除以当前时钟；其取法为四个阵列的 INT8 行/列供给宽度，null 不再回退 |
| DMA 服务率 `D` | min(600e9/1.05e9, V) ≈ 571.43 B/cycle | 两端共同搬运按较慢端计一次，不将 HBM 与 VMEM 端点耗时重复相加 |
| 每批填充/排空 `F` | 128+128−2 = 254 cycle | 理想二维阵列近似，尾块也预留完整几何；不是官方指令延迟 |
| 固定 DMA/发射开销 | 0 cycle | 显式省略未知固定开销，不表示实测为零 |
| 每 cell 的 MAC 服务 `s` | 1 MAC/cycle | 沿用已有峰值假设作为计算阶段理想服务，不视为有效指令吞吐 |

令当前逻辑块实际尺寸为 `m,k,n`，`Q=ceil(m/128)×ceil(n/128)`，`W=ceil(Q/U)`。`ceil` 对每个块或每个阶段单独向上取整，不能先合并整个任务的字节数再取整：

```text
每个逻辑计算块：
 hbm_to_vmem     = ceil((m*k + k*n) / D)
 vmem_to_mxu     = ceil((m*k + k*n) / V)
 psum_read       = ceil(4*m*n / V)      # 仅第二段及后续 K
 matrix_compute  = W * ceil(k / s)
 matrix_fill_drain = W * F
 result_to_vmem  = ceil(4*m*n / V)      # 每段 K，含最后一段
每个输出块：
 vmem_to_hbm     = ceil(4*m*n / D)      # 全部 K 完成后，只计一次

总周期 = 对全部实际块求和上述七项
时间 ns = 总周期 * 1e9 / clock_hz
有效吞吐 GOPS = useful_ops / 时间 ns
```

一个逻辑块的输入只读一次，并假设可以在 MXU 间共享；不额外计广播流量。旧 C 作为累加初值进入矩阵计算，MAC 服务已包含累加，不另设未知的 VPU 加法阶段。阵列内部隐式补齐不占额外逻辑 VMEM，也不增加 action counts。尾块仍按完整阵列预留时间。实现只遍历完整块/尾块的尺寸组合，乘以重复次数，任务很大时也不展开逐块事件。

**默认块 128/128/128 每次只使用 1 个 MXU**。例如 `--tile 256 128 256` 的完整块包含 4 个输出小块，可在一批内用满单核四个 MXU；不足四个的小块批次留空，不自动从其他逻辑块补任务。报告提供 `matrix_waves`、`mxu_output_tiles` 和 `max_parallel_mxus_used`，帮助解释这种利用率差异。

手算核对：16/32/16 的七阶段为 `2+1+0+32+254+1+2=292 cycle`，约 278.10 ns；128/128/128 为 `58+32+0+128+254+64+115=651 cycle`。256/128/256（相同块上界）使用 4 个 MXU、1 批，为 1276 cycle。3/5/7、块 2/3/4 的 8 个计算块共 2084 cycle，最终 HBM 输出仍仅 84 byte。`tiny_gemm.json` 默认分块时为 20016 cycle，约 19.06 μs。

报告 `timing.status=analytical_estimate`，`model=single_tensorcore_serial_v1`，`chip_cycles=null`；七阶段位于 stages_cycles，假设列在 parameters/assumptions。时钟、核数、MXU 数、阵列尺寸、MAC 速率或 HBM/VMEM 带宽缺失时拒绝 timing。VMEM 服务从 JSON 的显式 assumed B/s 值除以时钟得到，不再因 null 补默认值；对应来源台账已同步更新。

模型不含搬运/计算重叠、bank 冲突、编译器调度、寄存器溢出、持续权重驻留、CMEM/SparseCore/VPU 执行、主机传输或整片调度。串行化会增加某些开销，理想服务和省略固定延迟又会减少另一些开销，因此结果既不是已校准性能，也不是实际硬件时间的可靠上界或下界。

<a id="tsp"></a>

## 4. 原生 TSP

配置：[tsp.json](configs/hardware/tsp.json)。实现：[TSPSpec](src/hardware/tsp.py)、[分块](src/core/tsp/tiling.py)、[模拟器](src/core/tsp/simulator.py)、[公共原生 runner](src/utils/tsp_reference.py)、[入口](tsp.py)。

### 规格与执行范围

```text
chip inventory / geometric peak / nominal peak / provenance
                            |
                            v
      one hemisphere: 2 MXM planes + allocated local MEM
                            |
                            v
   install weights -> compressed activation/MXM/result row service
                            |                   ^
                            v                   |
                      MEM: C / PSUM -----------+
                            |
                            v
        single-side cycles, traffic, MACs and action counts
```

参考可用 MEM 为 220 MiB/chip、110 MiB/hemisphere。memory tile 的 128 KiB 定义包含两个 bank，20 tiles/slice×44 slices/hemisphere×2 hemispheres 得到 220 MiB，不能再乘 bank_count。当前模型不保留额外局部 SRAM、备用 SuperLane 或物理总 SRAM 汇总字段；已知 MEM 容量不表示全部物理 SRAM，历史缺口记录保存在来源台账。

库存为 320 lane、4 MXM plane/chip、5120 VXM ALU；单侧执行使用 2 plane，不复制中心 VXM。INT32 add 使用明确的单任务吞吐参数，不自动把 5120 ALU 当作每种操作的吞吐。参考验证仅接受不超过每 ALU 每周期一次 INT32 add 的预算上限；该上限是本模型的保守约束。

几何峰值为 737.28 TOPS，nominal 750 TOPS 单独保存。32×320=10240 byte/cycle 是单方向网络上限，不能当作单个 MEM slice 的供给。45 个 SR 坐标是结构字段，代码检查其索引范围，不据此推导所有路径均为 45 hops。

参数表见 [完整参数来源表](#tsp-parameters)，完整元数据位于 [参考配置](configs/hardware/tsp.json)。来源区分项目设计规格、公开原始论文、模型假设和 unknown。issue 指定的架构文件已恢复并核对精确 Git blob，配置已改用包含该 blob 的固定 commit 链接。documented 项目规格不等于芯片实测。

### 驻留、分块与流量

起点为已排布 A/B 位于本侧 MEM，终点为 INT32 C 位于本侧 MEM。主机传输、布局准备、外部供给、远侧 MEM 和输出裁剪不计入。超容量任务拒绝，不能以 tile 放得下代替完整驻留检查。

默认 tile 上限 M/K/N=320/320/640，是软件策略。K/N 向 16 对齐，M 保持实际行数；支持 KNM、KMN、MKN、NKM。修改 --tile 会影响重复加载和填充，不等同于硬件结构变化。

A/B/C 采用互不重叠的均匀条带逻辑地址，默认使用本侧全部 44 个 slice；可用 --mem-slices 选择明确子集。C 区域兼作 PSUM，所有活跃输出均有容量，不另配一份完整 C。--reserved-bytes 默认 0 是显式软件场景假设，不表示真实硬件没有保留空间。

MEM action 是已填充的有效负载 byte，尚不是 bank 事务计数；stream action 按 320-byte 组补齐。零填充/掩码和均匀条带是逻辑布局假设，未验证为具体 ISA ABI。逻辑 useful_ops=2MKN；executed_padded_ops 来自分块后的 MAC 计数，不预测 inactive supercell 的实际翻转/门控能量。

### 可选时间公式

#### 权重

按具体 plane 保存 (K 起点、N 起点、填充 K、列数) 标签；只安装发生变化的 plane。不同 M 块可以复用驻留权重，块间串行保证不会覆盖仍在计算的权重。

```text
B_install = min(slice_read_supply, slice_shared_supply,
                allocated_stream_supply, install_bpc)
group_bytes = stream_width * max(1, floor(B_install / stream_width))
Q = ceil(changed_weight_bytes / group_bytes)
II_install = ceil(group_bytes / B_install)
T_install = install_propagation_cycles + Q * II_install
```

install_propagation_cycles 只包含固定传播，默认假设 19 cycle；首组服务已包含在 Q×II_install 中，不再另外计费。首组完成时间为传播加 II_install。一个发射组可含多条并行 stream，不能把每个 320-byte 向量单独串行计费。安装端口低于一条 stream 宽度时，一个组可以耗时多拍；固定传播不随带宽改变。所有权重标签均命中时，安装时间和安装动作数为零。

#### 行服务

每行按实际填充 K/N 计算 activation、MXM result、可选 old PSUM 和写回需求。固定的 row_io_latency_cycles 包含该 profile 路径的 SRAM/SR 固定延迟，排除显式 payload 服务及 MXM/VXM 内部时间。

```text
II_MEM = max(read_bytes / read_supply,
             write_bytes / write_supply,
             (read_bytes + write_bytes) / shared_supply), each rounded up

II_stream = max(outward_bytes / allocated_stream_supply,
                inward_bytes / allocated_stream_supply), rounded up

II_MXM = max(mxm_row_ii, ceil(padded_K * padded_N / allocated_peak_MAC_per_cycle))
VXM_row_add_cycles = ceil(actual_tile_padded_N / vxm_add_ops_per_cycle)  # only later K
VXM_row_first = vxm_add_latency_cycles + VXM_row_add_cycles
II_row = max(II_MEM, II_stream, II_MXM, VXM_row_add_cycles)

L_row = row_io_latency_cycles + first_activation_transfer
        + mxm_first_cycles + first_result_transfer
        + optional_PSUM_read + optional_VXM_row_first + first_write

T_rows = L_row + (m_actual - 1) * II_row
T_total = sum_over_tiles(T_install_if_needed + T_rows)
```

首行的传输和加法按完整依赖链串行服务；后续行允许不同资源流水。VXM 按固定纯计算速率计算行服务，不再用 stream 带宽压低其算力后额外收费；stream 的供给约束已经体现在显式传输与 II_stream 中。额外 VXM 固定流水延迟只加入首行，不当作稳态 II。每个 N 尾块使用自己的补齐列数，不沿用最大行的加法时间。

同一聚合资源的多项需求先求和，再与其他资源取 max。方向预算保守地把 activation/write 计入同一 outward 预算，result/PSUM read 计入同一 inward 预算；不实现空间局部复用。MEM read/write 有独立上限以及共享总预算，避免一个 slice 被重复分配给多个同时满速的动作。

mxm_first_cycles 包含首结果的内部归约与错拍，结果服务不再重复加这部分。纯 GEMM 的第一个 K tile 不调用额外 VXM 激活函数；后续 K tile 读取旧 PSUM 并逐元素做 INT32 add。R 个 K tile 有 (R-1)MN 个逻辑 add、4(R-1)MN byte 逻辑 PSUM 读和中间写，以及 4MN byte 最终输出；填充动作另计。

压缩行流水是可解释的理想稳定服务假设，没有证明逐指令静态排程；不生成行/stream 事件。块间不重叠。first_row_write_cycle 可以是中间 PSUM 的首次写入，不保证是最终 C 的首次完成。

手算回归使用人工时序参数：1×16 乘 16×16 为 13 cycles，三行复用同一权重为 17 cycles；K=32 分两块为 29 cycles。这些样例验证公式，不是 TSP 实测延迟。

### 缺参和参考身份

count 不产生周期或能效。timing 只要求本次任务使用的服务；一个 K tile 不需要 VXM 跨 K 加法参数。必需服务为空时报错。JSON 的 value 全部直接采用，不根据任务改写。额外本地/物理 SRAM 仍可为空，报告不捏造库存。

energy/area 为 not_evaluated，总量和效率为 null；action_counts 与 hardware_inventory 作为后续成本模型输入。clock/control/SXM 物理数量没有可靠定义时，不从逻辑端点数捏造库存。

reference_id 是 profile_id 加完整配置内容哈希，防止仅文件名相同却使用不同参数。报告保存参数来源、派生公式及依赖状态、内存范围、分块、作用域和未建模限制。

### 原生 TSP 显式配置的模型服务（2026-11-16）

保留行流水、MEM 驻留、stream 预算、权重 tag 和跨 K 动作计数。配置与派生量分开：timing.parameters 记录固定输入；timing.derived_services 记录当前 MEM/stream/安装带宽、安装发射组与周期、首组完成时间以及实际使用的 VXM 行计算/首行时间最小最大值。无跨 K 加法时，VXM 时间范围为 null，表示本任务未使用该服务。

| 配置字段 | 固定值 | 作用 |
|---|---|---|
| `install_bpc` | 10240 B/cycle | 安装端口上限；实际带宽与已分配 MEM/stream 取 min |
| `install_propagation_cycles` | 19 cycle | 安装时仅支付一次固定传播；载荷时间另算，包含首组 |
| `mxm_row_ii` | 1 cycle | 理想驻留计算行 II；任务 II 仍由各资源瓶颈决定 |
| `mxm_first_cycles` | 20 cycle | 完整 MXM 首结果参考延迟，不另计同一归约错拍 |
| `row_io_latency_cycles` | 0 cycle | 显式省略额外固定 MEM/SR 路由开销；载荷仍计费 |
| `vxm_add_ops_per_cycle` | 320 op/cycle | 单 hemisphere 的固定单任务 INT32 算力代理；不随 stream 数变化 |
| `vxm_add_latency_cycles` | 0 cycle | 纯行计算服务之外的额外固定流水延迟；不包含传输或整行算术工作 |


只有跨 K 分段才解析最后两项。代理基于指定 TSP 文档 §6.5–6.7 的 LW/ACC 波传播和 §7 的 VXM 组织；原论文的“满阵列装载小于 40 拍”是完整条件下的参考，不能直接作为安装首延迟或重复加入各阶段。参考分配下 1/320/640 的安装为 20 个 payload 组加 19 拍传播，即 **39 cycle**，完整首行另需 23 拍；这只是模型算例，不声称所有布局都能达到该时延。

当前报告 schema 4，timing.model=single_hem_fixed_services_v2；install 与 row_service 之和等于总周期。以下固定服务行为延续 schema 3：16/32/16 仍为 **58 cycle**，1/321/16 为 **88 cycle**，tiny 为 **588 cycle**。人工参数将安装传播设为 2、VXM 额外流水设为 1 后，13/17/29-cycle 算例仍成立。受限 stream 的跨 K 任务可能减少重复供给计时：M3/K321/N640、单 stream/单 slice 从 852 改为 **846 cycle**；默认分配的 M2/K321/N641 从 202 改为 **201 cycle**，因为 N 尾块不再预留完整行 add 服务。动作计数保持不变。

这些代理没有加入后台装载重叠、逐 stream 排程、资源争用或实测拟合。它们提供统一披露规则下的解析估算，不构成真实硬件上下界或跨架构速度排名。

### 与 CIM-TSP 共用参考

CIM 配置通过 `native_reference=tsp.json` 引用 lane、MEM、stream、VXM 和 clock 参数及来源，并检查共享几何一致性。`--compare-mxm` 和 sweep 调用同一个原生 runner；相同 workload/策略使用相同原生结果，不再维护硬编码 MXM baseline。默认 CIM 与原生均为单 hemisphere，按同一模式/资源分配运行；`analytical_cycle_ratio_native_over_cim` 为解析周期比。原生安装串行与 CIM 后台 LW 等策略差异仍披露，`speedup`、`energy_ratio` 保持 null。显式单域诊断仍不可直接比较。

<a id="tsp-parameters"></a>

### 完整参数来源表

本表与 [tsp.json](configs/hardware/tsp.json) 对应，逐项原文位置和适用限制见[核验台账](calibration/parameter_source_audit.json)。指定原文已核对，旧 `primary_document_pending` 状态已移除。来源缩写：

- **T：TSP 架构修订稿 2026-08-05**：[固定版本](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/700b6e6509b1742878091382df0d0df3e92732e1/docs/public/tsp_architecture_doc_20260805.md)；Git blob `a1c88357c7a14ea54da7d107cd22b6b89ad0cd8e`。
- **S：SOW Summary 2026-11-05**：[固定版本](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/071573763db09594a85f2371e7abfc7615cfe509/docs/reference/SOW-Summary.md)；Git blob `b77cbdf8eb55ba46c990dd89060c193445cb81b2`。
- **I：ISCA 2020 Think Fast**：[固定版本](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/1db5a44ec36b6d3c7359f283fdd7d06908b212f4/docs/reference/papers/Think_Fast_A_Tensor_Streaming_Processor_TSP_for_Accelerating_Deep_Learning_Workloads.pdf)；Git blob `de8ebc2b25c212b9c409cc88adc629b17b2af2c5`。
- **A：ASAP 2022 Answer Fast**：[固定版本](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/1db5a44ec36b6d3c7359f283fdd7d06908b212f4/docs/reference/papers/Answer_Fast_Accelerating_BERT_on_the_Tensor_Streaming_Processor.pdf)；Git blob `31dbb2fc9531d0578d9f72fc8e0b31e8d59d72a3`。
- **H：HotChips 2022 scale-out TSP**：[固定版本](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/1db5a44ec36b6d3c7359f283fdd7d06908b212f4/docs/reference/papers/The_Groq_Software-defined_Scale-out_Tensor_Streaming_Multiprocessor__From_chips-to-systems_architectural_overview.pdf)；Git blob `eb4fafc781b412505509f7c335b2564900049175`。

`verified_project_spec` 仅表示与项目指定原文一致；`verified_primary` 表示与原始论文一致；derived 表示公式来自已核对结构。它们都不表示完成硅后标定。unknown 行也已审阅，不代表有任意可填的默认值。

| 参数 | 值 | 单位 | 作用域 | 状态 | 原文证据 / 核验结果 |
|---|---:|---|---|---|---|
| `superlanes` | 20 | count | chip | documented | tsp_design / verified_project_spec |
| `lanes_per_superlane` | 16 | count | superlane | documented | tsp_design / verified_project_spec |
| `hemispheres` | 2 | count | chip | documented | tsp_design / verified_project_spec |
| `planes_per_hemisphere` | 2 | count | hemisphere | documented | tsp_design / verified_project_spec |
| `plane_dim` | 320 | count | plane | documented | tsp_design / verified_project_spec |
| `supercell_dim` | 16 | count | supercell | documented | tsp_design / verified_project_spec |
| `vxm_alus_per_lane` | 16 | count | lane | documented | tsp_design / verified_project_spec |
| `mem_slices_per_hemisphere` | 44 | count | hemisphere | documented | tsp_design / verified_project_spec |
| `mem_tiles_per_slice` | 20 | count | slice | documented | tsp_design / verified_project_spec |
| `memory_tile_bytes` | 131072 | byte | memory_tile | documented | tsp_design / verified_project_spec |
| `banks_per_memory_tile` | 2 | count | memory_tile | documented | tsp_design / verified_project_spec |
| `usable_mem_bytes` | 230686720 | byte | chip | documented | tsp_design / verified_project_spec |
| `sr_coordinates` | 45 | count | superlane | documented | tsp_design / verified_project_spec |
| `streams_per_direction` | 32 | count | chip_stream_direction | documented | tsp_design / verified_project_spec |
| `stream_width_bytes` | 320 | byte | chip_stream_cross_section | documented | tsp_design, asap2022, isca2020 / derived_from_verified_geometry |
| `clock_ghz` | 0.9 | GHz | chip | documented | sow, isca2020 / verified_project_spec |
| `nominal_int8_tops` | 750 | TOPS | chip | documented | sow / verified_project_spec |
| `mem_read_bpc` | 320 | byte/cycle | slice | documented | isca2020, asap2022 / verified_primary |
| `mem_write_bpc` | 320 | byte/cycle | slice | documented | isca2020, asap2022 / verified_primary |
| `mem_shared_bpc` | 320 | byte/cycle | slice | assumed | isca2020 / assumption_retained |
| `install_bpc` | 10240 | byte/cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |
| `install_propagation_cycles` | 19 | cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |
| `mxm_first_cycles` | 20 | cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |
| `mxm_row_ii` | 1 | cycle | hemisphere | assumed | tsp_design, cim_design + model_policy / explicit_model_assumption |
| `row_io_latency_cycles` | 0 | cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |
| `vxm_add_ops_per_cycle` | 320 | op/cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |
| `vxm_add_latency_cycles` | 0 | cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |
| `nonlinear_ops_per_cycle` | null | op/cycle | chip | unknown | tsp_design / unresolved |

当前硬件与原生报告均为 schema 4，共 28 项参数：19 documented、8 assumed、1 unknown。2026-11-17 移除 `spare_superlanes`、`physical_sram_bytes`、`local_sram_bytes`、`offchip_capacity_bytes`、`offchip_bandwidth_bpc`、`interchip_bandwidth_bpc`；来源台账的 `retired_parameters` 保留各项完整旧配置、审阅依据和移除原因，移除不表示物理资源不存在。

`nonlinear_ops_per_cycle` 是唯一保留的 null，用于记录 [Issue #3](https://github.com/pku-pacific-lab-team/huawei_dfp/issues/3) 的粗粒度 Nonlinear 建模缺口。当前 GEMM 不读取它；后续需确定操作代价、延迟和与 VXM 的共享资源关系，不能把单一未知吞吐当成独立并行算力。[Issue #6](https://github.com/pku-pacific-lab-team/huawei_dfp/issues/6) 的片外供给及片间链路由独立系统配置定义，不在此保留泛化带宽字段。

自定义 schema 3 配置迁移：删除上述 6 项，保留其余参数原值，设置 `schema_version=4`；旧 schema 及退役字段均拒绝。schema 2 还需先按固定服务重构迁移首行延迟字段。原生报告移除 `hardware_inventory` 中的 `spare_superlanes`、`physical_sram_mib`、`local_sram_mib`，对应 Spec 属性同步移除；MEM 可用容量及所有计数/时间公式不变。CIM `shared_system` 不再包含三项外部系统参数；引用内容变化会更新原生及 CIM 的 reference_id。CIM 自身配置和报告的后续精简见下文，当前硬件 schema 4、报告 schema 5。

32 是每方向共享的一组 stream ID；每条 SuperLane 在每个 SR 坐标提供 16 B 分量，跨 20 条 SuperLane 的完整 stream 横截面才是 320 B。45 个 SR 坐标属于每条完整 SuperLane，不是芯片总寄存器数、路由跳数或需按 hemisphere 再乘的数量。配置及 loader 已分别使用 `chip_stream_direction`、`chip_stream_cross_section`、`superlane` 作用域；旧自定义配置需同步修正这些标签。

ISCA 2020 和 ASAP 2022 支持每 MEM slice 读/写各 320 B/cycle，异 bank 可并发。mem_shared_bpc=320 是保守软件合并上限。native matrix baseline II=1 在本模型中显式作为 assumed 的 mxm_row_ii=1；该映射未硬件标定。

900 MHz 与 750 TOPS 可追溯到 SOW；按四个 320×320 plane、每 MAC 2 op 推导得到 737.28 TOPS。差额为 12.72 TOPS，原文未解释原因，不将其断言为已证实的四舍五入。

<a id="cim-macro"></a>

## 5. 共享 CIM Macro 模型

共享实现：[CIMMacroModel](src/core/cim/macro_model.py)、[MacroContexts](src/core/cim/macro_model.py)、[CIMMacroSpec](src/hardware/macro.py)。通过 CIM-TSP 调用，或直接使用下文的 Macro Python API。

### 规格与参数来源

CIM-TSP 与 Macro Python API 统一引用 schema 2 的 [cim_macro.json](configs/hardware/cim_macro.json)，不得内嵌旧 macro 配置。每项参数记录 value、unit、scope、status、source、source_version、conditions、verification；缺失、不一致或旧 schema 均报错。结果携带完整参数与内容哈希，便于复现。

| 项目 | 当前值 | 依据与状态 |
| --- | --- | --- |
| 每 context 结构 | 16 bank × 16 subarray × 16 column | 项目文档的结构选择 |
| 权重上下文 | 4 套 | 固定当前 profile；原方案允许未来按面积调整 |
| W / A / 输出 | INT8 / INT8 / INT32 | 项目 INT8 模式 |
| K / N | 16 / 32 | N = 16 bank × (16 column / 8 bit) |
| 每 context / 总驻留 | 512 B / 2048 B | 由物理组织推导；四套不会增加瞬时吞吐 |
| 每行 MAC / II / 峰值 | 512 / 8 cycle / 64 MAC/cycle | 完整 MAC 计数；按 2 ops/MAC 为 128 ops/cycle |
| 每行输入 / 局部输出 | 16 B / 128 B | 16 个 INT8 activation；32 个 INT32 局部和 |
| 写入 wordline | 32 B，16 条/context | 详稿 §3.3.4 明确的写组织设计，不是已验证写带宽 |

设计来源与冻结版本见 [CIM 来源表](#cim-sources)。Macro 几何依据方案详稿 §3.1、§3.5，32 B 写组织依据最终 LW 设计 §3.3.4；已逐项核对原文。

`documented` 表示有项目文档依据，不表示经过流片测量或 ASIC 时序验证。这里不沿用材料中的跨精度能耗假设，也不把材料的整机结果移植为本模型预测。

<a id="cim-parameter-policy"></a>
参数政策：没有校准来源的成本不产生数值。32 B 写字组织已从 assumed 更新为 documented 项目设计；未被 Cluster 时间模型使用的首结果/写入/切换时序参数已退役。后续新增成本服务必须同时定义消费路径、来源、版本、条件和验证说明。

### 计数与 context

唯一 Macro 计算实现位于 [macro_model.py](src/core/cim/macro_model.py)。输入 rows 表示共享同一权重分片的 activation 行数；k≤16、n≤32。完整 INT8 操作数通过 8 个逐位输入阶段计算，输出是局部 INT32 部分和。

对 r 行：

- useful MAC = r × k × n；issued MAC = r × 16 × 32。
- bit-serial Macro cycles = r × 8；它是忙碌动作总数，不是端到端延迟。
- activation capture = r × 16 B；result = r × 128 B。
- W8×A1 word-bit product = r × 16 × 32 × 8；该项不是单 bitcell 翻转数。
- 局部 K 加法树 = r × 32 × 15 × 8 次 add；移位累加 = r × 32 × 8 次 update。
- 每次整 context 装载为 512 B / 16 条 wordline。尾块先补零，仍按整 context 装载。

尾块不假定免费门控或跳过 bit-serial 阶段。上述逻辑电路动作只作为后续成本模型的输入；bit 宽度、符号位处理电路、真实翻转率、能耗均未校准。不仿真数值结果或 INT32 溢出。

Macro API 只返回动作计数，不接受 `mode` 参数；返回值中的 `cycles`、`energy_pj`、`area_mm2` 保持 null。II=8 表示输入占用，不等于已标定的首结果延迟。任务时间统一由下文半片或显式单域模型计算；不再保留独立的 Macro 首结果、首字写入、连续写间隔或切换时间公式。

`MacroContexts` 只记录权重 tag、active 指针及轮转替换位置：未装载 context 不可激活，active context 不可覆盖。调用发生在上一个任务已排空的边界；它不跟踪逐拍 busy、Cluster readiness 或运行中 IW，也不声称后台装载重叠。tag 必须唯一标识权重内容；聚合入口使用本次 GEMM 的 K/N 分片坐标，每次 simulate 从空状态开始。

### CIM-TSP 的 Macro 聚合

`tsp_cim.py` 通过 `count_macro_tiles` 调用 Macro 计算与 tag 复用逻辑。完整 K/N tile 的物理 slot 固定，尾块不重编号。四套 context 内驻留分片不重复装载，超过容量时轮转替换非 active 项。

聚合函数支持 M/K/N 六种循环排列。计数止于 Macro 局部部分和；跨 Macro / 跨 tile K 加法记录逻辑义务。Macro cycles 之和不是墙钟时间，局部输出 bytes 也不是最终 C 写回流量。可选 `on_tile` 观察器向 CIM-TSP 时间模型传递本次实际编程/切换次数，避免重复实现 context 状态机；不传观察器时仍只计数。上层时间模型使用单独披露的粗粒度假设；Macro 只提供几何、II、context 状态与动作次数。

### Python API

```python
import json
from pathlib import Path
from src.hardware.macro import CIMMacroSpec
from src.core.cim.macro_model import CIMMacroModel

# 在工程根目录运行，直接读取单个 Macro 的规格。
profile = json.loads(Path("configs/hardware/cim_macro.json").read_text(encoding="utf-8"))
spec = CIMMacroSpec.from_dict(profile)
macro = CIMMacroModel(spec)
result = macro.compute(rows=3, k=16, n=32)  # 1536 MAC, 384 B output
program = macro.program_context()           # 512 B, 16 wordlines
# 不再接受 mode 参数；任务时间通过 TSPCIMSimulator.simulate(mode="timing") 获取。
```

<a id="cim-tsp"></a>

## 6. CIM-TSP Core / Cluster / Plane

配置：[tsp_cim.json](configs/hardware/tsp_cim.json)。实现：[TSPCIMSpec](src/hardware/tsp_cim.py)、[半片执行](src/core/tsp_cim/hemisphere.py)、[单域分块](src/core/tsp_cim/tiling.py)、[模拟器](src/core/tsp_cim/simulator.py)、[入口](tsp_cim.py)。默认执行一个 hemisphere，包含 8 个独立 Cluster domain；显式单域模式保留作诊断，整片规格和峰值独立报告。

<a id="cim-sources"></a>

### 设计来源与版本

本轮已逐项复核下面的冻结原文；文件内容与记录的 Git blob 完全一致，链接已固定到实际 commit：

| 来源 | 冻结的 Git blob | 用途 |
| --- | --- | --- |
| [评审材料](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/7383ae43cefcddc04d01c189794356ca62eb7101/docs/public/cim-mxm-patent-idea-review-slides-20261110.md) | aa8f3377d1203ec070a46fe3038627af730ce78b | 技术方案页 1–5：层级、独立任务域、NIM 与时序设计边界 |
| [方案详稿](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/7383ae43cefcddc04d01c189794356ca62eb7101/docs/legacy/patent-idea-review.md) | acf4798e3d0a5ed57bec576849d6c3ffb4679ab7 | §3.2–3.5：结构数量、K/N 组织、stream/LW、context 和 NIM 规格 |
| [原生 TSP 参数表](#tsp-parameters)及 [tsp.json](configs/hardware/tsp.json) | 随报告携带 native_reference_id | MEM、lane、stream、VXM、clock 等公共系统口径；保留原来源状态 |
| [Macro profile](configs/hardware/cim_macro.json) | 随报告携带 macro_reference_id | INT8 K16×N32、四套 context、64 MAC/cycle；详见 [Macro 说明](#cim-macro) |

固定链接、Git blob 与报告内容哈希共同用于复现。项目设计规格不等于 ASIC 实测；原生 profile 中的假设和未知项经 CIM 继承后保持原状态。详稿早期 §3.1 的“400 Macro/hemisphere”与最终拓扑冲突，当前采用后续 §3.2、§5.1 及评审材料一致的 6400 Macro/chip；该选择已入逐项台账。

2026-11-16 再次核对远端 `main`（commit `c641844c1d213d02a7d961d889838cae9b9dc8aa`）：上面两份文档的 blob 未变化。详稿 §5.1–5.2 及配套 [latency_model.py](https://github.com/pku-pacific-lab-team/LPU-HUAWEI-2012/blob/c641844c1d213d02a7d961d889838cae9b9dc8aa/tools/qwen3_ffn_cim_eval/latency_model.py) 已有 Qwen3 FFN 全芯片分析式评估，四格式、四个 M 的 16 组延迟对比已复现。本工程采纳 INT8 占用、LW 规格及其排空公式，此前在单 Cluster GEMM 入口中做串行估算；现已扩展到下述半片静态 wave。仍不移植专用 FFN 负载、多精度或全芯片调度器。

### 层级、任务域与放置

| 层级 | 组成 | INT8 K×N | Macro 数 | 稳态规格 MAC/cycle |
| --- | --- | --- | ---: | ---: |
| Macro | 共享 Macro profile | 16×32 | 1 | 64 |
| Core | 4 Macro，N 方向分片 | 16×128 | 4 | 256 |
| Cluster slice | 一条 SuperLane 上的 5 Core | 16×640 | 20 | 1,280 |
| Cluster domain | 同一 Cluster 编号跨 20 条 SuperLane | 320×640 | 400 | 25,600 |
| Plane | 4 个独立 Cluster domain | 每域 320×640 | 1,600 | 102,400 |
| hemisphere | 2 Plane | 8 个独立域 | 3,200 | 204,800 |
| chip | 2 hemisphere、4 Plane | 16 个独立域 | 6,400 | 409,600 |

文档中的“Cluster = 5 Core”是单 SuperLane 局部组织；“Cluster 任务 K=320”跨 20 条 SuperLane。代码显式使用 cluster_slice / cluster_domain 区分，两者不能互换。每 Plane 有 80 个局部 slice、400 Core，但只有 4 个独立任务域；全芯片共有 1,600 Core。

Core 内四个 Macro 保存不同 N 分片，结果并列，不互相相加。同一任务域跨 SuperLane 的对应 N 分片沿 K 累加；不同 Cluster 域之间不归并 PSUM。Plane 的四域 N 宽度总和不表示一个任务自动获得 N2560。

放置地址为 `(hemisphere, plane, cluster, superlane, core, macro)`，索引范围为 `2×2×4×20×5×4`。域内 slot 为 `superlane×20 + core×4 + macro`；K/N 区间分别为 `[superlane×16, (superlane+1)×16)` 和 `[(core×4+macro)×32, (core×4+macro+1)×32)`。尾块始终沿用完整域的 slot 跨度。

### 参数、派生带宽与 SRAM 库存

[tsp_cim.json](configs/hardware/tsp_cim.json) 使用 schema 4，每项参数都有 value、unit、scope、status、source、source_version、conditions、verification。表中详稿章节均指上面的固定 blob；评审材料用于交叉核对。当前是冻结的 INT8 profile，几何不一致、单位/作用域错误、布尔或非整数计数、遗漏字段及旧 overlay 字段均拒绝。

| 参数 | 值 | 作用域 / 来源 | 解释 |
| --- | --- | --- | --- |
| macros_per_core | 4 | core / §3.2 | N 分片 |
| cores_per_cluster | 5 | cluster_slice / §3.2 | 单 SuperLane 局部组 |
| clusters_per_superlane | 4 | superlane_in_plane / §3.2.6 | 四个独立广播域 |
| superlanes_per_plane | 20 | plane / §3.2 | K 方向 |
| planes_per_hemisphere、hemispheres | 2、2 | hemisphere、chip / §3.2、§5.1 | 与引用的原生 TSP 检查一致性 |
| nim_units_per_plane | 1 | plane / §3.2.6 | 一个共享物理 NIM |
| nim_tiles_per_plane | 20 | plane / §3.4 | 沿 SuperLane 分布 |
| nim_channels_per_tile | 4 | nim_tile / §3.4 | 四域独立上下文 |
| nim_conversion_lanes | 64 | plane / §3.4.5 | FP32 转换结构库存，不执行浮点转换 |
| nim_output_bpc | 256 byte/cycle | writer_superlane_plane / §3.4.5–3.4.6 | 每个转置 writer SuperLane 的目标；INT32 旁路及聚合带宽约束见下文 |
| streams_per_plane | 16 | superlane_plane_direction / §3.3 | 每 Plane 在每 SuperLane 的 LW stream 分配 |
| lw_cores_per_cycle | 2 core/cycle | superlane_plane / §3.3.4 | 设计的 LW 捕获宽度，不生成编程完成时间 |
| core_stagger_cycles | 1 cycle | cluster_slice / §3.2.5–3.2.6 | 启动偏移目标，不自动加入延迟 |

MEM 容量/切片/tile/bank、lane、stream 方向宽度、SR 坐标、VXM ALU、Vector/Nonlinear 有效速率与 clock 从同一个原生 profile 引用，完整保留来源。禁止在 CIM 配置中用旧 mem/streams/sram 字段覆盖它们。`nonlinear_ops_per_cycle` 为 Issue #3 保留在原生配置及 CIM 来源记录中，不参与当前 GEMM，也不列入 CIM 的 `missing_parameters`；其他共享字段的 unknown 继续披露，时钟未知时仍保留周期但不计算 ns/GOPS。片外供给与互联留给 Issue #6 的独立系统层。

#### 派生规格与带宽边界

整片 INT8 峰值为 `6400×64=409600 MAC/cycle`，按 `2 ops/MAC`、原生参考时钟 `0.9 GHz` 得 `737.28 TOPS`；单域对应 `46.08 TOPS`。这些都是规格算术，不是本模拟器得到的吞吐。时钟未知时 TOPS 为 null，MAC/cycle 保留。材料中的 800 MHz 能耗评估工作点没有替换原生系统参考时钟，也不作为 Fmax。

- 单方向 stream 结构宽度：`32×320 = 10240 byte/cycle`。
- 每 SuperLane、每 Plane 的 LW 捕获目标：`2 Core×4 Macro×32 B = 256 byte/cycle`，占 `16 stream×16 lane`。
- 一个 Plane 的分布式 LW 捕获宽度：`20×256 = 5120 byte/cycle`；同半区两个 Plane 合计占满一个方向的 10240 byte/cycle，不能再把全部 stream 带宽重复分给 activation。
- 整片四个 Plane 的分布式 LW 捕获宽度：`4×5120 = 20480 byte/cycle`；各处并行捕获的宽度之和，不是单 Cluster 可独占的带宽。
- NIM 的 256 B/cycle 局部 writer 目标与分布式 LW 捕获宽度分别报告；结合 §3.4.6 按 writer SuperLane 作用域建模，并受共享系统服务约束。

当前半片路径检查 MEM 分配，并在共享服务预算上预约 LW 和行流水。预约为解析带宽，不是逐 bank/stream slot 调度，也不是经过标定的写入时序。结构宽度不能直接当作有效带宽。

详稿 §3.3.4 明确了 wordline 为外层、Core 为内层的 LW 轮转。沿用现有配置可得：每条 SuperLane、每个 Plane 共 `4×5=20` 个 Core，每拍服务 2 个 Core，所以扫描一轮为 10 拍；每 Macro 的一套 context 有 `512/32=16` 条 wordline，完整扫描预算为 `10×16=160` 拍。这个 160 拍覆盖整行四个 Cluster，不表示选中一个 Cluster、任意尾块或一次实际编程必定耗时 160 拍。

对应报告字段位于 `hardware_derived`：`lw_capture_bpc_per_chip`、`lw_scan_cycles_per_wordline`、`lw_full_context_scan_cycles`。每项保留 value、unit、scope、formula、source 和 source_version，它们是结构派生量，不代表 Macro 物理写入时间经过标定。

写回口径按详稿 §3.4.6 修正：不同 Core 的结果转置到不同 writer SuperLane，不能把整个 Plane 输出累计到一个 writer。`nim_output_bpc=256` 的作用域改为 `writer_superlane_plane`；两个 Plane 各有 20 个 writer 位置，结构目标合计 10240 B/cycle。INT32 旁路采用该目标是明确模型假设，实际服务同时受方向 stream 与 MEM 读写预算限制；不据此把 64 个 FP 转换 lane 复制 20 份，也不执行 FP 转换。原作用域及审阅记录保存在来源台账。

#### SRAM 与面积库存

全芯片活动 context 的权重容量为 `6400×512 B = 3.125 MiB`，四套驻留总量为 `6400×2048 B = 12.5 MiB`。两者是包含关系，不相加。单域四套驻留为 800 KiB。

220 MiB MEM 加 12.5 MiB Macro 权重 SRAM 得到 232.5 MiB 已知小计，不能解释为全芯片物理 SRAM 总量。物理总量、额外局部 SRAM 汇总和 collector 容量占位已删除；当前仍未验证 collector 分配容量。Issue #4 的容量调度与 Issue #5 的成本模型需要按实际组件、复制数量及访问路径定义存储，不能用这些粗略汇总替代。没有面积密度/系数时不输出 mm² 或 TOPS/mm²。

库存还报告 4 个 NIM、80 个 NIM tile、256 条转换 lane、5120 VXM ALU、88 MEM slice 和 1760 memory tile。memory tile 容量已经包括双 bank，容量不再乘以 2。不再输出始终为 null 且没有消费路径的 SXM 实体数、stream 物理端点数和 clock/control domain 数量占位；删除不表示这些物理资源不存在。

### 默认半片执行：静态 wave、共享资源与行流水

实现位于 [hemisphere.py](src/core/tsp_cim/hemisphere.py) 和 [resources.py](src/core/tsp_cim/resources.py)。2026-11-17 从远端 `main` 实际读取并核对两份指定文档：commit `c641844c1d213d02a7d961d889838cae9b9dc8aa`，胶片 blob `aa8f3377d1203ec070a46fe3038627af730ce78b`，详稿 blob `acf4798e3d0a5ed57bec576849d6c3ffb4679ab7`，均与此前冻结文件一致。

半片资源为 `2 Plane × 4 Cluster domain × 400 Macro = 3200 Macro`，INT8 峰值 204800 MAC/cycle，与原生半片规格相同。当前只执行 INT8/INT32 GEMM；FP/BFP、不同精度混合任务和全芯片执行不在本次范围。

**映射与驻留。**每个 K/N 任务为 K320×N640，按用户选择的六种循环顺序生成。物理域固定为 `(K_tile × N_tiles + N_tile) % 8`，域号对应 `(plane=domain//4, cluster=domain%4)`。因此切换 M 行组不会迁移权重或自动复制权重。按遍历顺序装入 wave；遇到重复物理域或新的 M 行组就结束当前 wave。每 wave 最多 8 个任务，尾 wave 保留实际任务数。K 段可分派到不同域，其结果在 MEM/VXM 路径合并，域之间不增加直接 PSUM 归约链。

每个域复用同一个 Macro 动作实现，每个物理 Macro 有独立四套 context，初始为空，替换跳过 active 项。记录被替换 context 上一次退出 active 的 wave，新的 LW 不得早于该 wave 排空。当前按整 wave 排空释放，是对文档逐 Core 滚动 IW 的保守近似；没有精确 Core busy 仿真。`schedule.domains` 报告每域任务及动作，不把芯片库存乘入执行计数。

**完整任务容量。**复用原生 TSP 的所选 slices 均匀条带布局与逐区向上取整检查；CIM 的 K 按 16、N 按 32 补齐，M 保持原值。A、B、C_PSUM 和显式 reserved 空间互不重叠；C_PSUM 同时存放中间与最终结果。默认半片 44 个 MEM slice、110 MiB；超过所选容量直接拒绝，不借用另一半片或片外内存。`tile_m` 默认 min(M,320)，表示流水行组，不是 collector 容量声明。

**LW 与公共资源。**沿用 §3.3.4 的 wordline 外层、Core pair 内层轮转：16 条 wordline，每轮扫描 10 对 Core；两个 Plane 同拍使用各自捕获位置。无编程的 slot 保留空拍，满宽完整扫描为 160 cycle；受共享资源限制时可延长。只有真正被编程的 Macro 计入权重 MEM 读取与写 wordline 动作。两 Plane 的 LW 和 activation 使用同一个输入方向预算，不能把每个域都配置为独占完整 stream。

资源日历按精确有理数记录每周期字节服务，维护 MEM read/write/shared 与 stream in/out 五种容量。已有行流水预约后，后续 LW 只消费各资源的剩余带宽；没有余量时等待预约边界。加载目标 context 尚未释放时也必须等待。该机制是确定性解析服务预约，不是运行时仲裁或逐 stream slot 仿真。`timing.resources` 输出预算与实际最高预约速率。

**压缩行流水。**wave 内各域并行。对一行，把全部域的 activation、旧 PSUM 读取、输出写回需求按共享资源相加，再取瓶颈：

```text
row_ii = max(8,
             ceil(total_MEM_read / allocated_read_bpc),
             ceil(total_MEM_write / allocated_write_bpc),
             ceil((total_MEM_read + total_MEM_write) / allocated_shared_bpc),
             ceil(input_stream_bytes / allocated_stream_bpc),
             ceil(output_stream_bytes / allocated_stream_bpc),
             ceil(external_K_adds / configured_VXM_adds_per_cycle))
wave_pipeline = first_row_latency + (rows - 1) × row_ii
```

首行包含 context 切换、activation capture、8 拍计算、局部流水假设 3 拍、沿有效 SuperLane 的归约目标每段 1 拍、最多 4 拍 Core stagger，以及外部 K 读取/加法/写回。四路 activation capture 遵循 CL0→CL3 相位，INT8 内部 II=8；跨 K 的首次服务还包含原生配置的 VXM 附加延迟。相同输出块的多个 K 段在首行依赖链中依次合并；后续行按公共服务 II 流水处理。

输出以 `writer_SL = 19 - (5 × cluster + core)` 转置到各 Plane 的独立 writer，满半片可使用 40 个不同 `(plane, writer_SL)` 位置。每个 INT8 Core 的 128 个 INT32 结果按 256 B/cycle 排空需 2 拍，整体仍受 stream/MEM 带宽限制。两份源文档对局部 NIM 与聚合输出的表述层级不同；本模型按详稿 §3.4.6 的分布式 writer 明确实现 INT32 旁路，不能用来推导 FP 转换算力。

wave 的行流水在时间上串行衔接；下一 wave 的 LW 可以提前使用剩余带宽。为避免首行/排空阶段额外的隐含带宽，整个 pipeline 窗口都按 `row_demand/row_ii` 预约服务，包含填充/排空，是显式保守策略。资源预约不是动作流量，不能另行计费。当前没有独立验证 collector 缓冲容量，也未实现域级异步补位、完整按 Core 的滚动切换或跨请求 warm-cache。

`timing.total_cycles` 是最后一次写回完成时间，`stages_cycles = load_wait + row_pipeline` 是不重叠的墙钟分解。`load_elapsed_cycles_sum` 可能与 pipeline 重叠，不可再次相加。`compute_occupancy.value` 为各 wave 最大域 ACC 占用之和，`domain_cycles_sum` 为全部域占用之和；都不是总延迟。

手算与回归：`M1/K320/N640` 为 160 拍 LW + 39 拍首行 = **199 cycle**；`M1/K320/N5120` 的 8 域完整 wave 为 160 +（切换1 + capture4 + 计算8 + 排空23 + stagger4 + 写回2）= **202 cycle**。验收任务 `M16/K32/N16` 为 **296 cycle**。默认 `M512/K256/N512` 仅有一个 K/N 分片，按 M320/192 分为两组，第二组复用权重，总计 **4307 cycle**，0.9 GHz 下约 4785.56 ns；不会因分配了 8 个域就虚构八倍加速。

**与原生基线。**半片比较使用同一个原生 runner，传递本次 count/timing 模式、MEM slices、stream 数、reserved 容量及 M 分组。两边均为本侧 MEM→MEM 和相同 INT8 GEMM。timing 输出 `analytical_cycle_ratio_native_over_cim`；`speedup`、能耗比仍为 null。尾部补齐、权重组织、原生安装串行与 CIM 后台 LW 等区别单独说明；该比值只评价所声明的解析策略，不等于硬件实测加速比。

### 半片版本迁移

CIM 硬件 schema 3 → 4：`nim_output_bpc` 数值仍为 256，scope 改为 `writer_superlane_plane`，来源条件补充 §3.4.6，旧 scope/schema 拒绝加载；其余硬件值不变，Macro profile 仍为 schema 2。旧 scope 的完整配置及原审阅证据存入台账 `prior_writer_scope`。

报告 schema 4 → 5：默认 model 为 `tsp_cim_hemisphere_reference`，scope 为 `single_hem`；新增 memory、schedule、共享资源预约和域级统计。`nim_output_bpc_per_plane` 派生项改名为 `nim_output_bpc_per_writer_superlane_plane`，新增半片 writer 结构目标；这不是额外物理资源。所有原生、Ascend、TPU 的配置和执行公式保持不变。

CLI 用 `--hemisphere 0/1` 选择半片；`--mem-slices ... --streams N --reserved-bytes N` 配置公共资源。`--cluster H P C` 必须与 `--scope single_cluster` 一起使用，其旧计数/串行时间公式保留作诊断；旧调用若要保持单域语义，必须显式加上该 scope。API 默认 scope 同样改为 single_hem；默认 mode 仍为 count，CLI 默认 mode 仍为 timing。

### 显式单 Cluster 诊断与计数

显式选择 `--scope single_cluster` 后执行范围为 `single_cluster`，选中一个 `(H,P,C)` 域。K/N tile 固定为 320×640，所有 tile 在该域上依次计数，不向其他 15 个域分派任务。默认把全部 M 行作为一个逻辑行组；可用 tile_m 改变循环顺序下的复用策略。这不是 M 行能同时驻留某个 buffer 的承诺。

继续调用共享 CIMMacroModel 和 MacroContexts，不另写 Macro 算术公式。每次 simulate 从空 tag 开始，同一 slot 内已有权重不重复装载，超出四套 context 后轮转替换非 active 项。调用边界假定旧任务已排空；不模拟 Cluster ready、运行中覆盖、后台 LW 或滚动 IW。

| 输出 | 口径 |
| --- | --- |
| useful_mac | M×K×N |
| issued_mac | M×ceil(K/16)×ceil(N/32)×512，Macro 尾块补零 |
| program_bytes / program_wordlines | 实际发生的整 context 装载，每次 512 B / 16 wordline |
| activation_capture_bytes | Macro 端捕获动作之和；包含广播 fanout |
| logical_activation_broadcast_bytes | M×ceil(K/16)×16×ceil(N/640)，每域输入一次；含 K 补零，不宣称 MEM 事务 |
| result_bytes | 所有 Macro 局部 INT32 输出之和 |
| logical_inter_superlane_adds | 各 K320 段内，对有效 N 的对应 SuperLane 分片归约义务 |
| logical_inter_k_tile_adds | M×N×(ceil(K/320)−1)，段间累加义务 |
| logical_cluster_partial_bytes | 4×M×N×ceil(K/320)，有效通道的段结果逻辑大小 |
| logical_output_bytes | 4×M×N，最终 C 的逻辑大小 |

两级 K 加法合计为 `M×N×(ceil(K/16)−1)`。它们是完整 GEMM 必需的逻辑次数，未计实际树/链的 padding 操作、PSUM buffer 读写或传输，不能直接当作物理活动能耗。保留的 cross_macro_k_adds / cross_tile_k_adds 是同一逻辑次数的旧名称，不能与新名称重复相加计费。

验算例：`M=1,K=320,N=640` 使用 400 Macro，useful/issued 都为 204800 MAC，首次编程 204800 B，域输入广播 320 B，Macro 端捕获 6400 B，Macro 局部输出 51200 B，域结果逻辑大小 2560 B，跨 SuperLane 归约 12160 次。`3×321×641` 的 useful/issued 分别为 617283 / 677376 MAC，两级 K 加法为 36537 / 1923 次。

`timing.compute_occupancy` 新增单域 ACC 占用派生量，依据详稿 §5.1 的每任务 `M×II`：

```text
K/N 任务数 = ceil(K/320) × ceil(N/640)
计算占用周期 = M × K/N 任务数 × 8
```

每个尾块仍占完整 II，域内 Macro 并行，不能再乘 Macro 数量。`tile_m` 和循环顺序可能改变权重编程/复用次数，但不会减少全部 K/N 任务处理的 M 行数；本项不计算这些编程或切换等待。比如 `1×320×640` 的 Macro 周期累计是 3200，而单域计算占用为 8；`3×321×641` 有四个 K/N 任务，计算占用为 96。占用项带 value/unit/scope/status/formula/source/source_version，不作为新的能耗 action 重复计费。

count 模式仍不产生总时间，`timing.status=not_computed`。timing 模式由下面的阶段模型计算 total_cycles、time_ns 和 throughput_gops；chip_cycles、energy、area 总量仍为 null。原生对比调用独立 tsp.py 同一个 reference runner；CIM 单域诊断与原生单 hemisphere 的 scope 不同且没有共同标定时序，speedup 和 energy_ratio 保持 null。

### 显式单 Cluster 串行诊断模型

仅在 `--scope single_cluster --mode timing` 下启用，模型标识为 `single_cluster_serial_v1`，状态为 `analytical_estimate`。边界是已位于本地 MEM 的 INT8 A/B 到本地 MEM 中逻辑 INT32 C；不包含主机搬运或打包。每次运行的权重 context 初始为空，沿用 count 的 K/N 分块、M 行分组、循环顺序与四套 context 替换规则。各 tile 及其阶段完全串行：

```text
装载新权重 → 切换 context → ACC 计算 → 流水排空
                                      ↓
           首个 K 段：                写回 C 部分和
           后续 K 段：读已有部分和 → INT32 累加 → 覆盖写回
```

设当前 tile 的有效尺寸为 `m,k,n`，`W=ceil(4*m*n/256)`。`timing.stages_cycles` 按下表逐 tile 累加，`total_cycles` 为七项之和，因此等于最后写回结束时刻减首次装载开始时刻。

| 阶段 | 每个 tile 的周期 | 依据与简化 |
| --- | --- | --- |
| load | 有任意新权重时 160，否则 0 | §3.3.4 完整轮转；对单域/尾块也预约完整扫描，未使用槽空闲，已有权重不重写；不另加未知物理写入罚时 |
| switch | 有任意 Macro 切换时 1，否则 0 | §3.5.3 每 Core 排空后下一拍切换，简化为一次域级屏障；初次激活也计 1 拍 |
| compute | `m*8` | §5.1 的 INT8 ACC 占用，包含尾块完整 II |
| drain | `8+3+ceil(k/16)` | 沿用参考脚本 `II+3+reduction_slices` 的近似；3 拍局部流水、每段 1 拍含捕获开销均为假设，Core 错峰并入该粗粒度预算 |
| partial_read | 首个 K 段 0，后续为 W | 后续段从 MEM 读取已有有效 INT32 部分和，暂用同一 256 B/cycle 服务代理 |
| partial_add | 首个 K 段 0，后续为 `ceil(m*n/64)` | 假设每拍处理 64 个 INT32 加法，匹配写回宽度；不是已标定 VXM 能力，也不增加硬件库存 |
| write | W | 每段归约/累加后写有效 N 列；最后一段自然得到最终 C，不再重复收取一次最终写回 |

`timing.parameters` 为这些模型参数逐项记录 value、unit、scope、status、source、source_version 和 conditions。其中 input II 有文档依据；轮转如何用于局部任务、流水额外延迟、域级切换、整数 writer 与外部累加服务均标为 assumed。本次配置精简保留全部计数和 Cluster 时间公式，模型策略参数仍单列于报告并由验收审阅记录核对；当前全工程来源台账包含 108 项有效参数。

激活供给假定能在 ACC 的行间隔内完成，不另收搬运时间；不模拟 LW/ACC 重叠、stream/bank 争用、collector 逐拍预约或物理 buffer 容量调度。串行化和完整扫描预约可能增大估计，理想化搬运/累加服务又可能减小估计，因此结果不宣称真实硬件的上界或下界。

例：`1×320×640` 为 `160+1+8+31+0+0+10=210 cycle`；`1×321×32` 的两个 K 段合计 385 cycle，包含一次已有部分和读取和累加。该诊断模式下 `16×32×16` 为 306 cycle，在继承的 0.9 GHz 下为 340 ns。时钟未知时仍可输出周期，ns/GOPS 保持 null。Macro 的四项局部 timing 参数及 API 已退役；这些 Cluster 假设仍明确标记为 assumed，不因此成为已标定数值。

### 输出 schema

输出 schema 为 5：reference_id 标识完整上层规格，macro_reference_id 单独标识共享 Macro；chip 库存位于 hardware_inventory.chip，topology 列出各层级，parameter_provenance 保留 topology/macro/shared_system 三类来源。count 的既有计数不变；timing 模式报告阶段、假设、策略参数及总时间，执行终点为 MEM 中逻辑 C。旧构造参数、supercell overlay、sheet/stack/hop helper 和旧报告字段不提供兼容分支。

### 2026-11-17 参数精简迁移

Macro profile 从 schema 1 升至 2，删除 `compute_first_cycles`、`write_first_cycles`、`write_wordline_ii_cycles`、`context_switch_cycles`；`compute`、`program_context`、`switch_context` 不再接受 `mode`（包括旧 `mode="count"`），直接调用即计数。任务 timing 使用 `TSPCIMSimulator.simulate(mode="timing")`。几何、II、四套 context、全部动作计数和 Cluster 时间公式不变。

CIM 硬件从 schema 2 升至 3，删除 `physical_sram_bytes`、`additional_local_sram_bytes`、`collector_buffer_bytes`。自定义配置删除对应字段后升级版本；旧 schema 和退役字段明确拒绝。报告从 schema 3 升至 4，库存同步移除这三项以及 `sxm_physical_units`、`stream_physical_endpoints`、`clock_domains`、`control_domains`。已知 SRAM 小计继续报告，collector 容量未验证的限制继续披露。

七项完整旧配置及原核验记录保存在来源台账的 `retired_parameters`，不计入有效参数。`nonlinear_ops_per_cycle` 留在原生配置和 CIM 的共享来源记录中，但退出 CIM GEMM 缺参列表。Issue #3 定义算子级服务；#4/#5 定义实际容量、组件成本和活动窗口；#6 定义外部供给与通信。本次删除不取消这些后续工作，也不宣称完整硬件成本已可计算。

<a id="migration"></a>

## 7. 文件组织与迁移

### 当前文件职责

| 架构/模块 | Spec 与配置 | 计算实现 | 测试 |
| --- | --- | --- | --- |
| Ascend | [ascend.py](src/hardware/ascend.py)、[配置](configs/hardware/ascend910_reference.json) | [core/ascend](src/core/ascend/) | [tests/ascend](tests/ascend/) |
| TPU | [tpu.py](src/hardware/tpu.py)、[配置](configs/hardware/tpu_v4_reference.json) | [core/tpu](src/core/tpu/) | [tests/tpu](tests/tpu/) |
| 原生 TSP | [tsp.py](src/hardware/tsp.py)、[参数校验](src/hardware/parameters.py)、[配置](configs/hardware/tsp.json) | [tiling](src/core/tsp/tiling.py)、[simulator](src/core/tsp/simulator.py) | [baseline](tests/tsp/test_baseline.py) |
| CIM Macro 支持模型 | [macro.py](src/hardware/macro.py)、[profile](configs/hardware/cim_macro.json) | [Macro](src/core/cim/macro_model.py)、[动作聚合](src/core/cim/simulator.py) | [tests/cim](tests/cim/) |
| CIM-TSP | [tsp_cim.py](src/hardware/tsp_cim.py)、[配置](configs/hardware/tsp_cim.json) | [半片模型](src/core/tsp_cim/hemisphere.py)、[资源日历](src/core/tsp_cim/resources.py)、[simulator](src/core/tsp_cim/simulator.py) | [topology](tests/tsp_cim/test_topology.py)、[config](tests/tsp_cim/test_config.py)、[count](tests/tsp_cim/test_count.py) |
| 公共模块 | [workload](src/utils/workload.py)、[原生参考](src/utils/tsp_reference.py)、各架构 config/report 模块 | 各架构入口保持独立 | [workload](tests/common/test_workload.py)、[inventory](tests/common/test_hardware_inventory.py) |

<a id="directory-migration"></a>

### 目录统一（2026-11-15）

本次按职责和架构整理目录，保留每个模型的公式、分块策略、状态更新、参数检查及报告字段。根目录四个架构启动文件、CLI 参数和配置文件路径保持不变；额外通用实验入口已按用户要求移除；项目内导入、文档链接与验收测试 ID 已同步迁移。

| 原位置 | 现位置 |
| --- | --- |
| `src/core/tsp_simulator.py`、`tsp_tiling.py` | [core/tsp/](src/core/tsp/) 下的 `simulator.py`、`tiling.py` |
| `src/core/tsp_cim_simulator.py`、`tsp_cim_tiling.py` | [core/tsp_cim/](src/core/tsp_cim/) 下的 `simulator.py`、`tiling.py` |
| `src/core/simulator.py`、`cim_macro_model.py` | [core/cim/](src/core/cim/) 下的 `simulator.py`、`macro_model.py`；通用组类及专用 `tiling.py` 已移除 |
| 原 `src/utils/config.py` / `cim_config.py` | 通用 `ConfigLoader` 已移除；Macro 引用解析函数原样保留在 [tsp_cim_config.py](src/utils/tsp_cim_config.py) |
| `src/hardware/tsp_parameters.py` | [parameters.py](src/hardware/parameters.py)，明确是 TSP、Macro、CIM-TSP 共用校验 |
| `tests/test_tsp_baseline.py` | [tests/tsp/test_baseline.py](tests/tsp/test_baseline.py) |
| `tests/test_tsp_cim_config.py`、`test_tsp_cim_count.py`、`test_tsp_cim_topology.py` | [tests/tsp_cim/](tests/tsp_cim/) 下的 `test_config.py`、`test_count.py`、`test_topology.py` |
| `tests/cim_macro/` | [tests/cim/](tests/cim/)，覆盖 Macro 和 CIM-TSP 集成 |
| 根层 workload、inventory、source audit 三个测试文件 | [tests/common/](tests/common/)，保留原文件名 |

四架构及 Macro 相关导出保留；通用实验专用的 `CIMCoreSimulator`、`TilingEngine`、`ConfigLoader` 导出随入口移除。直接导入旧内部模块的外部脚本需按表更新，例如 `src.core.tsp_simulator` 改为 `src.core.tsp.simulator`，或使用 `from src.core.tsp import TSPSimulator`。不保留重复实现或旧路径转发文件。

测试文件移动一层后，相应的工程根目录定位同步上移一层；公共 CLI 测试按文件路径加载 `tsp.py`、`tsp_cim.py`，避免与同名测试包冲突。通用实验的测试改为验证现存 CIM-TSP 与共享 Macro；验收继续检查四架构，并将非 GEMM 负例覆盖到四个入口。备份及本次等价性核对记录保存在工程外维护资料目录。

### 相对 `e5d3bfa` 的行为变化

| 范围 | 当前行为与迁移要求 |
| --- | --- |
| TPU 服务归约（2026-11-17，当前） | 硬件 schema 3、报告 schema 4：两项旧 Vector 速率替换为共享基准吞吐与两项操作代价；新增独立服务占用 API，未接入 GEMM。CMEM 可用容量假设为 128 MiB，带宽仍为唯一 null，路径旁路。SMEM 退出模型，寄存器改为芯片级 262144 B，不随核数缩放。旧版本/退役字段拒绝，迁移步骤见 TPU 章节 |
| TPU 首轮精简（2026-11-17，历史） | 硬件 schema 1 → 2、报告 schema 2 → 3：删除 Scalar 吞吐、独立 SFU 数量/吞吐和 ICI 单向服务共 4 项 null；移除 SFU 库存和 ICI 单向派生带宽。当时保留两项 Vector 参数及四项未知存储参数，随后由上行迁移更新。完整旧配置与证据保存在 retired_parameters |
| Ascend 配置精简（2026-11-17） | 硬件和报告升至 schema 4，移除 vector.fp32_ops_per_cycle、sfu.units_per_core、sfu.fp32_ops_per_cycle、chip.noc_bytes_per_cycle、chip.interconnect_bytes_per_second；同时移除两项 FP32 派生峰值和 SFU 库存。保留 Cube/Vector 数量、HBM 容量与 L2 带宽记录及全部 GEMM 服务；计数和时间公式不变。旧 schema 2/3 或已移除字段拒绝加载；自定义配置迁移时需删除对应字段并升级 schema，历史字段证据保存在来源台账 retired_parameters |
| 默认运行模式（2026-11-16） | 四入口省略 `--mode` 时改为 timing，直接在 `results/<架构>.json` 输出总周期、时间、阶段分解、计数与假设。`--mode count` 保留；核心 API 默认值、公式、数据流和参数配置不变；能耗、实际面积仍未评估 |
| 默认负载（2026-11-16） | 按用户要求仅保留 `tiny_gemm.json`（M512/K256/N512），精度改为 INT8；移除 `default_gemm.json`。四入口及 TSP/CIM 加载器默认使用保留文件，无需指定精度覆盖；原大尺寸任务可通过自定义 JSON 运行。模拟器公式和硬件配置不变 |
| 默认报告位置 | 四个入口从仅在指定 `--output` 时写文件，改为默认写入工程根目录 `results/<架构>.json`；自定义路径、自动创建父目录、覆盖规则见 [README](README.md)。`tests/common/test_output.py` 在临时工程中验证默认路径、自定义路径和失败保护 |
| 通用 CIM 实验入口 | 按用户要求移除 `main.py`、`configs/hardware/default_core.json`、`CIMCoreSimulator`、专用 `TilingEngine` 和 `ConfigLoader`。不再支持这套任意 Macro 数量/缓冲容量实验；CIM-TSP 的共享 Macro、context、聚合计数和引用解析继续保留，四架构参数与输出不变 |
| Ascend Cube 文件 | 原 `cube.py`、`cube_tiling.py`、`cube_simulator.py`、`cube_config.py` 由 Ascend 专属模块替代；旧 `ascend.json` 迁至带来源元数据的 `ascend910_reference.json` |
| Ascend 执行 | CLI 默认 timing；新增 `--mode`、`--tile`、`--l1-k`、`--output`；旧 `--loop-order`、`--energy`、`--verbose` 不再使用。K 累加计入 MAC，完整 K 结束后导出一次 C |
| TPU | 独立 `tpu.py` 和 TPU v4 配置；报告升至 schema 2，增加 MXU/TensorCore/Chip 层级及每核库存，原平铺 `hardware_inventory` 移到 `.chip`；硬件配置仍为 schema 1，单核计数不变 |
| TPU 时间估算（2026-11-16） | `--mode` 新增 `timing`，API `simulate` 增加同名可选参数；显式 count 的完整报告不变。timing 报告 model 为 `tpu_v4_analytical`，增加七阶段总时间、块内 MXU 批次与显式假设；保留 schema 2、原文件结构及硬件配置，未扩展为芯片调度 |
| 显式模型服务配置（2026-11-16） | 14 个原运行时代理写入 Ascend/TPU/TSP JSON，unknown 改 assumed，conditions 说明取法；null 不再启用服务回退。Ascend 与 TPU 固定服务变化需显式修改对应值；TSP 固定服务与任务派生量分离见下行 |
| TSP 参数精简（2026-11-17，当前） | 硬件/原生报告 schema 4；移除 6 项备用/物理 SRAM/外部系统参数和 3 项原生库存输出，仅保留 nonlinear_ops_per_cycle 为 unknown，供 Issue #3 后续定义。CIM 共享来源去掉三项外部系统参数；CIM 自有库存的后续精简见下行。旧配置需删字段并升级版本，完整历史与依据存入 retired_parameters；计数和时间不变 |
| TSP 固定服务重构（2026-11-16） | 硬件与报告升至 schema 3，移除 derivation；install_first_cycles 改为 install_propagation_cycles=19，只含传播；vxm_add_first_cycles 改为 vxm_add_latency_cycles=0，只含额外流水。不能直接把旧首行总延迟数值复制为新固定延迟；旧 schema/字段拒绝加载。VXM 速率固定为 320 op/cycle、scope=hemisphere；派生服务转入 timing.derived_services。删除加法中重复的 stream 限制，尾块按实际列数计时；默认时间和动作计数不变，部分受限/尾块时间修正 |
| 原生 TSP 初始迁移 | MEM 改为 220 MiB 参考容量；当时未知物理/局部 SRAM 为 null，现由 schema 4 精简移除；默认单 hemisphere timing，可显式选择 count，拒绝 chip 执行，取消周期折半 |
| CIM 半片执行（2026-11-17，当前） | 硬件 schema 4、报告 schema 5；默认 2 Plane/8 域静态 wave，完整本侧容量检查、共享带宽、后台 LW 与行流水。writer 按 §3.4.6 改为分布式作用域。单域诊断需显式 scope；比较入口传递实际资源与模式，另报解析周期比。详见半片章节 |
| CIM 参数精简（2026-11-17，历史） | Macro profile schema 2、CIM 硬件 schema 3、报告 schema 4；删除四项 Macro 局部时序和三项存储占位，移除独立 Macro timing API 及四项无消费路径的库存占位。原生 Nonlinear 保留在共享来源但退出 CIM GEMM 缺参列表。七项旧配置/证据归档，计数和 Cluster 时间公式不变；迁移步骤见 CIM 章节 |
| CIM Macro | 旧 Bank/Loc 读出模型、多精度缩放及内嵌 Macro 配置已移除；CIM-TSP 显式引用 `cim_macro.json`，不提供旧构造参数兼容分支 |
| CIM-TSP 上层（历史） | 旧 supercell overlay、sheet/stack/hop helper 被 Core/Cluster/Plane 规格替代；当时默认单域 K320×N640；`--cluster` 选择物理域，`--tile-m` 是逻辑行组，拒绝 chip 执行 |
| CIM-TSP 时间估算（2026-11-16） | schema 3 保留 `timing.compute_occupancy` 和三项 LW 派生量；原先拒绝的 `--mode timing` 改为显式假设下的串行阶段估算。count 的 timing.status 从 unavailable_system_model 改为 not_computed，原计数不变；不改变目录/配置或采用 800 MHz、全芯片 writer 作为单域标定值 |
| 原生比较 | 统一调用公共 runner；speedup/energy_ratio 因范围和系统时序不可比而为 null |
| 成本与 DSE | 旧 energy/area 配置、共享 `area_model.py`、`src/dse/` 和旧 `src/utils/report.py` 已移除；旧成本加载/导出 API 不可用。`tsp_cim.py --energy/--area` 明确拒绝 |
| 数据格式 | 公共目录仅保留 `KNOWN_FORMATS` 名称集合；移除未使用的 `DataFormatSpec`、`FORMAT_SPECS`、`get_format_spec()` 及尾数/保护位/共享指数开销数值。名称被识别不代表架构支持该精度；各入口按 workload 声明精度执行或明确拒绝，显式覆盖写入报告 |
| 无效 verbose 接口 | `tsp_cim.py` 移除原来被接受但未使用的 `--verbose`，现在按未知参数退出 2；调用方应删除该选项。`TSPCIMSimulator` 构造函数同步移除 `verbose`；`tsp.py --verbose` 保留 |
| TSP 辅助 API | 移除无调用方的 `summarize_topology()` 及仅被它调用的 `plane_tandem_factor()`。库存/派生量通过 `area_inventory()`、`derived()` 获取；测试使用的 `describe_supercell_usage()` 保留 |
| 运行依赖 | 移除未使用的 NumPy、pandas、python-dateutil、tzdata 依赖；运行、测试和验收均使用标准库，`requirements.txt` 仅保留说明 |
| 测试 | 旧能耗/面积数值回归由新规格、动作、库存和未知状态测试替代；`tests/common/test_hardware_inventory.py` 检查库存与未评估面积 |
| 文档 | 本文维护现行技术说明，README 提供使用入口；教学、汇报、历史计划及备份迁至工程外资料目录 |

JSON schema 各自版本化：Ascend 硬件/报告为 4；TPU 硬件为 3、报告为 4；TSP 硬件/报告为 4；CIM Macro profile 为 2；CIM-TSP 硬件为 4、报告为 5。应读取实际 schema 字段，不假设所有架构报告形状相同。

参数来源台账绑定配置版本。修改参数、来源或作用域后，应重新核验并生成报告；旧报告不自动继承新的核验结论。

<a id="validation"></a>

## 8. 验证与 issue #2 状态

这里按 [issue #2 原文](https://github.com/pku-pacific-lab-team/huawei_dfp/issues/2) 的**四类交付物 D1–D4、五条验收条件 A1–A5**逐项对应。四类交付物不等于四个仿真器；每类交付物都覆盖相关架构。历史 16 核/128T 目标已由用户明确排除，其他验收条件仍保留。

### 四类交付物在哪里

| 编号 | 交付物 | 实际位置 | 如何查看 |
|---|---|---|---|
| D1 | 四架构配置和参数来源表 | [Ascend 配置](configs/hardware/ascend910_reference.json)、[TPU 配置](configs/hardware/tpu_v4_reference.json)、[TSP 配置](configs/hardware/tsp.json)、[CIM-TSP 配置](configs/hardware/tsp_cim.json)，另有共享 [Macro profile](configs/hardware/cim_macro.json)；[108 项有效参数来源台账](calibration/parameter_source_audit.json) | 配置查看 value/unit/scope/status/source/version；台账查看原文页码、章节、版本及缺口理由 |
| D2 | 架构设计及 MXM 替换说明 | 本文[总览](#simulator-structure)、[Ascend](#ascend)、[TPU](#tpu)、[TSP](#tsp)、[Macro](#cim-macro)、[CIM-TSP](#cim-tsp)章节，及[迁移说明](#migration) | 查看数据路径、执行边界、Core/Cluster/Plane 拓扑、Macro 编程/复用、PSUM 归约与公共原生基线 |
| D3 | 派生算力、容量、带宽与面积库存测试 | [Ascend](tests/ascend/test_config.py)、[TPU](tests/tpu/test_config.py)、[TSP](tests/tsp/test_baseline.py)、[CIM 拓扑/库存](tests/tsp_cim/test_topology.py)、[Macro](tests/cim/test_model.py) | [逐项结果](validation/issue2/run/tests.json)中找 A2 对应的完整 test ID；[原始测试日志](validation/issue2/run/unittest.txt)保留断言失败信息 |
| D4 | 四入口 INT8 GEMM 冒烟 | [统一任务](validation/issue2/run/workload.json)，输出分别为 [Ascend](validation/issue2/run/ascend.json)、[TPU](validation/issue2/run/tpu.json)、[TSP](validation/issue2/run/tsp.json)、[CIM-TSP](validation/issue2/run/tsp_cim.json) | [命令与检查结果](validation/issue2/run/commands.json)记录实际子进程参数、退出码、stdout/stderr 和输出校验 |

### 五条条件如何判断通过

最新本地结果以 [acceptance.json](validation/issue2/run/acceptance.json) 为准。`conditions.A1` 到 `A5` 分别列出对应测试 ID、命令结果和审阅依据；全部通过还要求整个测试集无失败/跳过，运行期间代码配置未变化。

| 编号 | 验收条件 | 直接证据与通过判据 | 判定方式 |
|---|---|---|---|
| A1 | 来源、单位和作用范围可追溯 | 108 项有效参数与台账完整对应，配置哈希一致；字段/单位/作用域校验测试通过；原始来源的语义审阅见 [review.json](validation/issue2/review.json)及来源台账 | 自动校验 + 已记录的来源审阅；不是脚本重新读论文后自动确认硬件 |
| A2 | 四类派生量和库存通过测试 | 明确映射的测试覆盖 Ascend/TPU/TSP/CIM/Macro：算力、容量、带宽换算和分层库存；TPU 检查三级峰值、私有/共享资源聚合与单核 VMEM 不合池，另有 TPU/CIM 阶段时间手算、MXU 分批与跨 K 累加；完整 ID 位于 `conditions.A2.tests` | 自动测试；面积库存通过不代表输出了 mm² 预测 |
| A3 | 缺参显式处理，不静默补值 | 负例及 unknown 传播测试，包括 TPU 跨层依赖；Ascend 缺 GM 路径服务、TSP 缺 MEM 基础服务、TPU 缺 HBM 可用容量或 timing 时钟的四个 CLI 负例退出 2 且无成功报告。四架构 timing 正例检查 assumed 参数、保留的硬件 unknown 和 null 芯片时间 | 自动测试 + CLI 正/负例；显式服务标 assumed，其他 unknown 保留，Macro 退役字段/API 明确拒绝，CIM 时钟 unknown 仍传播 |
| A4 | 四入口 INT8 GEMM 冒烟完成 | 四份 count 报告为同一 M16/K32/N16、INT8 输入、INT32 累加/输出；`useful_ops=16384`，作用域正确，action/provenance 非空且无虚构时间；TPU 另查 schema 4、芯片寄存器库存、预留 Vector 服务及单核计数不随库存放大。四个 timing 正例分别核对 Ascend 60、TPU 292、TSP 58、CIM 296 cycle，以及时间换算和阶段求和 | 自动测试 + 子进程 JSON 检查；不以进程退出 0 单独判定，也不要求四者补齐动作相同 |
| A5 | 行为变化已记录，四入口保持 GEMM 边界 | [迁移表](#migration)逐项审阅并绑定代码快照；旧接口/精度行为测试；四架构 GEMM 正例成功，四个入口的非 GEMM 请求均退出 2 且不产生成功报告 | 自动检查 + 已记录的代码/文档审阅；脚本不能独立证明迁移说明的语义完整性 |

A1 的通过含义是每项的文档依据、模型假设或未标定身份可追溯，模型所用单位/作用域明确。当前 **71 documented、33 assumed、4 unknown**；存在假设或缺口已按照 issue 的显式标记要求保留，不能把它解释为 108 项硬件参数均已确认。Ascend LLC 的两个公开数字尚未对齐统计口径，该字段仍为 null。

四架构实际任务时间参数另列于 timing.parameters。2026-11-16 将 14 个已有服务代理迁入当时的 130 个配置字段；后续精简、TPU 服务替换、TSP 六项及 CIM 七项字段退役后现有 108 项有效参数。Ascend 的 5 项、TPU 的 8 项、TSP 的 6 项、Macro 的 4 项和 CIM 上层的 3 项旧字段另存于 retired_parameters；共享 Vector 服务/操作代价及 CMEM 容量的四项新假设不改变 GEMM 时间。验收验证公式和配置语义，不等于硬件实测验证。

### 一条命令重新验收

```powershell
$env:PYTHONUTF8 = "1"
.\.venv\Scripts\python.exe scripts/verify_issue2.py
```

脚本运行全部单元测试，再执行四架构显式 count 冒烟、四架构默认 timing 正例、缺参负例和四入口非 GEMM 边界检查。默认覆盖写入 `validation/issue2/run/` 的本轮结果，可用 `--output-dir results/my_issue2_run` 输出到其他目录。每个 CLI 使用临时输出路径，避免上一次的成功 JSON 被误当成本次结果。

读取 `acceptance.json` 时检查：`local_acceptance_passed=true`、五项 status 均为 `passed` 或 `passed_with_recorded_review`、`unit_tests.status_counts` 全为 passed，以及 `snapshot_unchanged_during_run=true`。脚本只有满足这些条件才退出 0。A1/A5 若缺少审阅记录或代码/文档/配置快照变化，会返回 `needs_review` 和非零退出码，不自动续用旧审阅结论。

本轮审阅记录由 Codex 根据原文、代码和迁移说明核对生成，不表示用户或外部验收组已经签字。记录绑定完整本地工作区内容，包括未提交文件；Git HEAD 仅作背景信息。只有单元测试总数不能替代五条验收证据，来源核验也不等于硬件标定。该本地验收不会提交代码、发布结果或关闭 GitHub issue。

<a id="source-audit"></a>

### 参数来源核验结果

原始来源核验日期：2026-11-14；配置模型政策更新：2026-11-17（America/Los_Angeles）。覆盖 **108 项有效参数**，当前为 **71 documented、33 assumed、4 unknown**。先前 14 项变化为已有模型代理显式化；此前新增 LLMCompass 固定版本代码作为方法依据，Vector 三项和 CMEM 可用容量明确为假设，芯片寄存器容量使用已核对的论文证据。TSP 六项未参与执行的字段已退役，仅保留非线性服务缺口；CIM 另外七项未使用参数及独立 Macro timing API 已退役，几何、动作和 Cluster 时间模型保留。没有新增硬件标定；旧判断保存在 retired_parameters 或 prior_hardware_disposition。

| 范围 | 已核验与修正 | 保留的边界 |
|---|---|---|
| Ascend 910 | 1 GHz、每核 Cube/Vector 各 1、32 核；HBM 1.2 TB/s；原文存储标签、NoC 链路与 die 面积入台账 | KB/MB 到 byte 的解释与可用容量仍为假设；LLC 3/4 TB/s 冲突；五条路径和 Cube 服务已显式采用 assumed 值，尚未标定 |
| TPU v4 | 结构引用从误写 §2.2 改到第 2 节开头；表 4 与官方文档的计算、存储、ICI、工艺/面积字段已核对；0.25 MiB 芯片寄存器库存入台账 | 不能把芯片寄存器总量任意平分为每 TC；50 GB/s/link 不直接当单向有效载荷带宽 |
| 原生 TSP | 指定架构和 SOW 精确 blob 已恢复，修复把 blob 当 commit 的引用；SR/stream 作用域已改正；四项结构假设升级为 documented；schema 4 移除六项非执行参数 | 共享 MEM 320 B/cycle 是软件保守策略；任务服务显式采用 assumed 值；唯一 null 为 Issue #3 预留的非线性服务，未接入 GEMM |
| CIM Macro / CIM-TSP | 几何、上下文、INT8 II、Core/Cluster/Plane、LW/NIM 逐项核对；32 B wordline 升级为 documented 项目设计；区分分布式 LW 与末端 writer | 设计 II 不等于首结果延迟；缓冲示例不等于完整物理 SRAM；有效系统时序仍未标定 |

[机器可读核验台账](calibration/parameter_source_audit.json) 保存每个参数的判断、来源 ID、章节/页码/行号，以及来源的 Git commit/blob 或 PDF SHA256。它同时绑定五份配置的规范化 JSON 哈希；配置改变而未刷新核验记录会触发回归失败。下载的原始全文保存在工程外资料目录（本机 `D:\IC_paper\huawei_dfp`），工程内保留可追溯引用及核验台账。

原始核验完成来源追溯和作用域审阅；已有 14 个任务服务代理及新增 TPU 预留服务/容量假设分别记录。Ascend 移除的 5 项、TPU 移除/替换的 8 项、TSP 移除的 6 项、Macro 移除的 4 项及 CIM 上层移除的 3 项旧字段保留完整配置和依据，见对应 profile 的 retired_parameters；剩余 4 个有效 unknown 记录其缺口和当前用途。assumed 不代表硬件事实已经确认，后续可信 timing/能耗/面积预测仍需校准。

<a id="remaining"></a>

## 9. 待确认参数与后续工作

### 核验后仍未确定的参数

| 范围 | 待确认内容 | 当前处理 |
| --- | --- | --- |
| Ascend | HBM 精确 byte 容量、LLC 带宽口径仍为 null；核内容量假设、Cube 和五条路径 assumed 服务及 INT32 导出实现待标定 | schema 4 仅保留上述两项 null；通用 Vector/SFU 速率、独立 SFU 数量及两种聚合互联速率已移至退役记录。未来算子与网络模型扩展时再定义服务 |
| TPU v4 | 仅 CMEM 带宽仍为 null；Vector 基准吞吐/操作代价、CMEM 可用容量、VMEM 带宽等 assumed 值仍待标定；特殊函数和归约需独立定义代价 | Vector 采用一个共享服务，GEMM 暂不调用；CMEM 保留容量场景但路径旁路；SMEM 移除，寄存器为芯片级规格。当前 GEMM 计数/时间公式不变 |
| 原生 TSP | 唯一 null 为非线性服务；已有安装/MXM/VXM assumed 服务仍待标定 | Issue #3 定义粗粒度非线性操作与共享资源代价；当前 GEMM 固定服务保持显式假设。六项非执行字段已退役，片外供给/互联由 Issue #6 独立系统层定义 |
| CIM Macro | 活动能耗和面积系数尚未标定 | 当前只提供几何、II、context 状态与动作计数；独立局部时序参数/API 已退役，后续成本模型按动作与组件接入 |
| CIM-TSP | collector 实际容量、逐 bank/stream 调度与 assumed 服务仍待完善/标定 | 不保留无消费路径的容量占位；232.5 MiB 仅为已知小计，collector 容量未验证。共享 Nonlinear 来源保留，但不视为 GEMM 缺参 |

后续取得新证据时，应同步更新 JSON 的数值或状态、来源版本、条件及适用的 verification，刷新核验台账并运行对应回归。允许明确接受未标定项，不以任意数值填满表格作为完成标准。

### 后续模型增强

整片任务分配、真实 MEM 事务、逐 bank/stream/NoC 争用、逐拍调度、精确滚动 IW、真实缓存、数值仿真、整模和多芯片支持仍未实现；CIM 已有半片静态 wave、MEM 容量检查、解析共享带宽和后台 LW，仍需电路/调度标定。TPU 的 HBM-to-HBM 与 CIM 的 MEM-to-MEM 时间均采用上述显式假设。能耗系数、面积密度与实测拟合也需要另行补充。这些工作属于后续模型扩展，不自动作为 issue #2 规格与入口阶段的验收前提。

