"""One-time metadata migration for the shared TSP VXM implementation."""
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read(path):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def save(path, value):
    (ROOT / path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


cfg = read("configs/hardware/tsp.json")
old_cfg = read("tmp/tsp_vxm_service/configs/hardware/tsp.json")
old_audit = read("tmp/tsp_vxm_service/calibration/parameter_source_audit.json")
audit = read("calibration/parameter_source_audit.json")
profile = audit["configs"]["configs/hardware/tsp.json"]
for key, reason in {
    "vxm_add_ops_per_cycle": "Replaced by one shared VXM equivalent-op budget and explicit INT32 add cost; preserve default add rate without a second independent service.",
    "nonlinear_ops_per_cycle": "Replaced by operation-specific FP32 costs. User selected explicit algorithmic assumptions (exp=15, rsqrt=12), not an unknown chip-wide nonlinear rate or native instruction timing.",
}.items():
    name = "parameters." + key
    profile["retired_parameters"][name] = {
        "retired_at": "2026-11-18 America/Los_Angeles", "reason": reason,
        "last_configuration": old_cfg["parameters"][key],
        "prior_audit": old_audit["configs"]["configs/hardware/tsp.json"]["parameters"][name],
    }
    profile["parameters"].pop(name, None)

audit["sources"]["tsp_vxm_algorithmic_reference"] = {
    "title": "Shared single-task VXM service and explicit exp/rsqrt algorithmic work proxies",
    "classification": "model_policy", "path": "ARCHITECTURE.md#tsp-vxm-service",
    "version": "vxm-algorithmic-reference-v1; 2026-11-18",
    "identity_verification": "Local algorithmic accounting reviewed: exp=4+10+1, rsqrt=2+2*(4+1); not native instruction latency, calibrated silicon throughput, or numerical execution.",
}
names = ("vxm_base_ops_per_cycle", "vxm_int32_add_cost", "vxm_fp32_basic_op_cost",
         "vxm_fp32_exp_cost", "vxm_fp32_rsqrt_cost", "vxm_add_latency_cycles")
for key in names:
    p = cfg["parameters"][key]
    p["source_version"] = "vxm-algorithmic-reference-v1; 2026-11-18; original hardware context retained in source and retired parameter evidence"
    entry = copy.deepcopy(profile["parameters"].get("parameters." + key, {}))
    if key == "vxm_base_ops_per_cycle":
        entry = copy.deepcopy(profile["retired_parameters"]["parameters.vxm_add_ops_per_cycle"]["prior_audit"])
    entry.update(result="explicit_model_assumption", status=p["status"], decision=p["conditions"])
    evidence = entry.setdefault("evidence", [])
    evidence.append({"source_id": "tsp_vxm_algorithmic_reference", "locator": "ARCHITECTURE.md#tsp-vxm-service",
                     "finding": "Shared compute occupancy; no additive dtype resources or full nonlinear operator execution. Configuration value is an explicit model assumption."})
    profile["parameters"]["parameters." + key] = entry
profile["parameters"] = {"parameters." + k: profile["parameters"]["parameters." + k] for k in cfg["parameters"]}
save("configs/hardware/tsp.json", cfg)
profile["canonical_json_sha256"] = hashlib.sha256(json.dumps(cfg, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
profile["parameter_count"] = len(cfg["parameters"])
profile["status_counts"] = dict(Counter(p["status"] for p in cfg["parameters"].values()))
entries = [p for item in audit["configs"].values() for p in item["parameters"].values()]
audit["total_parameters_reviewed"] = len(entries)
audit["status_counts"] = dict(Counter(p["status"] for p in entries))
audit["result_counts"] = dict(Counter(p["result"] for p in entries))
audit["configuration_reviewed_at"] = "2026-11-18 America/Los_Angeles"
audit["completion_boundary"] = (
    "All 111 active parameters have traceable dispositions: 70 documented, 41 assumed, 0 unknown. "
    "TSP hardware schema 6 replaces add/nonlinear rates with a shared single-task VXM budget and operation costs; "
    "the reference has 31 non-null parameters, including exp=15 and rsqrt=12 explicit algorithmic work proxies. "
    "Only INT32 add is consumed by native/CIM GEMM. Independent FP32 services do not implement full nonlinear operators "
    "or calibrate native special-function timing. Existing Ascend L2 and TPU CMEM proxy/bypass policies are unchanged. "
    "Historical hardware uncertainty remains in retired evidence; no silicon calibration claimed.")
audit["findings"]["tsp_vxm_service_2026_11_18"] = {
    "decision": audit["completion_boundary"], "basis": "ARCHITECTURE.md#tsp-vxm-service",
    "preserved_gemm_rate": "320 equivalent op/cycle / 1 equivalent_op/add = 320 add/cycle",
}
save("calibration/parameter_source_audit.json", audit)

replacements = {
    "README.md": {
        "TSP 当前硬件和报告均为 schema 5": "TSP 当前硬件和报告均为 schema 6",
        "当前共 28 项，唯一 null 为给 [Issue #3](https://github.com/pku-pacific-lab-team/huawei_dfp/issues/3) 预留的 `nonlinear_ops_per_cycle`，GEMM 不使用它。": "schema 6 进一步替换旧 add/nonlinear 速率，当前共 31 项且无 null；19 项 documented、12 项 assumed。共享 VXM 预算为 320 op/cycle，INT32 add/FP32 add/mul 代价为 1，exp 为 15、rsqrt 为 12。`TSPSpec.vxm_service_cycles()` 支持独立计算占用估算；原生/CIM GEMM 只消费 INT32 add。特殊函数值是算法工作量代理，不是原生指令时序。迁移及 API 示例见 [共享 VXM 服务](ARCHITECTURE.md#tsp-vxm-service)。",
        "原生 `nonlinear_ops_per_cycle` 及共享来源保留，但不再列为 CIM GEMM 缺参。": "该次精简曾保留原生 `nonlinear_ops_per_cycle`；当前已由原生 schema 6 的共享 VXM 操作代价替换，CIM 同步来源与服务，报告 schema 7。",
    },
    "ARCHITECTURE.md": {
        "当前 schema 5 保持这套服务定义": "当前 schema 6 保持安装服务，并将 VXM 加法速率归约为共享预算/操作代价",
        "当前报告 schema 5，timing.model=single_hem_fixed_services_v2": "当前报告 schema 6，timing.model=single_hem_fixed_services_v2",
        "额外本地/物理 SRAM 仍可为空，报告不捏造库存。": "额外本地/物理 SRAM 字段已退役，报告不捏造库存。",
        "当前硬件 schema 4、报告 schema 5。": "当前 CIM 硬件 schema 5、报告 schema 7；原生还需完成 schema 5 的 execution 迁移及 schema 6 的共享 VXM 迁移。",
        "`nonlinear_ops_per_cycle` 为 Issue #3 保留在原生配置及 CIM 来源记录中，不参与当前 GEMM，也不列入 CIM 的 `missing_parameters`": "原生 schema 6 的 VXM 预算和操作代价由 CIM 共用；原生/CIM 的跨 K 累加都调用共享服务 API。FP32 代价在来源和 `hardware_derived.vxm_service` 中披露，不参与当前 GEMM，也不列入 CIM 的 `missing_parameters`",
        "`nonlinear_ops_per_cycle` 留在原生配置和 CIM 的共享来源记录中，但退出 CIM GEMM 缺参列表。": "历史 `nonlinear_ops_per_cycle` 曾保留为预留项；当前已迁移为共享 VXM 服务，完整旧记录归档在原生来源台账。",
    },
    "scripts/verify_issue2.py": {
        "test_retired_parameters_rejected_and_nonlinear_reserved": "test_retired_parameters_rejected_and_fp32_costs_not_used_by_gemm",
        "test_nonlinear_is_visible_but_not_a_gemm_missing_parameter": "test_fp32_service_is_visible_but_not_a_gemm_missing_parameter",
        'fixed_service_schema=r["schema_version"] == 5': 'fixed_service_schema=r["schema_version"] == 6',
        'nonlinear_provenance_preserved=r["parameter_provenance"]["shared_system"]["nonlinear_ops_per_cycle"]["value"] is None,':
            'vxm_costs_preserved=r["parameter_provenance"]["shared_system"]["vxm_fp32_exp_cost"]["value"] == 15\n                        and r["parameter_provenance"]["shared_system"]["vxm_fp32_rsqrt_cost"]["value"] == 12\n                        and r["hardware_derived"]["vxm_service"]["nonlinear_included_in_gemm"] is False,',
    },
}
for relative, changes in replacements.items():
    path = ROOT / relative
    text = path.read_text(encoding="utf-8")
    for old, new in changes.items():
        if old not in text:
            raise ValueError(f"Missing migration target in {relative}: {old}")
        text = text.replace(old, new)
    if relative == "scripts/verify_issue2.py":
        old = 'if r.get("model") == "tsp_cim_hemisphere_reference":'
        prefix, suffix = text.split(old, 1)
        suffix = suffix.replace('report_schema=r.get("schema_version") == 6', 'report_schema=r.get("schema_version") == 7', 1)
        text = prefix + old + suffix
    path.write_text(text, encoding="utf-8")
print("Refreshed TSP audit, migration docs and acceptance mappings:", audit["status_counts"])
