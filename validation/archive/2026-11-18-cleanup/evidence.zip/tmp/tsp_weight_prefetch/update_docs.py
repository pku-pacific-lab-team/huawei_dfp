from pathlib import Path

p = Path('ARCHITECTURE.md')
s = p.read_text(encoding='utf-8')
start = s.index('#### 权重\n', s.index('### 可选时间公式'))
end = s.index('#### 行服务\n', start)
s = s[:start] + '''<a id="tsp-weight-prefetch"></a>

#### 权重预取与安装

原生 TSP 仅保留受约束的后台预取：`weight_load_overlap="background"`、`inter_tile_overlap="weight_prefetch"`。旧串行策略和旧 schema 拒绝加载，不保留运行分支。

公开依据：[Answer Fast III-C，第 5 页](https://arxiv.org/pdf/2206.11062#page=5)明确描述在同一 MXM plane 执行 pass i−1 时加载 pass i 权重，在该 BERT 调度中隐藏安装延迟；[Hot Chips 34，第 25 页](https://hc34.hotchips.org/assets/program/conference/day2/Machine%20Learning/HotChips34%20-%20Groq%20-%20Abts%20-%20final.pdf#page=25)区分 LW（stream→权重缓冲）和 IW（缓冲/stream→阵列）。这些资料支持重叠机制；以下容量与具体时序是本工程的显式假设。

按 plane 保存 `(K 起点、N 起点、填充 K、列数)` 权重标签，只为变化的 plane 装载。不同 M 块继续复用驻留权重。`weight_buffer_bytes=204800` 假设容纳本侧两个 320×320 INT8 plane 的一个待用块（200 KiB），并非公开硬件容量；它与 MEM 中的一份 A/B/C 分配分开，不能加到已核验物理 SRAM 库存。缓冲不足时 count/timing 都明确拒绝，可显式缩小 tile。缓冲再大也只预取一个后续权重块。

```text
MEM --LW(共享读/stream预算)--> 待用权重缓冲 --IW(内部端口)--> MXM 当前权重
           可与当前行流水并发                  等上一块行流水排空

LW_idle = ceil(max(weight_payload / MEM_read_Bpc,
                   padded_weight_stream_bytes / stream_to_MXM_Bpc))
IW = install_propagation_cycles + ceil(weight_payload / install_bpc)

row_resource_rate[r] = row_payload[r] / II_row
LW_fraction_per_cycle = min(
    (MEM_read_Bpc - row_resource_rate[mem_read]) / weight_payload,
    (stream_to_MXM_Bpc - row_resource_rate[stream_to_mxm]) / padded_weight_stream_bytes)
```

LW 使用当前行窗口剩余的读与同方向 stream 带宽；读服务已满或 stream 已满时暂停，写预算独立。用精确有理数推进 payload 与补齐 stream 的相同完成比例，最后不足一拍向上取整。预取可跨越多个复用当前 B 的 M 块。LW capture 未另加端口瓶颈，是显式假设；全片 stream 上限仍约束本侧分配。

当前 IW 采用保守排空策略：等待上一 tile 的行窗口结束、目标 LW 完成后，消耗内部 `install_bpc=10240 B/cycle` 与固定传播 19 cycle。IW 不再次读取 MEM/stream。待用槽在 IW 结束后释放，才能预取再下一块；不会覆盖当前阵列仍在使用的权重。论文中的滚动安装/无空转并未逐指令复现，不能把这项保守时序称为硬件必需间隙。

`schedule.tiles` 给出各 tile 的 LW、IW、行窗口及保留速率；`schedule.weight_load_segments` 给出实际搬运段、字节和带宽。行需求/II 在整个首行填充、稳态和排空窗口上保留，可能压低可用预取带宽。这是压缩流体服务模型，不是逐 bank/stream slot 模拟。

''' + s[end:]
s = s.replace('T_total = sum_over_tiles(T_install_if_needed + T_rows)',
              'T_total = weight_load_stall_cycles + install_cycles + row_service_cycles')
replacements = {
 '| TSP | 6 | 6 | 单半片；tile 320/320/640；行流水；权重安装与计算串行；共享 VXM 操作代价 |':
 '| TSP | 8 | 8 | 单半片；tile 320/320/640；有限缓冲后台权重预取与行流水；共享 VXM 操作代价 |',
 '| CIM-TSP | 5 | 7 |': '| CIM-TSP | 6 | 8 |',
 '，报告 schema 7 |\n| CIM-TSP': '，报告 schema 8 |\n| CIM-TSP',
 'TSP/CIM 的容量、MEM/stream 分配和 M 行组可匹配，默认装载策略同为串行。':
 'TSP/CIM 的容量、MEM/stream 分配和 M 行组可匹配；原生固定采用后台预取，CIM 默认仍为串行，后台 LW 为显式选项。',
 '分别报告原生串行、CIM 串行、CIM 后台装载的周期与计数一致性':
 '分别报告原生预取、CIM 串行、CIM 后台装载的周期与计数一致性（原生字段为 native_prefetch_cycles）',
 '当前 schema 7 采用独立 MEM 读写预算，保持安装服务':
 '当前 schema 8 采用独立 MEM 读写预算，将 LW 预取与内部 IW 服务分开',
 '压缩行流水是可解释的理想稳定服务假设，没有证明逐指令静态排程；不生成行/stream 事件。块间不重叠。':
 '压缩行流水没有证明逐指令静态排程；只输出 tile 窗口与 LW 搬运段。计算块间保留排空边界，后续权重预取可以与当前行窗口重叠。',
 '为 13 cycles，三行复用同一权重为 17 cycles；K=32 分两块为 29 cycles':
 '为 14 cycles，三行复用同一权重为 18 cycles；K=32 分两块为 31 cycles（单 stream 已满，无法隐藏 LW）',
 'timing.derived_services 记录当前 MEM/stream/安装带宽、安装发射组与周期、首组完成时间以及实际使用的 VXM 行计算/首行时间最小最大值':
 'timing.derived_services 记录当前 MEM/stream 带宽、LW 空闲峰值、独立 IW 带宽、权重缓冲容量以及实际使用的 VXM 行计算/首行时间最小最大值',
 '| `install_bpc` | 10240 B/cycle | 安装端口上限；实际带宽与已分配 MEM/stream 取 min |':
 '| `weight_buffer_bytes` | 204800 byte | 假设一个待用权重块；独立于 MEM 驻留容量 |\n| `install_bpc` | 10240 B/cycle | 缓冲到阵列的内部 IW 端口；不再与 MEM/stream 取 min |',
 '原生 TSP 硬件/报告 schema 7，CIM 硬件 schema 6、报告 schema 8。':
 '原生 TSP 当前硬件/报告 schema 8（独立 MEM 读写规则自 schema 7 引入），CIM 硬件 schema 6、报告 schema 8。',
 '原生现有 30 项参数（19 documented、11 assumed），全部非空。':
 '原生当前有 31 项参数（19 documented、12 assumed），全部非空；schema 8 新增有限权重缓冲容量。',
 '安装仅消耗读服务；所有计数和总 MEM 容量不变':
 'LW 消耗读服务，IW 消耗内部端口；所有计数和总 MEM 容量不变',
 '硬件 schema 7 沿用 schema 6 引入的': '硬件 schema 8 沿用 schema 6 引入的',
 '原生安装串行与 CIM 后台 LW 等策略差异仍披露':
 '原生单待用块预取、CIM 多 context LW 与各自切换屏障的差异仍披露',
 '| `install_bpc` | 10240 | byte/cycle | hemisphere | assumed | tsp_design + model_policy / explicit_model_assumption |':
 '| `weight_buffer_bytes` | 204800 | byte | hemisphere | assumed | asap2022 + hotchips2022 + tsp_weight_prefetch_policy / explicit_model_assumption |\n| `install_bpc` | 10240 | byte/cycle | hemisphere | assumed | tsp_design + tsp_weight_prefetch_policy / explicit_model_assumption |',
 '当前硬件与原生报告均为 schema 7，共 30 项参数：19 documented、11 assumed、0 unknown。':
 '当前硬件与原生报告均为 schema 8，共 31 项参数：19 documented、12 assumed、0 unknown。',
 '及 schema 7 的独立 MEM 读写迁移。':
 '、schema 7 的独立 MEM 读写迁移及 schema 8 的有限权重缓冲预取迁移。',
 'schema 7 的参考参数已无 null': 'schema 8 的参考参数已无 null',
}
for a, b in replacements.items():
    if a not in s: print('Not found:', a)
    s = s.replace(a, b)
lines = s.splitlines()
for i, line in enumerate(lines):
    if line.startswith('当前报告 schema 7，timing.model=single_hem_fixed_services_v3'):
        lines[i] = '当前报告 schema 8，`timing.model=single_hem_weight_prefetch_v1`。`stages_cycles` 是不重叠的墙钟分解：等待 LW + IW + 行窗口。`weight_load_cycles` 为所有实际 LW 段长度之和，其中 `weight_load_overlap_cycles` 已包含在行窗口，不能重复加到总周期。当前 16/32/16 为 **59 cycle**、1/321/16 为 **89 cycle**、tiny 为 **601 cycle**；M3/K321/N640、单 stream/单 slice 为 **865 cycle**，默认分配 M2/K321/N641 为 **221 cycle**。首次 LW 和内部 IW 现在分开计时，单块任务可能比旧合并公式更长；不把这次语义修正包装成必然加速。'
    elif line.startswith('这些代理没有加入后台装载重叠'):
        lines[i] = '模型包含有限权重预取和共享带宽争用，尚无逐 stream 排程或实测拟合。不构成真实硬件上下界或跨架构速度排名。'
    elif line.startswith('只有跨 K 分段才解析最后三项 VXM 参数。'):
        lines[i] = '只有跨 K 分段才解析最后三项 VXM 参数。默认 1/320/640 的冷 LW 为 20 cycle，内部 IW 为 20 拍载荷加 19 拍传播，首行另需 23 拍，总计 **82 cycle**。这些固定服务是明确假设，不能用整段权重装载参考时间同时充当 LW 和 IW 的实测依据。'
s = '\n'.join(lines) + '\n'
anchor = '<a id="tsp-mem-concurrency"></a>'
s = s.replace(anchor, '迁移 schema 7 → 8：新增 `weight_buffer_bytes` 的完整元数据；执行策略改为 `background` 和 `weight_prefetch`。`buffer_slots=1` 仍表示一份 MEM A/B/C 分配，待用权重缓冲另行限制。原 `install_bpc`、`install_propagation_cycles` 需重新确认仅描述内部 IW；报告删除旧安装组派生字段，新增 LW 等待/重叠统计和窗口计划。\n\n' + anchor)
p.write_text(s, encoding='utf-8')

p = Path('README.md'); s = p.read_text(encoding='utf-8')
s = s.replace('TSP/CIM 默认都将权重装载与计算串行，CIM 后台装载需显式选择。',
              '原生 TSP 固定采用单待用块权重预取；CIM 默认装载串行，后台 LW 需显式选择。')
s = s.replace('本次分配带宽、安装首组时间，以及实际尾块的 VXM 行计算/首行时间范围',
              '本次分配带宽、LW 空闲峰值、内部 IW 带宽、权重缓冲容量，以及实际尾块的 VXM 行计算/首行时间范围')
s = s.replace('TSP 当前硬件和报告均为 schema 7', 'TSP 当前硬件和报告均为 schema 8')
s += '''
原生 TSP 现使用 [有限权重预取模型](ARCHITECTURE.md#tsp-weight-prefetch)：LW 利用当前行流水剩余的 MEM 读和同方向 stream 带宽，IW 在旧 tile 排空后通过内部端口安装权重。仅保留一个待用块，假设缓冲容量为 204800 byte（200 KiB）；超过容量明确拒绝。31 项参考参数全部有值，19 documented、12 assumed。缓冲容量和保守 IW 时序均为建模假设，公开论文仅支持机制；没有保留旧串行运行选项。

报告以 `weight_load_stall + install + row_service` 分解总周期，另列已隐藏的 `weight_load_overlap_cycles` 和各 tile/LW 段。首次装载不会隐藏，内部 IW 不再次读取 MEM。默认 tiny 为 **601 cycle**，原有动作计数和 MEM 驻留容量保持不变。自定义 schema 7 配置需补全权重缓冲参数及预取策略后升级到 8。
'''
p.write_text(s, encoding='utf-8')
